package in.np.fxtools.lm.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
public class Attribute implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(length = 100)
    private String name;

    private Double amount;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "unitCode")
    private CodeMaster unit;

    @ManyToOne(fetch = FetchType.LAZY)
    private Sigil sigil;

    @ManyToOne(fetch = FetchType.LAZY)
    private Jewel jewel;

    @ManyToOne(fetch = FetchType.LAZY)
    private Equipment equipment;
}
