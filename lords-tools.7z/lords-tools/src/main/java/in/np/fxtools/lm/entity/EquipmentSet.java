package in.np.fxtools.lm.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Data
@Entity
public class EquipmentSet implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(length = 100)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    private CodeMaster setType;

    @OneToMany(mappedBy = "equipmentSet", fetch = FetchType.LAZY)
    private Set<Equipment> equipment;
}
