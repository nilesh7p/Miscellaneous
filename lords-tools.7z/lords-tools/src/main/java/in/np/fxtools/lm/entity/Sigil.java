package in.np.fxtools.lm.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Data
@Entity
public class Sigil implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(length = 100)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    private CodeMaster grade;

    @OneToMany(mappedBy = "sigil", fetch = FetchType.LAZY)
    private List<Attribute> attributes;
}
