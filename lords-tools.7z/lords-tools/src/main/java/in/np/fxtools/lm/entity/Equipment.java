package in.np.fxtools.lm.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Data
@Entity
public class Equipment implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(length = 100)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    private CodeMaster type;

    @ManyToOne(fetch = FetchType.LAZY)
    private CodeMaster grade;

    @ManyToOne(fetch = FetchType.LAZY)
    private Jewel slotOneJewel;

    @ManyToOne(fetch = FetchType.LAZY)
    private Jewel slotTwoJewel;

    @ManyToOne(fetch = FetchType.LAZY)
    private Jewel slotThreeJewel;

    @ManyToOne(fetch = FetchType.LAZY)
    private Sigil sigil;

    @OneToMany(mappedBy = "equipment", fetch = FetchType.LAZY)
    private Set<Attribute> attributes;

    @ManyToOne(fetch = FetchType.LAZY)
    private EquipmentSet equipmentSet;
}
