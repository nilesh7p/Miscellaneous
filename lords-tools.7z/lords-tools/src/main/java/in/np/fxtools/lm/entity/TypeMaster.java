package in.np.fxtools.lm.entity;

import lombok.Data;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Data
@Entity
public class TypeMaster implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(length = 100)
    private String name;

    @Column(length = 100)
    private String description;

    @Column(length = 1000)
    private String comments;

    @Column(length = 1)
    private String typeEditable;

    @Column(length = 1)
    private String typeAddable;

    @Column(length = 1)
    private String typeStatus;

    private Integer sortOrder;

    @OneToMany(mappedBy = "typeMaster", cascade = CascadeType.REMOVE, orphanRemoval = true)
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE, org.hibernate.annotations.CascadeType.DELETE,
            org.hibernate.annotations.CascadeType.MERGE, org.hibernate.annotations.CascadeType.PERSIST})
    private Set<CodeMaster> codeMasters;


}
