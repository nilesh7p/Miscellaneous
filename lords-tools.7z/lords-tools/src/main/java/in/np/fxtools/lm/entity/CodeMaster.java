package in.np.fxtools.lm.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
public class CodeMaster implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @ManyToOne
    @JoinColumn(name="codeType")
    private TypeMaster typeMaster;

    @Column(length = 100)
    private String name;

    @Column(length = 100)
    private String value;

    @Column(length = 100)
    private String description;

    @Column(length = 1000)
    private String comments;

    @Column(length = 1)
    private String codeEditable;

    @Column(length = 1)
    private String codeStatus;

    private Integer sortOrder;


}
