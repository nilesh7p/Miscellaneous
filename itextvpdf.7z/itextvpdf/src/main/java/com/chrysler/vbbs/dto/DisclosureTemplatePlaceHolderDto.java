
package com.chrysler.vbbs.dto;
//changes by Vivek

import java.util.List;

/**
 * @author 474865
 * T9450NP 7/16/2018
 */
public class DisclosureTemplatePlaceHolderDto {

    private String vin;

    private String year;

    private String make;

    private String model;

    private String problem1;

    private String problem2;

    private String problem3;

    private String problem4;

    private String problem5;

    private String repairMade1;

    private String repairMade2;

    private String repairMade3;

    private String repairMade4;

    private String repairMade5;

    private String additionalInfoLine1 = "";

    private String additionalInfoLine2 = "";

    private String dealerName = "";

    private String dealerCode = "";

    private String dealerState = "";

    private String dealerStreet = "";

    private String dealerCity = "";

    private String dealerZip = "";

    private String renderedBy;

    private String priorTitleNumber;

    private String previousTitleNumber;

    private String stateOfTitle;

    private String previousTitle;

    private String odoMeterReading;

    private String currentMileage;

    private String repurchaseDate;

    private String nameAndAddressOfPreviousOwner;

    private String fcaLLCrepresentativeAndTitle;

    private String vehicleOriginallySoldDate;

    private String repurchaseDateFromOwner;

    private String originalCustomerName;

    private String originalCustomerAddress;

    private String dateOfVehicleReacquation;

    private String cair;

    private String correctionDateOrComment1;

    private String correctionDateOrComment2;

    private String correctionDateOrComment3;

    private String correctionDateOrComment4;

    private String correctionDateOrComment5;

    private String transfareeName;

    private String transfareeLocation;

    private String transfareeState;

    private String transferredDate;

    private String sellerName;

    private String sellerBusinessName;

    private String sellerAddress;

    private String repairCost;

    private String approximateAmount;

    private String warrentyrestrictionYesOrNo;

    private String currentDate;

    private String caseValue;

    private String otherDamage;

    private String fcaRepSign;

    private String fcaRepSignDate;

    private String auctionName;

    private String goergiaRenderedBy;

    //added by Vivek
    private String buybackCair;
    private String currDate;
    //added by Vivek

    private List<String> repairsMade;
    private List<String> problems;

    public List<String> getRepairsMade() {
        return repairsMade;
    }

    public void setRepairsMade(List<String> repairsMade) {
        this.repairsMade = repairsMade;
    }

    public List<String> getProblems() {
        return problems;
    }

    public void setProblems(List<String> problems) {
        this.problems = problems;
    }

    public String getDealerZip() {
        return dealerZip;
    }

    //change by vivek
    public void setDealerZip(String dealerZip) {
        if (dealerZip != null)
            this.dealerZip = dealerZip;
        else
            this.dealerZip = "";

		/*if (StringUtils.hasText(dealerZip) && dealerZip.length() == 9) {

			String part1 = dealerZip.substring(0, 5);
			String part2 = dealerZip.substring(5);
			this.dealerZip = part1 + "-" + part2;

		} else {
			this.dealerZip = dealerZip;
		}*/
    }

    public String getRenderedBy() {
        return renderedBy;
    }

    public void setRenderedBy(String renderedBy) {
        this.renderedBy = renderedBy;
    }

    public String getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(String currentDate) {
        this.currentDate = currentDate;
    }

    public String getVin() {
        return vin;
    }

    public String getYear() {
        return year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getProblem1() {
        return problem1;
    }

    public String getProblem2() {
        return problem2;
    }

    public String getProblem3() {
        return problem3;
    }

    public String getProblem4() {
        return problem4;
    }

    public String getProblem5() {
        return problem5;
    }

    public String getRepairMade1() {
        return repairMade1;
    }

    public String getRepairMade2() {
        return repairMade2;
    }

    public String getRepairMade3() {
        return repairMade3;
    }

    public String getRepairMade4() {
        return repairMade4;
    }

    public String getRepairMade5() {
        return repairMade5;
    }

    public String getAdditionalInfoLine1() {
        return additionalInfoLine1;
    }

    public String getAdditionalInfoLine2() {
        return additionalInfoLine2;
    }

    public String getDealerName() {
        return dealerName;
    }

    public String getDealerCode() {
        return dealerCode;
    }

    public String getDealerState() {
        return dealerState;
    }

    public String getDealerStreet() {
        return dealerStreet;
    }

    public String getDealerCity() {
        return dealerCity;
    }

    public String getPriorTitleNumber() {
        return priorTitleNumber;
    }

    public String getStateOfTitle() {
        return stateOfTitle;
    }

    public String getCurrDate() {
        return currDate;
    }

    public void setCurrDate(String currDate) {
        this.currDate = currDate;
    }

    public String getBuybackCair() {
        return buybackCair;
    }

    public void setBuybackCair(String buybackCair) {
        this.buybackCair = buybackCair;
    }

    public String getOdoMeterReading() {
        return odoMeterReading;
    }

    public String getCurrentMileage() {
        return currentMileage;
    }

    public String getPreviousTitleNumber() {
        return previousTitleNumber;
    }

    public String getRepurchaseDate() {
        return repurchaseDate;
    }

    public String getNameAndAddressOfPreviousOwner() {
        return nameAndAddressOfPreviousOwner;
    }

    public String getFcaLLCrepresentativeAndTitle() {
        return fcaLLCrepresentativeAndTitle;
    }

    public String getVehicleOriginallySoldDate() {
        return vehicleOriginallySoldDate;
    }

    public String getRepurchaseDateFromOwner() {
        return repurchaseDateFromOwner;
    }

    public String getPreviousTitle() {
        return previousTitle;
    }

    public String getOriginalCustomerName() {
        return originalCustomerName;
    }

    public String getOriginalCustomerAddress() {
        return originalCustomerAddress;
    }

    public String getDateOfVehicleReacquation() {
        return dateOfVehicleReacquation;
    }

    public String getCair() {
        return cair;
    }

    public String getCorrectionDateOrComment1() {
        return correctionDateOrComment1;
    }

    public String getCorrectionDateOrComment2() {
        return correctionDateOrComment2;
    }

    public String getCorrectionDateOrComment3() {
        return correctionDateOrComment3;
    }

    public String getCorrectionDateOrComment4() {
        return correctionDateOrComment4;
    }

    public String getCorrectionDateOrComment5() {
        return correctionDateOrComment5;
    }

    public String getTransfareeName() {
        return transfareeName;
    }

    public String getTransfareeLocation() {
        return transfareeLocation;
    }

    public String getTransfareeState() {
        return transfareeState;
    }

    public String getTransferredDate() {
        return transferredDate;
    }

    public String getSellerName() {
        return sellerName;
    }

    public String getSellerBusinessName() {
        return sellerBusinessName;
    }

    public String getSellerAddress() {
        return sellerAddress;
    }

    public String getRepairCost() {
        return repairCost;
    }

    public String getApproximateAmount() {
        return approximateAmount;
    }

    public String getWarrentyrestrictionYesOrNo() {
        return warrentyrestrictionYesOrNo;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public void setYear(String year) {
        this.year = year;
    }

    //changed by vivek
    public void setMake(String make) {
        if (make != null)
            this.make = make;
        else
            this.make = "";
		/*if (make.length() > 15) {
			this.make = make.substring(0, 14);
		} else {
			this.make = make;
		}*/
    }

    //changed by vivek
    public void setModel(String model) {
        if (model != null)
            this.model = model;
        else
            this.model = "";
		/*if (model.length() > 30) {
			this.model = model.substring(0, 29);
		} else {
			this.model = model;
		}*/
    }


    //changed limit from 75 to 1025 by Vivek in all methods
    public void setProblem1(String problem1, boolean isGaProblem) {

        int maxCharToDisplay = 1025;
        int maxIndexToDisplay = 1024;
        if (isGaProblem) {
            maxCharToDisplay = 1025;
            maxIndexToDisplay = 1024;
        }

            this.problem1 = problem1;

    }

    public void setProblem2(String problem2, boolean isGaProblem) {
        int maxCharToDisplay = 1025;
        int maxIndexToDisplay = 1024;
        if (isGaProblem) {
            maxCharToDisplay = 1025;
            maxIndexToDisplay = 1024;
        }

            this.problem2 = problem2;
    }

    public void setProblem3(String problem3, boolean isGaProblem) {
        int maxCharToDisplay = 1025;
        int maxIndexToDisplay = 1024;
        if (isGaProblem) {
            maxCharToDisplay = 1025;
            maxIndexToDisplay = 1024;
        }

            this.problem3 = problem3;

    }

    public void setProblem4(String problem4, boolean isGaProblem) {
        int maxCharToDisplay = 1025;
        int maxIndexToDisplay = 1024;
        if (isGaProblem) {
            maxCharToDisplay = 1025;
            maxIndexToDisplay = 1024;
        }

            this.problem4 = problem4;

    }

    public void setProblem5(String problem5, boolean isGaProblem) {
        int maxCharToDisplay = 1025;
        int maxIndexToDisplay = 1024;
        if (isGaProblem) {
            maxCharToDisplay = 1025;
            maxIndexToDisplay = 1024;
        }

            this.problem5 = problem5;

    }

    //changed by Vivek
    public void setRepairMade1(String repairMade1) {

        this.repairMade1 = repairMade1;

		/*if (StringUtils.hasText(repairMade1) && repairMade1.length() > 75) {
			this.repairMade1 = repairMade1.substring(0, 74);
		} else {
			this.repairMade1 = repairMade1;
		}*/
    }

    //changed by Vivek
    public void setRepairMade2(String repairMade2) {

        this.repairMade2 = repairMade2;
		/*if (StringUtils.hasText(repairMade2) && repairMade2.length() > 75) {
			this.repairMade2 = repairMade2.substring(0, 74);
		} else {
			this.repairMade2 = repairMade2;
		}*/
    }

    //changed by Vivek
    public void setRepairMade3(String repairMade3) {

        this.repairMade3 = repairMade3;
		/*if (StringUtils.hasText(repairMade3) && repairMade3.length() > 75) {
			this.repairMade3 = repairMade3.substring(0, 74);
		} else {
			this.repairMade3 = repairMade3;
		}*/
    }

    //changed by Vivek
    public void setRepairMade4(String repairMade4) {

        this.repairMade4 = repairMade4;
		/*if (StringUtils.hasText(repairMade4) && repairMade4.length() > 75) {
			this.repairMade4 = repairMade4.substring(0, 74);
		} else {
			this.repairMade4 = repairMade4;
		}*/
    }

    //changed by Vivek
    public void setRepairMade5(String repairMade5) {
        this.repairMade5 = repairMade5;
		/*if (StringUtils.hasText(repairMade5) && repairMade5.length() > 75) {
			this.repairMade5 = repairMade5.substring(0, 74);
		} else {
			this.repairMade5 = repairMade5;
		}*/
    }

    //changed by Vivek
    public void setAdditionalInfoLine1(String additionalInfoLine1) {
        this.additionalInfoLine1 = additionalInfoLine1;
		/*if (additionalInfoLine1.length() > 80) {
			this.additionalInfoLine1 = additionalInfoLine1.substring(0, 79);
		} else {
			this.additionalInfoLine1 = additionalInfoLine1;
		}*/
    }

    //changed by Vivek
    public void setAdditionalInfoLine2(String additionalInfoLine2) {
        this.additionalInfoLine2 = additionalInfoLine2;
		/*if (additionalInfoLine2.length() > 80) {
			this.additionalInfoLine2 = additionalInfoLine2.substring(0, 79);
		} else {
			this.additionalInfoLine2 = additionalInfoLine2;
		}*/
    }

    //changed by Vivek
    public void setDealerName(String dealerName) {
        if (dealerName != null)
            this.dealerName = dealerName;
        else
            this.dealerName = " ";

		/*if (dealerName.length() > 31) {
			this.dealerName = dealerName.substring(0, 30);
		} else {
			this.dealerName = dealerName;
		}*/
    }

    //vivek change
    public void setDealerCode(String dealerCode) {
        if (dealerCode != null)
            this.dealerCode = dealerCode;
        else
            this.dealerCode = "";
    }

    //vivek change
    public void setDealerState(String dealerState) {
        if (dealerState != null)
            this.dealerState = dealerState;
        else
            this.dealerState = "";
    }

    //changed by Vivek
    public void setDealerStreet(String dealerStreet) {
        if (dealerStreet != null)
            this.dealerStreet = dealerStreet;
        else
            this.dealerStreet = "";
    }

    //changed by Vivek
    public void setDealerCity(String dealerCity) {
        if (dealerCity != null)
            this.dealerCity = dealerCity;
        else
            this.dealerCity = "";
		/*if (dealerCity.length() > 10) {
			this.dealerCity = dealerCity.substring(0, 9);
		} else {
			this.dealerCity = dealerCity;
		}*/
    }

    public void setPriorTitleNumber(String priorTitleNumber) {
        this.priorTitleNumber = priorTitleNumber;
    }

    public void setStateOfTitle(String stateOfTitle) {
        this.stateOfTitle = stateOfTitle;
    }

    public void setOdoMeterReading(String odoMeterReading) {
        this.odoMeterReading = odoMeterReading;
    }

    public void setCurrentMileage(String currentMileage) {
        this.currentMileage = currentMileage;
    }

    public void setPreviousTitleNumber(String previousTitleNumber) {
        this.previousTitleNumber = previousTitleNumber;
    }

    public void setRepurchaseDate(String repurchaseDate) {
        this.repurchaseDate = repurchaseDate;
    }

    public void setNameAndAddressOfPreviousOwner(String nameAndAddressOfPreviousOwner) {
        this.nameAndAddressOfPreviousOwner = nameAndAddressOfPreviousOwner;
    }

    public void setFcaLLCrepresentativeAndTitle(String fcaLLCrepresentativeAndTitle) {
        this.fcaLLCrepresentativeAndTitle = fcaLLCrepresentativeAndTitle;
    }

    public void setVehicleOriginallySoldDate(String vehicleOriginallySoldDate) {
        this.vehicleOriginallySoldDate = vehicleOriginallySoldDate;
    }

    public void setRepurchaseDateFromOwner(String repurchaseDateFromOwner) {
        this.repurchaseDateFromOwner = repurchaseDateFromOwner;
    }

    public void setPreviousTitle(String previousTitle) {
        this.previousTitle = previousTitle;
    }

    public void setOriginalCustomerName(String originalCustomerName) {
        this.originalCustomerName = originalCustomerName;
    }

    public void setOriginalCustomerAddress(String originalCustomerAddress) {
        this.originalCustomerAddress = originalCustomerAddress;
    }

    public void setDateOfVehicleReacquation(String dateOfVehicleReacquation) {
        this.dateOfVehicleReacquation = dateOfVehicleReacquation;
    }

    public void setCair(String cair) {
        this.cair = cair;
    }

    public void setCorrectionDateOrComment1(String correctionDateOrComment1) {
        this.correctionDateOrComment1 = correctionDateOrComment1;
    }

    public void setCorrectionDateOrComment2(String correctionDateOrComment2) {
        this.correctionDateOrComment2 = correctionDateOrComment2;
    }

    public void setCorrectionDateOrComment3(String correctionDateOrComment3) {
        this.correctionDateOrComment3 = correctionDateOrComment3;
    }

    public void setCorrectionDateOrComment4(String correctionDateOrComment4) {
        this.correctionDateOrComment4 = correctionDateOrComment4;
    }

    public void setCorrectionDateOrComment5(String correctionDateOrComment5) {
        this.correctionDateOrComment5 = correctionDateOrComment5;
    }

    public void setTransfareeName(String transfareeName) {
        this.transfareeName = transfareeName;
    }

    public void setTransfareeLocation(String transfareeLocation) {
        this.transfareeLocation = transfareeLocation;
    }

    public void setTransfareeState(String transfareeState) {
        this.transfareeState = transfareeState;
    }

    public void setTransferredDate(String transferredDate) {
        this.transferredDate = transferredDate;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public void setSellerBusinessName(String sellerBusinessName) {
        this.sellerBusinessName = sellerBusinessName;
    }

    public void setSellerAddress(String sellerAddress) {
        this.sellerAddress = sellerAddress;
    }

    public void setRepairCost(String repairCost) {
        this.repairCost = repairCost;
    }

    public void setApproximateAmount(String approximateAmount) {
        this.approximateAmount = approximateAmount;
    }

    public void setWarrentyrestrictionYesOrNo(String warrentyrestrictionYesOrNo) {
        this.warrentyrestrictionYesOrNo = warrentyrestrictionYesOrNo;
    }

    public String getCaseValue() {
        return caseValue;
    }

    public void setCaseValue(String caseValue) {
        this.caseValue = caseValue;
    }

    public String getOtherDamage() {
        return otherDamage;
    }

    public String getFcaRepSign() {
        return fcaRepSign;
    }

    public void setFcaRepSign(String fcaRepSign) {
        this.fcaRepSign = fcaRepSign;
    }

    public String getFcaRepSignDate() {
        return fcaRepSignDate;
    }

    public void setFcaRepSignDate(String fcaRepSignDate) {
        this.fcaRepSignDate = fcaRepSignDate;
    }

    public void setOtherDamage(String otherDamage) {

            this.otherDamage = otherDamage;

    }

    public String getAuctionName() {
        return auctionName;
    }

    public void setAuctionName(String auctionName) {
        this.auctionName = auctionName;
    }

    public String getGoergiaRenderedBy() {
        return goergiaRenderedBy;
    }

    public void setGoergiaRenderedBy(String goergiaRenderedBy) {
        this.goergiaRenderedBy = goergiaRenderedBy;
    }

    public static DisclosureTemplatePlaceHolderDto samplePreviewData() {
        DisclosureTemplatePlaceHolderDto dto = new DisclosureTemplatePlaceHolderDto();
        dto.setProblem1("Engine Over Heat", false);
        dto.setRepairMade1("serviced in local cerrage");
        dto.setProblem2("Engine Over Heat2", false);
        dto.setRepairMade2("serviced in local cerrage2");
        dto.setProblem3("Engine Over Heat3", false);
        dto.setRepairMade3("serviced in local cerrage3");
        dto.setProblem4("Engine Over Heat4", false);
        dto.setRepairMade4("serviced in local cerrage4");
        dto.setProblem5("Engine Over Heat5", false);
        dto.setRepairMade5("serviced in local cerrage5");
        dto.setDealerName("TORRADO JEEP EAGLE INCORPORATED");
        dto.setDealerCode("26484");
        dto.setDealerState("NJ");
        dto.setDealerStreet("2nd street");
        dto.setDealerCity("new jersey");
        dto.setCaseValue("case1234");
        return dto;

    }


}
