package com.chrysler.vbbs.pdf1;


import java.io.FileOutputStream;
import java.io.IOException;
import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Paragraph;

public class FloridaPdfTest {

	public static void main(String[] args) {
		DisclosureTemplatePlaceHolderDto dto = new DisclosureTemplatePlaceHolderDto();
		try {
			createPdf("D:\\PDF\\Florida.pdf", dto);
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void createPdf(String filename, DisclosureTemplatePlaceHolderDto dto)
			throws DocumentException, IOException {
		Document document = new Document(PageSize.LETTER);
		// document.setMargins(45, 36, 36, 45);
		PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
		document.open();
		createFinalPDf(document, writer, dto);
		document.close();
	}
		
		private static void createFinalPDf(Document document, PdfWriter writer, DisclosureTemplatePlaceHolderDto dto)
				throws BadElementException {

			final Font titleFont = new Font(FontFamily.UNDEFINED, 18, Font.BOLD);
			final Font paraFont = new Font(FontFamily.UNDEFINED, 10, Font.NORMAL);
			final Font normalFont = new Font(FontFamily.UNDEFINED, 12, Font.NORMAL);
			final Font boldFont = new Font(FontFamily.UNDEFINED, 12, Font.BOLD);
			final Font smmllFont = new Font(FontFamily.UNDEFINED, 8, Font.NORMAL);
			final Font dataFont = new Font(FontFamily.COURIER, 10, Font.NORMAL);
			final Font smallBold = new Font(FontFamily.UNDEFINED, 12, Font.BOLD);
			final Font cairPageNumFont = new Font(FontFamily.UNDEFINED, 10, Font.NORMAL);
			final Font cairPageNumFont1 = new Font(FontFamily.UNDEFINED, 8, Font.NORMAL);
			FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\ARIAL.TTF", "Arial_Normal");
			FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\micross.ttf", "MSSansSerif_Normal");
			FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\timesbd.ttf", "TNR_Bold");
			FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\times.ttf", "TNR_Normal");
			//FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\times.ttf", "TNR_Normal");
			FontFactory.register("D:\\Sheetal\\Workspace\\utah_pdf\\fonts\\cour.ttf", "CouNew_Normal");
			
			// Table 1
			// ********************************************************************************************************************
			PdfPTable cairPageNumTable = new PdfPTable(3);
			cairPageNumTable.setWidthPercentage(110);
			try {
				cairPageNumTable.setTotalWidth(new float[] { 100, 380, 100 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			cairPageNumTable.setLockedWidth(true);
			
			
			Font f_ArialNormal_8 = FontFactory.getFont("Arial_Normal", 8);
			PdfPCell cairCell = new PdfPCell(new Phrase(" " + "32265853 - 0522181539", f_ArialNormal_8));
			cairCell.setBorder(Rectangle.NO_BORDER);
			cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			// cairCell.setIndent(-5);
			cairPageNumTable.addCell(cairCell);

			cairCell = new PdfPCell(new Phrase(""));
			cairCell.setBorder(Rectangle.NO_BORDER);
			//cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			cairPageNumTable.addCell(cairCell);

			
			Font f_MSSansSerifNormal_8 = FontFactory.getFont("MSSansSerif_Normal", 8);
			
			Chunk cPage = new Chunk("Page ", f_MSSansSerifNormal_8);
			Chunk c2 = new Chunk("1 of 2", f_ArialNormal_8);
			Phrase p = new Phrase();
			p.add(cPage);
			p.add(c2);
			cairCell = new PdfPCell(new Phrase(p));
			cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			cairCell.setBorder(Rectangle.NO_BORDER);
			cairPageNumTable.addCell(cairCell);
			cairPageNumTable.setSpacingAfter(1f);

			// Table 2
			// **************************************************************************************************************************

			PdfPTable revNo = new PdfPTable(1);
			revNo.setWidthPercentage(110);
			try {
				revNo.setTotalWidth(new float[] {580});
			}catch(DocumentException e) {
				e.printStackTrace();
			}
			revNo.setLockedWidth(true);
			
			Font f_ArialNormal_7 = FontFactory.getFont("Arial_Normal", 7);
			PdfPCell revCell = new PdfPCell(new Phrase("Rev. 06/17", f_ArialNormal_7));
			revCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			revCell.setBorder(Rectangle.NO_BORDER);
			revNo.addCell(revCell);
			//revNo.setSpacingAfter(5f);
			
			//Table 3
			// **************************************************
			
			Image image = null;
			try {
				image = Image.getInstance("D:\\PDF\\images\\logo-fca.png");
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			PdfPTable titleTable = new PdfPTable(3);
			titleTable.setWidthPercentage(110);
			try {
				titleTable.setTotalWidth(new float[] { 80, 435, 65 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			titleTable.setLockedWidth(true);
			
			PdfPCell titleCell = new PdfPCell();
			titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			// titleCell.setBorderColor(new BaseColor(255,0,0));
			titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			 titleCell.setBorder(Rectangle.NO_BORDER);
			titleTable.getDefaultCell().setFixedHeight(39f);
			titleTable.getDefaultCell().setPaddingLeft(5f);
			//titleCell.setPaddingTop(f);
			titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
			//titleTable.getDefaultCell().setPaddingTop(-7);
			titleTable.addCell(image);

			Font f_TNRBold_17 = FontFactory.getFont("TNR_Bold", 17);
			titleCell = new PdfPCell(new Phrase("RESALE DISCLOSURE OF NONCONFORMITY -", f_TNRBold_17));
			titleCell.setBorder(Rectangle.NO_BORDER);
			titleCell.setPaddingTop(10f);
			titleCell.setPaddingLeft(47f);
			//titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
			//titleCell.setFixedHeight(15f);
			titleTable.addCell(titleCell);

			Font f_TNRBold_10 = FontFactory.getFont("TNR_Bold", 10);
			titleCell = new PdfPCell(new Phrase("FLORIDA", f_TNRBold_10));
			titleCell.setBorder(Rectangle.NO_BORDER);
			titleCell.setPaddingTop(17f);
			titleCell.setPaddingLeft(1);
			//titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
			titleTable.addCell(titleCell);
			titleTable.setSpacingAfter(1.5f);

			// Table 4 draw line
			// ***************************************************************************************************************************
			/*LineSeparator lineTitle = new LineSeparator();
			lineTitle.setOffset(-5);
			lineTitle.setPercentage(107);
			lineTitle.setLineWidth(3.3f);*/
			
			PdfPTable lineTitle = new PdfPTable(1);
			lineTitle.setWidthPercentage(110);
			try {
				lineTitle.setTotalWidth(new float[] { 580 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			lineTitle.setLockedWidth(true);
			
			PdfPCell lineCell = new PdfPCell(new Phrase());
			lineCell.setBorderWidth(3f);
			lineTitle.addCell(lineCell);
			lineTitle.setSpacingAfter(1.25f);
						
			// Table 5
			// ***************************************************************************************************************************

			PdfPTable checkOneTable = new PdfPTable(2);
			//checkOneTable.setSpacingBefore(1.5f);
			checkOneTable.setWidthPercentage(110);
			try {
				checkOneTable.setTotalWidth(new float[] { 44, 536 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			checkOneTable.setLockedWidth(true);
			
			PdfPCell partCell1 = new PdfPCell(new Phrase("PART I:", f_TNRBold_10));
			partCell1.setBorder(Rectangle.NO_BORDER);
			partCell1.setPaddingLeft(2f);
			partCell1.setPaddingTop(-0.05f);
			checkOneTable.addCell(partCell1);

			partCell1 = new PdfPCell(new Phrase("To be Completed by FCA US LLC Within 10 Days Of Transfer of the Returned Vehicle To the Auction.", f_TNRBold_10));
			partCell1.setPaddingTop(-0.05f);
			partCell1.setPaddingLeft(-1f);
			//partCell1.setLeading(1f, 0f);
			partCell1.setBorder(Rectangle.NO_BORDER);
			checkOneTable.addCell(partCell1);
			
			partCell1 = new PdfPCell(new Phrase());
			partCell1.setBorder(Rectangle.NO_BORDER);
			checkOneTable.addCell(partCell1);
			
			partCell1 = new PdfPCell(new Phrase("Upon Completion a Copy of This form is to be Mailed to the Office of the Attorney General, Lemon Law Enforcement Unit,", f_TNRBold_10));
			partCell1.setBorder(Rectangle.NO_BORDER);
			partCell1.setLeading(7.5f, 0f);
			partCell1.setPaddingLeft(-1f);
			checkOneTable.addCell(partCell1);
			
			partCell1 = new PdfPCell(new Phrase());
			partCell1.setBorder(Rectangle.NO_BORDER);
			checkOneTable.addCell(partCell1);
			
			partCell1 = new PdfPCell(new Phrase("The Capitol, Tallahassee, Florida 32399-1050.", f_TNRBold_10));
			partCell1.setBorder(Rectangle.NO_BORDER);
			partCell1.setLeading(7.5f, 0f);
			partCell1.setPaddingLeft(-1f);
			checkOneTable.addCell(partCell1);
			
			checkOneTable.setSpacingAfter(0.6f);
			
			//**********
			Font f_TNRNormal_10 = FontFactory.getFont("TNR_Normal", 10);
			Font f_CouNewNormal_10 = FontFactory.getFont("CouNew_Normal", 10);
			
			PdfPTable checkOneTable1 = new PdfPTable(8);
			//checkOneTable.setSpacingBefore(1.5f);
			checkOneTable1.setWidthPercentage(110);
			try {
				checkOneTable1.setTotalWidth(new float[] { 23, 119, 35, 57, 40, 227, 34, 45 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			checkOneTable1.setLockedWidth(true);
			
			PdfPCell vinDetails = new PdfPCell(new Phrase("VIN", f_TNRNormal_10));
			vinDetails.setBorder(Rectangle.NO_BORDER);
			
			checkOneTable1.addCell(vinDetails);
			
			vinDetails = new PdfPCell(new Phrase("ZACCJABT3FPB44930", f_CouNewNormal_10));
			vinDetails.setBorder(Rectangle.BOTTOM);
			vinDetails.setPaddingBottom(3.5f);
			vinDetails.setBorderWidth(1f);
			checkOneTable1.addCell(vinDetails);
			
			vinDetails = new PdfPCell(new Phrase("MAKE", f_TNRNormal_10));
			vinDetails.setBorder(Rectangle.NO_BORDER);
			checkOneTable1.addCell(vinDetails);
			
			vinDetails = new PdfPCell(new Phrase("JEEP", f_CouNewNormal_10));
			vinDetails.setBorder(Rectangle.BOTTOM);
			vinDetails.setBorderWidth(1f);
			checkOneTable1.addCell(vinDetails);
			
			vinDetails = new PdfPCell(new Phrase("MODEL ", f_TNRNormal_10));
			vinDetails.setBorder(Rectangle.NO_BORDER);
			checkOneTable1.addCell(vinDetails);
			
			vinDetails = new PdfPCell(new Phrase("RENEGADE LATITUDE 4X2 SPORT UTILITY   ", f_CouNewNormal_10));
			vinDetails.setBorder(Rectangle.BOTTOM);
			vinDetails.setBorderWidth(1f);
			checkOneTable1.addCell(vinDetails);
					
			vinDetails = new PdfPCell(new Phrase("YEAR", f_TNRNormal_10));
			vinDetails.setBorder(Rectangle.NO_BORDER);
			checkOneTable1.addCell(vinDetails);
					
			vinDetails = new PdfPCell(new Phrase("15", f_CouNewNormal_10));
			vinDetails.setBorder(Rectangle.BOTTOM);
			vinDetails.setBorderWidth(1f);
			checkOneTable1.addCell(vinDetails);
						
			
			
			//***************
			PdfPTable checkOneTable2 = new PdfPTable(6);
			//checkOneTable.setSpacingBefore(1.5f);
			checkOneTable2.setWidthPercentage(110);
			try {
				//add 2
				//minu 10
				checkOneTable2.setTotalWidth(new float[] { 85, 109, 82, 170, 54, 80 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			checkOneTable2.setLockedWidth(true);
			
			PdfPCell vinDetails1 = new PdfPCell(new Phrase("Odometer Reading:", f_TNRNormal_10));
			vinDetails1.setBorder(Rectangle.NO_BORDER);
			checkOneTable2.addCell(vinDetails1);
			
			vinDetails1 = new PdfPCell(new Phrase("27,693", f_CouNewNormal_10));
			vinDetails1.setBorder(Rectangle.BOTTOM);
			checkOneTable2.addCell(vinDetails1);
			
			vinDetails1 = new PdfPCell(new Phrase("Previous Title No.:", f_TNRNormal_10));
			vinDetails1.setBorder(Rectangle.NO_BORDER);
			checkOneTable2.addCell(vinDetails1);
			
			vinDetails1 = new PdfPCell(new Phrase("119806763", f_CouNewNormal_10));
			vinDetails1.setBorder(Rectangle.BOTTOM);
			checkOneTable2.addCell(vinDetails1);
			
			vinDetails1 = new PdfPCell(new Phrase("State:", f_TNRNormal_10));
			vinDetails1.setPaddingLeft(29.2f);
			vinDetails1.setBorder(Rectangle.NO_BORDER);
			checkOneTable2.addCell(vinDetails1);
			
			vinDetails1 = new PdfPCell(new Phrase("FL", f_CouNewNormal_10));
			vinDetails1.setBorder(Rectangle.BOTTOM);
			checkOneTable2.addCell(vinDetails1);
			
			/*
			
			
			cVin = new Chunk("YEAR ", f_TNRNormal_10);
			pPart1.add(cVin);
			cVin = new Chunk("15  ", f_CouNewNormal_10);
			cVin.setUnderline(1f, 0f);
			pPart1.add(cVin);
			
			PdfPCell vehDetail1 = new PdfPCell(pPart1);
			vehDetail1.setBorder(Rectangle.NO_BORDER);
			checkOneTable.addCell(vehDetail1);
			
			Phrase pVehDetails1 = new Phrase();
			//Odometer Reading: 27,693 Previous Title No.: 119806763 State: FL
			Chunk cVin1 = new Chunk("Odometer Reading:");
			pVehDetails1.add(cVin1);
			cVin1 = new Chunk("27,693");
			pVehDetails1.add(cVin1);
			cVin1 = new Chunk("Previous Title No.:");
			pVehDetails1.add(cVin1);
			cVin1 = new Chunk("119806763");
			pVehDetails1.add(cVin1);
			cVin1 = new Chunk("State");
			pVehDetails1.add(cVin1);
			cVin1 = new Chunk("FL");
			pVehDetails1.add(cVin1);
			
			PdfPCell vehDetail2 = new PdfPCell(pVehDetails1);
			vehDetail2.setBorder(Rectangle.NO_BORDER);
			checkOneTable.addCell(vehDetail2);
			*/
			
			//********************
			
			PdfPTable paraStart = new PdfPTable(1);
			paraStart.setWidthPercentage(110);
			try {
				paraStart.setTotalWidth(new float[] { 580 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStart.setLockedWidth(true);
			
			//TNR_Bold
			Font f_TNRBOLD_10 = FontFactory.getFont("TNR_Bold", 10);
			Chunk cPara1 = new Chunk("This is a ", f_TNRNormal_10);
			Chunk cPara2 = new Chunk("USED ", f_TNRBold_10);
			Chunk cPara3 = new Chunk("vehicle.  This vehicle was repurchased by FCA US LLC from the original owner on", f_TNRNormal_10);
			Phrase pPARA1 = new Phrase();
			pPARA1.add(cPara1);
			pPARA1.add(cPara2);
			pPARA1.add(cPara3);
			PdfPCell paraStart1 = new PdfPCell(pPARA1);
			paraStart1.setBorder(Rectangle.NO_BORDER);
			//paraStart.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStart1.setPaddingLeft(28f);
			//paraStart.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStart.addCell(paraStart1);
			
			//********************
			
			PdfPTable paraStart2 = new PdfPTable(2);
			paraStart2.setWidthPercentage(110);
			try {
				paraStart2.setTotalWidth(new float[] { 129, 451 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStart2.setLockedWidth(true);
			
			
			PdfPCell paraStart12 = new PdfPCell(new Phrase("9/14/2017", f_CouNewNormal_10));
			paraStart12.setBorder(Rectangle.BOTTOM);
			paraStart12.setPaddingLeft(37f);
			paraStart12.setPaddingBottom(4f);
			paraStart12.setBorderWidth(1f);
			//paraStart2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			//paraStart12.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStart2.addCell(paraStart12);
			
			paraStart12 = new PdfPCell(new Phrase("as a result of:", f_TNRNormal_10));
			paraStart12.setPaddingLeft(-0.5f);
			paraStart12.setBorder(Rectangle.NO_BORDER);
			paraStart2.addCell(paraStart12);
			
			
			//******
			Font f_TNRNormal_7 = FontFactory.getFont("TNR_Normal", 7);
			
			PdfPTable dateTable = new PdfPTable(1);
			dateTable.setWidthPercentage(110);
			try {
				dateTable.setTotalWidth(new float[] { 580 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			dateTable.setLockedWidth(true);
			
			PdfPCell dateTableCell = new PdfPCell(new Phrase("(Date)", f_TNRNormal_7));
			dateTableCell.setPaddingLeft(55f);
			dateTableCell.setPaddingTop(-0.15f);
			dateTableCell.setBorder(Rectangle.NO_BORDER);
			dateTable.addCell(dateTableCell);
			
			dateTable.setSpacingAfter(2f);
			
			
			//++++++++++++++++++++++++++++
			Image checkNO_BORDER = null;
			try {
				checkNO_BORDER = Image.getInstance("D:\\PDF\\images\\checkbox-blank-31x31.png");
				checkNO_BORDER.setAlignment(Image.ALIGN_LEFT);

			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			Image checkNO_BORDERCross = null;
			try {
				checkNO_BORDERCross = Image.getInstance("D:\\PDF\\images\\checkbox-crossed-31x31.png");
				checkNO_BORDERCross.setAlignment(Image.ALIGN_LEFT);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			//*****************************
			PdfPTable paraStartTable1 = new PdfPTable(2);
			paraStartTable1.setWidthPercentage(110);
			try {
				paraStartTable1.setTotalWidth(new float[] { 15, 565 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable1.setLockedWidth(true);
			
			PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", normalFont));
			paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable1.addCell(checkNO_BORDER);

			paraStartCell1 = new PdfPCell(new Phrase(
					"A settlement reached or a decision rendered by FCA US LLC Customer Arbitration Process.", f_TNRNormal_10));
			paraStartCell1.setBorder(Rectangle.NO_BORDER);
			paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable1.addCell(paraStartCell1);
			
			paraStartTable1.setSpacingAfter(-4.65f);
			
			
			
			//*****************
			
			PdfPTable paraStartTable2 = new PdfPTable(3);
			paraStartTable2.setWidthPercentage(110);
			//paraStartTable1.setSpacingAfter(14f);
			try {
				paraStartTable2.setTotalWidth(new float[] { 15, 465, 100 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable2.setLockedWidth(true);
			
			PdfPCell paraStartCell2 = new PdfPCell(new Phrase("", normalFont));
			paraStartTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable2.addCell(checkNO_BORDERCross);

			paraStartCell2 = new PdfPCell(new Phrase("A settlement reached or a decision rendered by the FL New Motor Vehicle Arbitration Board, Case #", f_TNRNormal_10));
			paraStartCell2.setBorder(Rectangle.NO_BORDER);
			paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable2.addCell(paraStartCell2);
			
			paraStartCell2 = new PdfPCell(new Phrase("2017-0197/ORL", f_CouNewNormal_10));
			paraStartCell2.setBorder(Rectangle.BOTTOM);
			paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable2.addCell(paraStartCell2);
			
			paraStartTable2.setSpacingAfter(-4.65f);
			paraStartTable2.setSpacingBefore(0.5f);
			//****
			
			PdfPTable paraStartTable3 = new PdfPTable(2);
			paraStartTable3.setWidthPercentage(110);
			//paraStartTable1.setSpacingAfter(14f);
			try {
				paraStartTable3.setTotalWidth(new float[] { 15, 565});
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable3.setLockedWidth(true);
			
			PdfPCell paraStartCell3 = new PdfPCell(new Phrase("", normalFont));
			paraStartTable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable3.addCell(checkNO_BORDER);

			paraStartCell3 = new PdfPCell(new Phrase("A court decision made pursuant to an action brought under Chapter 681, F.S. (The Florida Lemon Law)", f_TNRNormal_10));
			paraStartCell3.setBorder(Rectangle.NO_BORDER);
			paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable3.addCell(paraStartCell3);
			
			paraStartTable3.setSpacingAfter(-4.65f);
			paraStartTable3.setSpacingBefore(0.5f);
			//*******************
			
			
			PdfPTable paraStartTable4 = new PdfPTable(4);
			paraStartTable4.setWidthPercentage(110);
			//paraStartTable1.setSpacingAfter(14f);
			try {
				paraStartTable4.setTotalWidth(new float[] { 15, 300, 100, 165});
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable4.setLockedWidth(true);
			
			PdfPCell paraStartCell4 = new PdfPCell(new Phrase("", normalFont));
			paraStartTable4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable4.addCell(checkNO_BORDER);

			paraStartCell4 = new PdfPCell(new Phrase(" An arbitration, administrative, or judicial determination made pursuant to the", f_TNRNormal_10));
			paraStartCell4.setBorder(Rectangle.NO_BORDER);
			paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable4.addCell(paraStartCell4);
			
			paraStartCell4 = new PdfPCell(new Phrase());
			paraStartCell4.setBorder(Rectangle.BOTTOM);
			paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable4.addCell(paraStartCell4);
			
			paraStartCell4 = new PdfPCell(new Phrase("Lemon Law.", f_TNRNormal_10));
			paraStartCell4.setBorder(Rectangle.NO_BORDER);
			paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable4.addCell(paraStartCell4);
			
			paraStartTable4.setSpacingAfter(-4.65f);
			paraStartTable4.setSpacingBefore(0.5f);
			//********
			
			
			PdfPTable paraStartTable5 = new PdfPTable(1);
			paraStartTable5.setWidthPercentage(110);
			
			try {
				paraStartTable5.setTotalWidth(new float[] { 580});
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable5.setLockedWidth(true);
			
			
			PdfPCell paraStartCell5 = new PdfPCell(new Phrase("(State)", f_TNRNormal_7));
			paraStartTable5.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable5.addCell(paraStartCell5);
			
			paraStartTable5.setSpacingAfter(-4.65f);
			paraStartTable5.setSpacingBefore(0.5f);
			
			//*************
			
			
			PdfPTable paraStartTable6 = new PdfPTable(2);
			paraStartTable6.setWidthPercentage(110);
			
			try {
				paraStartTable6.setTotalWidth(new float[] { 15, 565 });
			} catch (DocumentException e2) {
				e2.printStackTrace();
			}
			paraStartTable6.setLockedWidth(true);
			
			//Font f_TNRNormal_7 = FontFactory.getFont("TNR_Normal", 7);
			PdfPCell paraStartCell6 = new PdfPCell(new Phrase());
			paraStartTable6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable6.addCell(checkNO_BORDER);
			
			paraStartCell6 = new PdfPCell(new Phrase("A settlement reached or a decision rendered by the Florida Pilot RV Mediation/Arbitration Program.", f_TNRNormal_10));
			paraStartCell6.setBorder(Rectangle.NO_BORDER);
			paraStartCell6.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable6.addCell(paraStartCell6);
			
			
			PdfPCell paraStartCell7 = new PdfPCell(new Phrase());
			paraStartTable6.getDefaultCell().setBorder(Rectangle.NO_BORDER);
			paraStartCell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable6.addCell(checkNO_BORDER);
			
			paraStartCell7 = new PdfPCell(new Phrase("An effort to promote customer satisfaction.", f_TNRNormal_10));
			paraStartCell7.setBorder(Rectangle.NO_BORDER);
			paraStartCell7.setHorizontalAlignment(Element.ALIGN_LEFT);
			paraStartTable6.addCell(paraStartCell7);
			
			paraStartTable6.setSpacingAfter(-4.65f);
			paraStartTable6.setSpacingBefore(0.5f);
			
			//  *****************
			
			
			PdfPTable pDetail = new PdfPTable(1);
			pDetail.setWidthPercentage(110);
			try {
				pDetail.setTotalWidth(new float[] { 580 });
			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			pDetail.setLockedWidth(true);

			PdfPCell cell_PT = new PdfPCell(new Phrase("The vehicle was alleged or determined to have the following nonconformities:", f_TNRNormal_10));
			cell_PT.setBorder(Rectangle.NO_BORDER);
			pDetail.addCell(cell_PT);
			
			//Table
			
			PdfPTable problemsTable = new PdfPTable(2);
			problemsTable.setWidthPercentage(110);
			try {
				problemsTable.setTotalWidth(new float[] { 19, 559 });
			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			problemsTable.setLockedWidth(true);
			

			PdfPCell cellPT = new PdfPCell(new Phrase("1. ", f_TNRNormal_10));
			//cellPT.setBorderWidth(1f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
			//cellPT.setIndent(10f);
			cellPT.setFixedHeight(14f);
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("Car doors wouldn't lock.", f_CouNewNormal_10));
			cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			//cellPT.setPaddingBottom(2f);
			cellPT.enableBorderSide(2);
			
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("2. ", f_TNRNormal_10));
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setFixedHeight(14f);
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("Camera back up wouldn't turn on.", f_CouNewNormal_10));
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setPaddingTop(0.5f);
			cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			//cellPT.setMinimumHeight(10f);
			//cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
			//cellPT.setPaddingBottom(2f);
			cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);

			// cellPT = new PdfPCell(new Phrase(dto.getRepairMade1()));
			cellPT = new PdfPCell(new Phrase("3. ", f_TNRNormal_10));
			//cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			//cellPT.setMinimumHeight(15f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("Parking brake comes on all the time.", f_CouNewNormal_10));
			cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			//cellPT.setMinimumHeight(15f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setPaddingBottom(2f);
			cellPT.enableBorderSide(2);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);
			
			cellPT = new PdfPCell(new Phrase("4. ", f_TNRNormal_10));
			//cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			//cellPT.setMinimumHeight(15f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("Electrical system switches to different language.", f_CouNewNormal_10));
			cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			//cellPT.setMinimumHeight(15f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setPaddingBottom(2f);
			cellPT.enableBorderSide(2);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);
			
			cellPT = new PdfPCell(new Phrase("5. ", f_TNRNormal_10));
			//cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(14f);
			cellPT.setPaddingBottom(2f);
			//cellPT.setMinimumHeight(26f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);

			cellPT = new PdfPCell(new Phrase("All lights come on.", f_CouNewNormal_10));
			cellPT.setBorderWidth(1f);
			cellPT.setFixedHeight(10);
			//cellPT.setMinimumHeight(26f);
			cellPT.setBorder(Rectangle.NO_BORDER);
			cellPT.setPaddingTop(-1.8f);
			cellPT.enableBorderSide(2);
			//cellPT.enableBorderSide(2);
			problemsTable.addCell(cellPT);
			
			problemsTable.setSpacingAfter(5f);
			
			// Table ****
			
			PdfPTable addInfoTable = new PdfPTable(2);
			addInfoTable.setWidthPercentage(110);
			try {
				addInfoTable.setTotalWidth(new float[] { 108, 472 });
			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			addInfoTable.setLockedWidth(true);
			
			PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:", f_TNRNormal_10));
			cellAddInfo.setBorder(Rectangle.NO_BORDER);
			cellAddInfo.setPaddingBottom(4f);
			//cellAddInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
			addInfoTable.addCell(cellAddInfo);

			cellAddInfo = new PdfPCell(new Phrase(""));
			cellAddInfo.setBorderWidth(1.05f);
			cellAddInfo.setBorder(Rectangle.NO_BORDER);
			cellAddInfo.enableBorderSide(2);
			cellAddInfo.setPaddingLeft(20f);
			addInfoTable.addCell(cellAddInfo);
			//addInfoTable.setSpacingAfter(20f); 
			
			// *****************
			PdfPTable addInfoTable1 = new PdfPTable(1);
			addInfoTable1.setWidthPercentage(110);
			try {
				addInfoTable1.setTotalWidth(new float[] { 580 });
			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			addInfoTable1.setLockedWidth(true);
			
			PdfPCell cellAddInfo1 = new PdfPCell(new Phrase(""));
			cellAddInfo1.setBorderWidth(1.5f);
			cellAddInfo1.setFixedHeight(13f);
			cellAddInfo1.enableBorderSide(2);
			cellAddInfo1.setBorder(Rectangle.BOTTOM);
			addInfoTable1.addCell(cellAddInfo1);
			
			//************************
			
			PdfPTable brkLineSignTable = new PdfPTable(5);
			brkLineSignTable.setWidthPercentage(110);
			try {
				brkLineSignTable.setTotalWidth(new float[] { 255, 20, 215, 20, 70 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			brkLineSignTable.setLockedWidth(true);

			PdfPCell cellPT1 = new PdfPCell(new Phrase());
			cellPT1.setBorder(Rectangle.BOTTOM);
			cellPT1.setFixedHeight(18f);
			cellPT1.setBorderWidth(1.14f);
			cellPT1.enableBorderSide(2);
			//cellPT1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			//cellPT1.setPaddingTop(7.5f);
			brkLineSignTable.addCell(cellPT1);

			cellPT1 = new PdfPCell(new Phrase(""));
			//cellPT1.setFixedHeight(18f);
			//cellPT1.setBorderWidth(1f);
			cellPT1.setBorder(Rectangle.NO_BORDER);
			brkLineSignTable.addCell(cellPT1);

			cellPT1 = new PdfPCell(new Phrase(""));
			cellPT1.setBorder(Rectangle.BOTTOM);
			cellPT1.setBorderWidth(1.14f);
			cellPT1.setFixedHeight(18f);
			cellPT1.enableBorderSide(2);
			brkLineSignTable.addCell(cellPT1);
			
			cellPT1 = new PdfPCell(new Phrase(""));
			cellPT1.setBorder(Rectangle.NO_BORDER);
			//cellPT1.setBorder(Rectangle.BOTTOM);
			//cellPT1.setFixedHeight(18f);
			//cellPT1.setBorderWidth(1f);
			brkLineSignTable.addCell(cellPT1);

			cellPT1 = new PdfPCell(new Phrase(" 05/22/2018", f_CouNewNormal_10));
			cellPT1.setBorder(Rectangle.BOTTOM);
			cellPT1.setFixedHeight(18f);
			cellPT1.setPaddingTop(5f);
			cellPT1.enableBorderSide(2);
			cellPT1.setBorderWidth(1.14f);
			brkLineSignTable.addCell(cellPT1);

			brkLineSignTable.setSpacingBefore(0.3f);
			//*************************************
			
			PdfPTable brkLineDelRepTable = new PdfPTable(5);
			brkLineDelRepTable.setWidthPercentage(110);
			
			try {
				brkLineDelRepTable.setTotalWidth(new float[] { 255, 20, 215, 20, 70 });
			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			brkLineDelRepTable.setLockedWidth(true);
			
			Font f_TNRNormal_8 = FontFactory.getFont("TNR_Normal", 8);
			PdfPCell cellPrintD = new PdfPCell(new Phrase("FCA US LLC Representative PrintedName and Title", f_TNRNormal_8));
			cellPrintD.setBorder(Rectangle.NO_BORDER);
			cellPrintD.setPaddingTop(-0.25f);
			cellPrintD.setPaddingLeft(-1f);
			//cellPrintD.enableBorderSide(2);
			//cellPrintD.setBorderWidth(1f);
			brkLineDelRepTable.addCell(cellPrintD);
			
			cellPrintD = new PdfPCell(new Phrase());
			cellPrintD.setBorder(Rectangle.NO_BORDER);
			brkLineDelRepTable.addCell(cellPrintD);
			
			cellPrintD = new PdfPCell(new Phrase("FCA US LLC Representative Signature", f_TNRNormal_8));
			//cellPrintD.setBorderWidth(1f);
			cellPrintD.setPaddingTop(-0.25f);
			cellPrintD.setBorder(Rectangle.NO_BORDER);
			brkLineDelRepTable.addCell(cellPrintD);

			cellPrintD = new PdfPCell(new Phrase(""));
			cellPrintD.setBorder(Rectangle.NO_BORDER);
			brkLineDelRepTable.addCell(cellPrintD);
			
			cellPrintD = new PdfPCell(new Phrase("Date", f_TNRNormal_8));
			cellPrintD.setPaddingTop(-0.25f);
			cellPrintD.setPaddingLeft(30f);
			cellPrintD.setBorder(Rectangle.NO_BORDER);
			brkLineDelRepTable.addCell(cellPrintD);
			brkLineDelRepTable.setSpacingAfter(-2f);
			
			//*****************
			PdfPTable transDetail = new PdfPTable(1);
			transDetail.setWidthPercentage(110);
			try {
				transDetail.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			transDetail.setLockedWidth(true);
			
			//TNR_Bold
			PdfPCell transCell = new PdfPCell(new Phrase("Transferred by FCA US LLC To:", f_TNRBold_10));
			transCell.setBorder(Rectangle.NO_BORDER);
			transCell.setPaddingLeft(-1f);
			//Phrase pCell = new Phrase();
			transDetail.addCell(transCell);
			transDetail.setSpacingAfter(-3f);
		
			
			//**********************
			PdfPTable brkLineTransTable = new PdfPTable(5);
			brkLineTransTable.setWidthPercentage(110);
			try {
				//brkLineTransTable.setTotalWidth(new float[] { 255, 18, 215, 18, 80 });
				brkLineTransTable.setTotalWidth(new float[] {257, 18, 217, 18, 70 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			brkLineTransTable.setLockedWidth(true);

			PdfPCell cellPT2 = new PdfPCell(new Phrase("FLORIDA AUTO AUCTION OF ORLANDO", f_CouNewNormal_10));
			cellPT2.setBorder(Rectangle.BOTTOM);
			cellPT2.setFixedHeight(18f);
			cellPT2.setBorderWidth(1f);
			cellPT2.enableBorderSide(2);
			cellPT2.setPaddingLeft(32f);
			cellPT2.setPaddingTop(3.8f);
			//cellPT1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			//cellPT1.setPaddingTop(7.5f);
			brkLineTransTable.addCell(cellPT2);

			cellPT2 = new PdfPCell(new Phrase(""));
			//cellPT1.setFixedHeight(18f);
			//cellPT1.setBorderWidth(1f);
			cellPT2.setBorder(Rectangle.NO_BORDER);
			brkLineTransTable.addCell(cellPT2);

			Chunk cPT1 = new Chunk("OCOEE", f_CouNewNormal_10);
			Chunk cPT2 = new Chunk(" / ", f_TNRBold_10);
			Chunk cPT3 = new Chunk("FL", f_CouNewNormal_10);
			Phrase pPT = new Phrase();
			pPT.add(cPT1);
			pPT.add(cPT2);
			pPT.add(cPT3);
			cellPT2 = new PdfPCell(new Phrase(pPT));
			cellPT2.setBorder(Rectangle.BOTTOM);
			cellPT2.setBorderWidth(1f);
			cellPT2.setFixedHeight(18f);
			cellPT2.enableBorderSide(2);
			cellPT2.setPaddingLeft(60f);
			cellPT2.setPaddingTop(3.8f);
			brkLineTransTable.addCell(cellPT2);
			
			cellPT2 = new PdfPCell(new Phrase(""));
			cellPT2.setBorder(Rectangle.NO_BORDER);
			//cellPT1.setBorder(Rectangle.BOTTOM);
			//cellPT1.setFixedHeight(18f);
			//cellPT1.setBorderWidth(1f);
			brkLineTransTable.addCell(cellPT2);

			cellPT2 = new PdfPCell(new Phrase(" 01/23/2018", f_CouNewNormal_10));
			cellPT2.setPaddingLeft(0.5f);
			cellPT2.setBorder(Rectangle.BOTTOM);
			cellPT2.setFixedHeight(18f);
			cellPT2.enableBorderSide(2);
			cellPT2.setBorderWidth(1f);
			cellPT2.setPaddingTop(3.8f);
			brkLineTransTable.addCell(cellPT2);

			//************************
			
			PdfPTable TransDetailTable = new PdfPTable(5);
			TransDetailTable.setWidthPercentage(110);
			try {
				TransDetailTable.setTotalWidth(new float[] { 257, 18, 217, 18, 70 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			TransDetailTable.setLockedWidth(true);

			PdfPCell cellPT3 = new PdfPCell(new Phrase("Transferee Name (please print)", f_TNRNormal_8));
			cellPT3.setBorder(Rectangle.NO_BORDER);
			cellPT3.setFixedHeight(12f);
			cellPT3.setPaddingLeft(78f);
			cellPT3.setPaddingTop(1f);
			//cellPT3.setPaddingTop(7.5f);
			TransDetailTable.addCell(cellPT3);

			cellPT3 = new PdfPCell(new Phrase(""));
			cellPT1.setFixedHeight(12f);
			cellPT3.setBorder(Rectangle.NO_BORDER);
			//cellPT3.setPaddingTop(-0.25f);
			TransDetailTable.addCell(cellPT3);

			cellPT3 = new PdfPCell(new Phrase("Transferee Location/State (please print)", f_TNRNormal_8));
			cellPT3.setBorder(Rectangle.NO_BORDER);
			cellPT3.setFixedHeight(12f);
			cellPT3.setPaddingLeft(50f);
			cellPT3.setPaddingTop(-0.25f);
			TransDetailTable.addCell(cellPT3);			
			
			cellPT3 = new PdfPCell(new Phrase(""));
			cellPT3.setBorder(Rectangle.NO_BORDER);
			//cellPT1.setBorder(Rectangle.BOTTOM);
			cellPT3.setFixedHeight(12f);
			//cellPT1.setBorderWidth(1f);
			TransDetailTable.addCell(cellPT3);

			cellPT3 = new PdfPCell(new Phrase("Date Tranferred", f_TNRNormal_8));
			cellPT3.setPaddingLeft(10f);
			cellPT3.setBorder(Rectangle.NO_BORDER);
			cellPT3.setFixedHeight(12f);
			cellPT3.setPaddingTop(-0.25f);
			TransDetailTable.addCell(cellPT3);
			
			TransDetailTable.setSpacingAfter(-5f);
			
			//*****************
			PdfPTable tableShrPara = new PdfPTable(1);
			tableShrPara.setWidthPercentage(110);
			try {
				tableShrPara.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			tableShrPara.setLockedWidth(true);
			
			
			PdfPCell pShortPara = new PdfPCell(new Phrase("At the time of each transfer of such returned motor vehicle, the transferor shall ensure that the transferee receives this form and that this form\n" + 
					"remains with the vehicle.", f_TNRNormal_10));
			pShortPara.setBorder(Rectangle.NO_BORDER);
			pShortPara.setLeading(3f, 0.8f);
			//pShortPara.setLeading(0.5f);
			tableShrPara.addCell(pShortPara);
			
			
			tableShrPara.setSpacingAfter(-1.7f);
			
			//******************
			PdfPTable tableShrPara1 = new PdfPTable(1);
			tableShrPara1.setWidthPercentage(110);
			try {
				tableShrPara1.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			tableShrPara1.setLockedWidth(true);
			
			PdfPCell pShortPara1 = new PdfPCell(new Phrase("Part II: To be Completed Upon Sale or Lease to the Ultimate (Retail) Consumer. Within 10 Days of Sale or Lease Mail a Copy of this\n" + 
					"disclosure to the Office of the Attorney General, Lemon Law Enforcement Unit, The Capitol, Tallahassee, FL 32399-1050", f_TNRBold_10));
			
			pShortPara1.setBorder(Rectangle.NO_BORDER);
			tableShrPara1.addCell(pShortPara1);
			
			//****************
			
			PdfPTable brkLineSellTable = new PdfPTable(5);
			brkLineSellTable.setWidthPercentage(110);
			try {
				brkLineSellTable.setTotalWidth(new float[] { 255, 20, 215, 20, 70 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			brkLineSellTable.setLockedWidth(true);

			PdfPCell cellSell = new PdfPCell(new Phrase());
			cellSell.setBorder(Rectangle.BOTTOM);
			cellSell.setFixedHeight(18f);
			cellSell.setBorderWidth(1f);
			cellSell.enableBorderSide(2);
			//cellPT1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			//cellPT1.setPaddingTop(7.5f);
			brkLineSellTable.addCell(cellSell);

			cellSell = new PdfPCell(new Phrase(""));
			cellSell.setFixedHeight(18f);
			cellSell.setBorder(Rectangle.NO_BORDER);
			brkLineSellTable.addCell(cellSell);

			cellSell = new PdfPCell(new Phrase(""));
			cellSell.setBorder(Rectangle.BOTTOM);
			cellSell.setBorderWidth(1f);
			cellSell.setFixedHeight(18f);
			cellSell.enableBorderSide(2);
			brkLineSellTable.addCell(cellSell);
			
			cellSell = new PdfPCell(new Phrase());
			cellSell.setBorder(Rectangle.NO_BORDER);
			//cellPT1.setBorder(Rectangle.BOTTOM);
			cellSell.setFixedHeight(18f);
			//cellPT1.setBorderWidth(1f);
			brkLineSellTable.addCell(cellSell);

			cellSell = new PdfPCell(new Phrase());
			cellSell.setBorder(Rectangle.BOTTOM);
			cellSell.setFixedHeight(18f);
			cellSell.enableBorderSide(2);
			cellSell.setBorderWidth(1f);
			brkLineSellTable.addCell(cellSell);
			
			brkLineSellTable.setSpacingAfter(-2.4f);
			
			//*******************
			
			
			PdfPTable lineSellDetailTable = new PdfPTable(5);
			lineSellDetailTable.setWidthPercentage(110);
			try {
				lineSellDetailTable.setTotalWidth(new float[] { 255, 20, 215, 20, 70 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			lineSellDetailTable.setLockedWidth(true);

			PdfPCell cellSellDetail = new PdfPCell(new Phrase("Seller or Lessor Representative Printed Name and Title", f_TNRNormal_8));
			cellSellDetail.setBorder(Rectangle.NO_BORDER);
			cellSellDetail.setFixedHeight(12f);
			cellSellDetail.setPaddingLeft(36f);
			lineSellDetailTable.addCell(cellSellDetail);

			cellSellDetail = new PdfPCell(new Phrase(""));
			cellSellDetail.setFixedHeight(12f);
			
			cellSellDetail.setBorder(Rectangle.NO_BORDER);
			lineSellDetailTable.addCell(cellSellDetail);

			cellSellDetail = new PdfPCell(new Phrase("Seller or Lessor Representative Signature", f_TNRNormal_8));
			cellSellDetail.setBorder(Rectangle.NO_BORDER);
			cellSellDetail.setFixedHeight(12f);
			cellSellDetail.setPaddingLeft(40f);
			lineSellDetailTable.addCell(cellSellDetail);
			
			cellSellDetail = new PdfPCell(new Phrase());
			cellSellDetail.setBorder(Rectangle.NO_BORDER);
			cellSellDetail.setFixedHeight(12f);
			lineSellDetailTable.addCell(cellSellDetail);

			cellSellDetail = new PdfPCell(new Phrase("Date", f_TNRNormal_8));
			cellSellDetail.setBorder(Rectangle.NO_BORDER);
			cellSellDetail.setFixedHeight(12f);
			cellSellDetail.setPaddingLeft(27f);
			lineSellDetailTable.addCell(cellSellDetail);
						
			lineSellDetailTable.setSpacingAfter(-4.5f);
			//************************
			
			PdfPTable tableBusiness = new PdfPTable(2);
			tableBusiness.setWidthPercentage(110);
			try {
				tableBusiness.setTotalWidth(new float[] { 500, 80 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			tableBusiness.setLockedWidth(true);

			PdfPCell cellBusiness = new PdfPCell(new Phrase("MARTIN MOTORS, 709 S DAVIS STREET, NASHVILLE, GA 316392620", f_CouNewNormal_10));
			cellBusiness.setBorder(Rectangle.BOTTOM);
			cellBusiness.setFixedHeight(18f);
			cellBusiness.setBorderWidth(1f);
			cellBusiness.enableBorderSide(2);
			cellBusiness.setPaddingLeft(-1f);
			cellBusiness.setPaddingTop(5f);
			cellBusiness.setPaddingBottom(-0.15f);
			tableBusiness.addCell(cellBusiness);
			
			cellBusiness = new PdfPCell(new Phrase("63938", f_CouNewNormal_10));
			cellBusiness.setBorder(Rectangle.BOTTOM);
			cellBusiness.setFixedHeight(18f);
			cellBusiness.setBorderWidth(1f);
			cellBusiness.enableBorderSide(2);
			cellBusiness.setPaddingLeft(28f);
			cellBusiness.setPaddingBottom(-0.15f);
			cellBusiness.setPaddingTop(5f);
			tableBusiness.addCell(cellBusiness);
			
			
			//******
			PdfPTable tableBusinessDetail = new PdfPTable(2);
			tableBusinessDetail.setWidthPercentage(110);
			try {
				tableBusinessDetail.setTotalWidth(new float[] { 480, 100 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			tableBusinessDetail.setLockedWidth(true);
			
			PdfPCell cellBusiness1 = new PdfPCell(new Phrase("Business Name & Address of Seller or Lessor (please print)", f_TNRNormal_8));
			cellBusiness1.setBorder(Rectangle.NO_BORDER);
			cellBusiness1.setFixedHeight(15f);
			cellBusiness1.setPaddingTop(-0.25f);
			tableBusinessDetail.addCell(cellBusiness1);
			
			cellBusiness1 = new PdfPCell(new Phrase("Dealer Code", f_TNRNormal_8));
			cellBusiness1.setBorder(Rectangle.NO_BORDER);
			cellBusiness1.setFixedHeight(15f);
			cellBusiness1.setPaddingTop(-0.25f);
			cellBusiness1.setPaddingLeft(44f);
			tableBusinessDetail.addCell(cellBusiness1);
			
			tableBusinessDetail.setSpacingAfter(-5.5f);
			//*******************
			PdfPTable signPara1 = new PdfPTable(1);
			signPara1.setWidthPercentage(110);
			try {
				signPara1.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			signPara1.setLockedWidth(true);

			PdfPCell cellSign = new PdfPCell(new Phrase("The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above information will be made to the retail customer prior to sale or lease of\n" + 
					"this vehicle as provided by law in the state in which it is resold or leased. The dealer agrees to defend, indemnify, and hold harmless", f_TNRNormal_8));
			cellSign.setBorder(Rectangle.NO_BORDER);
			cellSign.setPaddingLeft(-0.25f);
			signPara1.addCell(cellSign);
			
			
			//*******************
			PdfPTable signPara2 = new PdfPTable(1);
			signPara2.setWidthPercentage(110);
			try {
				signPara2.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			signPara2.setLockedWidth(true);
			
			Font f_TNRBold_8 = FontFactory.getFont("TNR_Bold", 8);
			Chunk sign1 = new Chunk("FCA US LLC from all claims, causes of action, or any other liability arising from or related to the dealer's failure to make proper disclosure of the above information, whether or\n" + 
					"not disclosure is required by state or federal law.", f_TNRNormal_8);
			Chunk sign2 = new Chunk("  From the date of delivery of this motor vehicle to the first consumer to whom it is sold or leased after its return to FCA\n" + 
					"US LLC pursuant to Part I hereof, FCA US LLC warrants to correct the nonconformities listed at Part I above for a term of 12 months with no mileage limitation.\n" + 
					"I read, or had read to me, the terms of this disclosure before I purchased or leased this vehicle.", f_TNRBold_8);
			sign2.setLineHeight(9.5f);
			Phrase pSignDemo = new Phrase();
			pSignDemo.add(sign1);
			pSignDemo.add(sign2);
			
			pSignDemo.setLeading(10f);
			PdfPCell cellSign1 = new PdfPCell(pSignDemo);
			cellSign1.setPaddingTop(-0.5f);
			cellSign1.setPaddingLeft(-0.25f);
			cellSign1.setBorder(Rectangle.NO_BORDER);
			signPara2.addCell(cellSign1);
			
			//***************
			PdfPTable conSignDetailTable = new PdfPTable(5);
			conSignDetailTable.setWidthPercentage(110);
			try {
				conSignDetailTable.setTotalWidth(new float[] { 93, 265, 97, 26, 100 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			conSignDetailTable.setLockedWidth(true);

			PdfPCell cellconDetail = new PdfPCell(new Phrase("Consumer Signature:", f_TNRNormal_10));
			cellconDetail.setBorder(Rectangle.NO_BORDER);
			cellconDetail.setFixedHeight(18f);
			cellconDetail.setPaddingTop(5f);
			conSignDetailTable.addCell(cellconDetail);

			cellconDetail = new PdfPCell(new Phrase(""));
			cellconDetail.setFixedHeight(18f);
			cellconDetail.setBorderWidth(1f);
			cellconDetail.setBorder(Rectangle.BOTTOM);
			cellconDetail.enableBorderSide(2);
			conSignDetailTable.addCell(cellconDetail);

			cellconDetail = new PdfPCell(new Phrase());
			cellconDetail.setBorder(Rectangle.NO_BORDER);
			cellconDetail.setFixedHeight(18f);
			conSignDetailTable.addCell(cellconDetail);

			cellconDetail = new PdfPCell(new Phrase("Date:", f_TNRNormal_10));
			cellconDetail.setBorder(Rectangle.NO_BORDER);
			cellconDetail.setPaddingTop(5f);
			cellconDetail.setFixedHeight(18f);
			conSignDetailTable.addCell(cellconDetail);
			
			cellconDetail = new PdfPCell(new Phrase());
			cellconDetail.setBorder(Rectangle.BOTTOM);
			cellconDetail.setFixedHeight(18f);
			cellconDetail.setBorderWidth(1f);
			cellconDetail.enableBorderSide(2);
			conSignDetailTable.addCell(cellconDetail);
			
			conSignDetailTable.setSpacingAfter(16f);
			
			
			//****************
			PdfPTable conSign = new PdfPTable(5);
			conSign.setWidthPercentage(110);
			try {
				conSign.setTotalWidth(new float[] { 250, 110, 100, 80, 40  });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			conSign.setLockedWidth(true);

			//Font f_TNRNormal_7 = FontFactory.getFont("TNR_Normal", 7);
			PdfPCell cellConSign = new PdfPCell(new Phrase("Consumer Name (please print)", f_TNRNormal_7));
			cellConSign.setBorder(Rectangle.NO_BORDER);
			cellConSign.setPaddingTop(-0.25f);
			conSign.addCell(cellConSign);
			
			cellConSign = new PdfPCell(new Phrase("Street Address", f_TNRNormal_7));
			cellConSign.setBorder(Rectangle.NO_BORDER);
			cellConSign.setPaddingTop(-0.25f);
			conSign.addCell(cellConSign);
			
			cellConSign = new PdfPCell(new Phrase("City/Town", f_TNRNormal_7));
			cellConSign.setBorder(Rectangle.NO_BORDER);
			cellConSign.setPaddingLeft(20f);
			cellConSign.setPaddingTop(-0.25f);
			conSign.addCell(cellConSign);
			
			cellConSign = new PdfPCell(new Phrase("State", f_TNRNormal_7));
			cellConSign.setBorder(Rectangle.NO_BORDER);
			cellConSign.setPaddingLeft(15f);
			cellConSign.setPaddingTop(-0.25f);
			conSign.addCell(cellConSign);
			
			cellConSign = new PdfPCell(new Phrase("Zip", f_TNRNormal_7));
			cellConSign.setBorder(Rectangle.NO_BORDER);
			cellConSign.setPaddingTop(-0.25f);
			conSign.addCell(cellConSign);
			
			
			
			//****************
			PdfPTable conSign1 = new PdfPTable(1);
			conSign1.setWidthPercentage(110);
			try {
				conSign1.setTotalWidth(new float[] { 580 });

			} catch (DocumentException e1) {
				
				e1.printStackTrace();
			}
			conSign1.setLockedWidth(true);

			//Font f_TNRNormal_7 = FontFactory.getFont("TNR_Normal", 7);
			PdfPCell cellConSign1 = new PdfPCell(new Phrase());
			cellConSign1.setBorder(Rectangle.NO_BORDER);
			//cellConSign1.setFixedHeight(12f);
			cellConSign1.setBorderWidth(1f);
			cellConSign1.enableBorderSide(2);
			//cellPT1.setHorizontalAlignment(Element.ALIGN_RIGHT);
			//cellPT1.setPaddingTop(7.5f);
			conSign1.addCell(cellConSign1);
			
		
			
			
			

			try {
				document.add(cairPageNumTable);
				document.add(revNo);
				document.add(titleTable);
				document.add(lineTitle);
				document.add(checkOneTable);
				document.add(checkOneTable1);
				document.add(checkOneTable2);
				document.add(paraStart);
				document.add(paraStart2);
				document.add(dateTable);
				document.add(paraStartTable1);
				document.add(paraStartTable2);
				document.add(paraStartTable3);
				document.add(paraStartTable4);
				document.add(paraStartTable5);
				document.add(paraStartTable6);
				document.add(pDetail);
				document.add(problemsTable);
				document.add(addInfoTable);
				document.add(addInfoTable1);
				document.add(brkLineSignTable);
				document.add(brkLineDelRepTable);
				document.add(transDetail);
				document.add(brkLineTransTable);
				document.add(TransDetailTable);
				document.add(tableShrPara);
				document.add(tableShrPara1);
				document.add(brkLineSellTable);
				document.add(lineSellDetailTable);
				document.add(tableBusiness);
				document.add(tableBusinessDetail);
				document.add(signPara1);
				document.add(signPara2);
				document.add(conSignDetailTable);
				document.add(conSign1);
				document.add(conSign);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("PDF printed ........................");
		}
}
