package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.createImage;
import static com.chrysler.vbbs.pdf.PdfUtility.createTable;

/**
 * @author 1214662
 * T9450NP 7/16/2018
 */

public class DisclosureNoticeNevada {
    Logger logger = Logger.getLogger(DisclosureNoticeNevada.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {

        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arialbd = BaseFont.createFont("fonts/ARIALBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font arial14bold = new Font(bf_arialbd, 14);
        final Font arial10bold = new Font(bf_arialbd, 10);
        final Font arial7 = new Font(bf_arial, 7);
        final Font arial10 = new Font(bf_arial, 10);
        final Font arial12 = new Font(bf_arial, 12);
        final Font arial8 = new Font(bf_arial, 8);
        final Font courier10 = new Font(bf_courierNew, 10);

        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);


        PdfPTable cairPageNumTable = createTable(3, 100, new float[]{100, 380, 100});
        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);

        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);
        cairPageNumTable.setSpacingAfter(11f);


        PdfPTable titleTable = createTable(4, 100, new float[]{140, 220, 90, 130});
        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase("WARRANTY BUYBACK NOTICE", arial14bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setFixedHeight(15f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("- NEVADA", arial10bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setPaddingTop(6f);
        titleCell.setFixedHeight(1f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", arial7));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);

        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(3.3f);

        PdfPTable checkOneTable = createTable(1, 100, new float[]{580});

        PdfPCell checkOneCell = new PdfPCell(new Phrase("(Check One)", arial12));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        checkOneCell.setLeft(-100);
        checkOneTable.addCell(checkOneCell);
        checkOneTable.setSpacingBefore(10f);
        checkOneTable.setSpacingAfter(1f);

        PdfPTable paraStartTable = createTable(2, 100, new float[]{15, 565});
        paraStartTable.setSpacingAfter(5f);

        PdfPCell paraStartCell = new PdfPCell(new Phrase("", arial12));
        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable.getDefaultCell().setPaddingTop(5);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER);

        paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by FCA US LLC due to the problem(s) listed below.", arial12));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setLeading(13.75f, 0);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);

        PdfPTable paraStartTable1 = createTable(2, 100, new float[]{15, 565});
        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", arial12));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable1.getDefaultCell().setPaddingTop(5);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDERCross);

        paraStartCell1 = new PdfPCell(new Phrase("THIS VEHICLE WAS REPURCHASED BY ITS MANUFACTURER DUE TO A DEFECT IN THE\r\n"
                + "VEHICLE PURSUANT TO CONSUMER WARRANTY LAWS. THE TITLE TO THIS VEHICLE HAS\r\n" + "BEEN PERMANENTLY INSCRIBED WITH THE NOTATION \"LEMON LAW BUYBACK.\" Under Nevada\r\n"
                + "law, the manufacturer must warrant to you, for a one year period, that the vehicle is free of the\r\n" + "problem(s) listed below.", arial12));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setLeading(13.75f, 0);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);

        paraStartTable1.setSpacingAfter(15f);


        PdfPTable tableVehCoreData = createTable(4, 100, new float[]{162, 52, 94, 272});
        PdfPCell c1 = new PdfPCell(new Phrase("V.I.N.", arial10));
        c1.disableBorderSide(2);
        c1.setBorderWidth(1f);
        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Year", arial10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setBorderWidth(1f);
        c1.enableBorderSide(1);
        c1.enableBorderSide(4);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Make", arial10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setBorderWidth(1f);
        c1.enableBorderSide(1);
        c1.enableBorderSide(4);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Model", arial10));
        c1.disableBorderSide(2);
        c1.setBorderWidth(1f);
        c1.setHorizontalAlignment(Element.ALIGN_LEFT);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setHeaderRows(1);
        tableVehCoreData.setSpacingAfter(5f);

        c1 = new PdfPCell(new Phrase(dto.getVin(), courier10));

        c1.setBorderWidth(1f);
        c1.disableBorderSide(1);
        c1.setPaddingBottom(2f);
        c1.setFixedHeight(23f);
        c1.setPaddingTop(0f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getYear(), courier10));
        c1.setBorderWidth(1f);
        c1.disableBorderSide(1);
        c1.setPaddingTop(0f);
        c1.setPaddingBottom(4f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getMake(), courier10));
        c1.setBorderWidth(1f);
        c1.disableBorderSide(1);
        c1.setPaddingTop(0f);
        c1.setPaddingBottom(2f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getModel(), courier10));
        c1.setBorderWidth(1f);
        c1.disableBorderSide(1);
        c1.setPaddingTop(0f);
        c1.setPaddingBottom(2f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setSpacingAfter(11f);


        PdfPTable problemsHeadTable = createTable(2, 100, new float[]{290, 290});
        PdfPCell cellHead = new PdfPCell(new Phrase("                     " + "PROBLEM(S) REPORTED\r\n" + "                      " + "  BY ORIGINAL OWNER", arial12));
        cellHead.setBorderWidth(1f);
        cellHead.setLeading(13.75f, 0);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("                     " + "REPAIRS MADE, IF ANY,\r\n" + "        " + "TO CORRECT REPORTED PROBLEM(S)", arial12));
        cellHead.setBorderWidth(1f);
        cellHead.setLeading(13.75f, 0);
        problemsHeadTable.addCell(cellHead);


        PdfPTable problemsTable = createTable(5, 100, new float[]{15, 275, 0, 15, 275});
        PdfPCell cellPT = new PdfPCell(new Phrase());
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT.setFixedHeight(23f);
        cellPT.setBorderWidth(1f);
        cellPT.setPaddingTop(2f);
        cellPT.enableBorderSide(1);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);

        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(1);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);

        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(1);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(1);
        cellPT.enableBorderSide(4);
        cellPT.setPaddingTop(2f);
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(13);
        cellPT.disableBorderSide(4);

        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(13);
        cellPT.disableBorderSide(4);
        cellPT.disableBorderSide(1);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(13);
        cellPT.disableBorderSide(4);
        cellPT.disableBorderSide(1);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(13);
        cellPT.disableBorderSide(4);
        cellPT.disableBorderSide(1);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorderWidth(1f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(4);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase());
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setBorderWidth(1f);
        cellPT.enableBorderSide(2);
        cellPT.enableBorderSide(4);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        cellPT.enableBorderSide(13);
        cellPT.disableBorderSide(4);
        cellPT.disableBorderSide(1);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(15f);


        PdfPTable MfgSignTable = createTable(3, 100, new float[]{310, 200, 70});
        PdfPCell cellPT1 = new PdfPCell(new Phrase("Signature of Manufacturer", arial12));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        MfgSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase(""));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        MfgSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase("Date", arial12));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        MfgSignTable.addCell(cellPT1);
        MfgSignTable.setSpacingAfter(10f);

        PdfPTable BrkLineMfgSignTable = createTable(3, 100, new float[]{380, 100, 100});

        PdfPCell cellPT11 = new PdfPCell(new Phrase("", arial12));
        cellPT11.setBorder(Rectangle.BOTTOM);
        cellPT11.setBorderWidth(0.75f);
        BrkLineMfgSignTable.addCell(cellPT11);

        cellPT11 = new PdfPCell(new Phrase(""));
        cellPT11.setBorder(Rectangle.NO_BORDER);
        BrkLineMfgSignTable.addCell(cellPT11);

        cellPT11 = new PdfPCell(new Phrase("   " + dto.getCurrentDate(), courier10));
        cellPT11.setBorder(Rectangle.BOTTOM);
        cellPT11.setBorderWidth(0.75f);
        BrkLineMfgSignTable.addCell(cellPT11);
        BrkLineMfgSignTable.setSpacingAfter(5f);

        PdfPTable repSignTable = createTable(3, 100, new float[]{310, 200, 70});

        PdfPCell cellPT32 = new PdfPCell(new Phrase("Signature of Dealer(s)", arial12));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase(""));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase("Date", arial12));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);
        repSignTable.setSpacingAfter(10f);

        PdfPTable retailSignTable = createTable(3, 100, new float[]{310, 200, 70});

        PdfPCell cellPT33 = new PdfPCell(new Phrase("Signature of Retail Buyer or Lessee", arial12));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        retailSignTable.addCell(cellPT33);

        cellPT33 = new PdfPCell(new Phrase(""));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        cellPT33.setBorderWidth(1f);
        retailSignTable.addCell(cellPT33);

        cellPT33 = new PdfPCell(new Phrase("Date", arial12));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        retailSignTable.addCell(cellPT33);
        retailSignTable.setSpacingAfter(10f);

        PdfPTable BrkLineDealerSignTable = createTable(3, 100, new float[]{380, 100, 100});

        PdfPCell cellPT111 = new PdfPCell(new Phrase("", arial12));
        cellPT111.setBorder(Rectangle.BOTTOM);
        cellPT111.setBorderWidth(0.75f);
        BrkLineDealerSignTable.addCell(cellPT111);

        cellPT111 = new PdfPCell(new Phrase(""));
        cellPT111.setBorder(Rectangle.NO_BORDER);
        BrkLineDealerSignTable.addCell(cellPT111);

        cellPT111 = new PdfPCell(new Phrase("  ", courier10));
        cellPT111.setBorder(Rectangle.BOTTOM);
        cellPT111.setBorderWidth(0.75f);
        BrkLineDealerSignTable.addCell(cellPT111);
        BrkLineDealerSignTable.setSpacingAfter(12f);


        try {
            document.add(cairPageNumTable);
            document.add(titleTable);
            document.add(lineTitle);
            document.add(checkOneTable);
            document.add(paraStartTable);
            document.add(paraStartTable1);
            document.add(tableVehCoreData);
            document.add(problemsHeadTable);
            document.add(problemsTable);
            document.add(MfgSignTable);
            document.add(BrkLineMfgSignTable);
            document.add(repSignTable);
            document.add(BrkLineDealerSignTable);
            document.add(BrkLineDealerSignTable);
            document.add(BrkLineDealerSignTable);
            document.add(retailSignTable);
            document.add(BrkLineDealerSignTable);
            document.add(BrkLineDealerSignTable);

        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("###################### PDF Prepared Nevada");

        return document;
    }

    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }

    /**
     * @param columns         number of columns in table
     * @param widthPercentage width percentage
     * @param columnWidths    widths of columns
     * @return table
     *//*
    private PdfPTable createTable(int columns, int widthPercentage, float[] columnWidths) {
        PdfPTable table = new PdfPTable(columns);
        table.setWidthPercentage(widthPercentage);
        try {
            table.setTotalWidth(columnWidths);
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        table.setLockedWidth(true);
        return table;
    }

    *//**
     * @param imgPath   path to image file
     * @param alignment alignment
     * @return created image
     *//*
    private Image createImage(String imgPath, int alignment) {
        Image img = null;
        try {
            img = Image.getInstance(getClass().getResource(imgPath).getPath());
            img.setAlignment(alignment);
        } catch (IOException | BadElementException e1) {
            e1.printStackTrace();
        }
        return img;
    }*/
}
