package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.*;

/**
 * @author 1214662
 * T9450NP 7/16/2018
 */

public class InTransit {
    Logger logger = Logger.getLogger(DisclosureNoticeHawaii.class);

    /**
     * @param dtoData  - Data for the Pdf
     * @param document - The common pdf document object that will be used to add requested pages
     * @return document after adding the necessary pages
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }

    /**
     * @param dto            - Data for the Pdf
     * @param document       - The common pdf document object that will be used to add requested pages
     * @param currentPageNum - Page Number of the document being printed
     * @param totalPages     - Total number of pages
     * @return document after adding a page
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {
        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arial_bold = BaseFont.createFont("fonts/ARIALBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font titleFont = new Font(bf_arial_bold, 18);
        final Font arial7 = new Font(bf_arial, 7);
        final Font arial10 = new Font(bf_arial, 10);
        final Font arial12 = new Font(bf_arial, 12);
        final Font arial11Bold = new Font(bf_arial_bold, 11);
        final Font arial8 = new Font(bf_arial, 8);
        final Font courier10 = new Font(bf_courierNew, 10);
        final Font arial11 = new Font(bf_arial, 11);
        final Font arial10Bold = new Font(bf_arial_bold, 10);

        PdfPTable cairPageNumTable = new PdfPTable(3);
        cairPageNumTable.setWidthPercentage(110);
        try {
            cairPageNumTable.setTotalWidth(new float[]{100, 380, 100});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }
        cairPageNumTable.setLockedWidth(true);
        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);

        cairPageNumTable.setSpacingAfter(11f);

        Image image = null;
        try {
            image = Image.getInstance(getClass().getResource("/images/logo-fca.png").getPath());
        } catch (IOException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }

        PdfPTable titleTable = new PdfPTable(1);
        titleTable.setWidthPercentage(110);
        try {
            titleTable.setTotalWidth(new float[]{500});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        titleTable.setLockedWidth(true);
        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);

        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(200);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);
        titleTable.setSpacingAfter(-5f);


        PdfPTable Disclosure = new PdfPTable(1);
        Disclosure.setWidthPercentage(110);
        try {
        	Disclosure.setTotalWidth(new float[]{500});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        Disclosure.setLockedWidth(true);
        PdfPCell DisclosureCell = new PdfPCell();
        //Disclosure.getDefaultCell().setPaddingLeft(200);
        //Disclosure.getDefaultCell().setPaddingTop(-7);

        DisclosureCell =new PdfPCell(new Phrase("Disclosure Notice", titleFont));
        DisclosureCell.setBorder(Rectangle.NO_BORDER);
        DisclosureCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        
        Disclosure.addCell(DisclosureCell);

       

        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(1f);

        PdfPTable checkOneTable = new PdfPTable(1);
        checkOneTable.setWidthPercentage(110);
        try {
            checkOneTable.setTotalWidth(new float[]{580});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        checkOneTable.setLockedWidth(true);
        PdfPCell checkOneCell = new PdfPCell(new Phrase("This vehicle was repurchased by FCA US LLC from the dealer becuase of", arial12));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        checkOneCell.setLeft(-100);
        checkOneTable.addCell(checkOneCell);
        checkOneTable.setSpacingBefore(1f);
        checkOneTable.setSpacingAfter(10f);

        PdfPTable paraStartTable = new PdfPTable(2);
        paraStartTable.setWidthPercentage(110);
        paraStartTable.setSpacingAfter(5f);
        try {
            paraStartTable.setTotalWidth(new float[]{15, 565});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        Image checkNO_BORDER = null;
        try {
            checkNO_BORDER = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER.setAlignment(Image.ALIGN_LEFT);
        } catch (IOException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }

        Image checkNO_BORDERCross = null;
        try {
            checkNO_BORDERCross = Image.getInstance(getClass().getResource("/images/checkbox-crossed-31x31.png").getPath());
            checkNO_BORDERCross.setAlignment(Image.ALIGN_LEFT);
        } catch (IOException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }

        paraStartTable.setLockedWidth(true);
        PdfPCell paraStartCell = new PdfPCell(new Phrase("", arial12));

        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER);

        paraStartCell = new PdfPCell(new Phrase("Major transportation damage  (damage as discribed in the Warranty Administration Manual in the Warranty Administration chapter in the \"Cliams\" section)", arial12));
        		
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);

        PdfPTable paraStartTable1 = new PdfPTable(2);
        paraStartTable1.setWidthPercentage(110);
        paraStartTable1.setSpacingAfter(10);
        try {
            paraStartTable1.setTotalWidth(new float[]{15, 565});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        paraStartTable1.setLockedWidth(true);
        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", arial12));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDER);

        paraStartCell1 = new PdfPCell(new Phrase("Major repair disclosure", arial12));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.getDefaultCell().setPaddingTop(-50);

        paraStartTable1.addCell(paraStartCell1);
        paraStartTable1.setWidthPercentage(110);
        //paraStartTable1.setSpacingAfter(15f);
        
        PdfPTable paraStartTable2 = new PdfPTable(2);
        paraStartTable2.setWidthPercentage(110);
        paraStartTable2.setSpacingAfter(10f);
        try {
        	paraStartTable2.setTotalWidth(new float[]{15, 565});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        paraStartTable2.setLockedWidth(true);
        PdfPCell paraStartCell2 = new PdfPCell(new Phrase("", arial12));
        paraStartTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable2.addCell(checkNO_BORDER);

        paraStartCell2 = new PdfPCell(new Phrase(" "));
        paraStartCell2.setBorder(Rectangle.NO_BORDER);
        paraStartCell2.enableBorderSide(2);
        paraStartCell2.setBorderWidth(1f);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartCell2.setTop(-500);

        paraStartTable2.addCell(paraStartCell2);
        
        
        PdfPTable paraStartTable3 = new PdfPTable(1);
        paraStartTable3.setWidthPercentage(110);
        try {
        	paraStartTable3.setTotalWidth(new float[]{580});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        paraStartTable3.setLockedWidth(true);
        PdfPCell paraStartCell3 = new PdfPCell(new Phrase("Vehicle Identification Number", arial12));
        paraStartCell3.setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartCell3.setLeft(-100);
        paraStartTable3.addCell(paraStartCell3);
        paraStartTable3.setSpacingBefore(1f);
        paraStartTable3.setSpacingAfter(15f);
        
        PdfPTable fullLineTable2= new PdfPTable(1);
        try {
        	fullLineTable2.setTotalWidth(new float[]{580});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fullLineTable2.setWidthPercentage(110);
        fullLineTable2.setLockedWidth(true);
        //PdfPCell cellPT12 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getAdditionalInfoLine2()), courier10));
        PdfPCell cellPT13=new PdfPCell(new Phrase(""));
        //cellPT13.setMinimumHeight(23f);

        cellPT13.setBorder(Rectangle.NO_BORDER);
        cellPT13.setBorderWidth(1f);
        cellPT13.enableBorderSide(2);
        fullLineTable2.addCell(cellPT13);
        fullLineTable2.setSpacingAfter(6f);

        
        PdfPTable paraStartTable4 = new PdfPTable(6);
        paraStartTable4.setWidthPercentage(110);
        try {
        	paraStartTable4.setTotalWidth(new float[]{60,60,45,115,60,240});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        paraStartTable4.setLockedWidth(true);
        PdfPCell paraStartCell4 = new PdfPCell(new Phrase("Year:", arial12));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        //paraStartCell4.setLeft(-100);
        paraStartTable4.addCell(paraStartCell4);
        
        
        
        paraStartCell4 = new PdfPCell(new Phrase(""));

        paraStartCell4.setBorderWidth(1f);
        //paraStartCell4.setMinimumHeight(23f);
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.enableBorderSide(2);
        paraStartTable4.addCell(paraStartCell4);
        
        paraStartCell4 = new PdfPCell(new Phrase("Make:", arial12));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
        paraStartTable4.addCell(paraStartCell4);
        
        paraStartCell4 = new PdfPCell(new Phrase(""));

        paraStartCell4.setBorderWidth(1f);
        //paraStartCell4.setMinimumHeight(23f);
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.enableBorderSide(2);
        paraStartTable4.addCell(paraStartCell4);
        
        paraStartCell4 = new PdfPCell(new Phrase("Model:", arial12));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_CENTER);
        paraStartTable4.addCell(paraStartCell4);
        //paraStartTable4.setHeaderRows(1);
        
        paraStartCell4 = new PdfPCell(new Phrase(""));
        paraStartCell4.setBorderWidth(1f);
        //paraStartCell4.setMinimumHeight(23f);
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.enableBorderSide(2);
        paraStartTable4.addCell(paraStartCell4);
        
        paraStartTable4.setSpacingBefore(1f);
        paraStartTable4.setSpacingAfter(10f);
        
        
        
        PdfPTable paraStartTable5 = new PdfPTable(4);
        paraStartTable5.setWidthPercentage(110);
        try {
        	paraStartTable5.setTotalWidth(new float[]{130,200,120,130});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }

        paraStartTable5.setLockedWidth(true);
        PdfPCell paraStartCell5 = new PdfPCell(new Phrase("Approximate Amount:", arial12));
        paraStartCell5.setBorder(Rectangle.NO_BORDER);
        paraStartCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        //paraStartCell4.setLeft(-100);
        paraStartTable5.addCell(paraStartCell5);
        
        
        
        paraStartCell5 = new PdfPCell(new Phrase(""));

        paraStartCell5.setBorderWidth(1f);
        //paraStartCell4.setMinimumHeight(23f);
        paraStartCell5.setBorder(Rectangle.NO_BORDER);
        paraStartCell5.enableBorderSide(2);
        paraStartTable5.addCell(paraStartCell5);
        
        paraStartCell5 = new PdfPCell(new Phrase("Odometer Reading:", arial12));
        paraStartCell5.setBorder(Rectangle.NO_BORDER);
        paraStartCell5.setHorizontalAlignment(Element.ALIGN_CENTER);
        paraStartTable5.addCell(paraStartCell5);
        
        paraStartCell5 = new PdfPCell(new Phrase(""));

        paraStartCell5.setBorderWidth(1f);
        //paraStartCell4.setMinimumHeight(23f);
        paraStartCell5.setBorder(Rectangle.NO_BORDER);
        paraStartCell5.enableBorderSide(2);
        paraStartTable5.addCell(paraStartCell5);
        
       
        
        paraStartTable5.setSpacingBefore(1f);
        paraStartTable5.setSpacingAfter(10f);
        
        
        

       
        
        PdfPTable problemsHeadTable = new PdfPTable(2);
        try {
            problemsHeadTable.setTotalWidth(new float[]{290, 290});
        } catch (DocumentException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }
        problemsHeadTable.setWidthPercentage(110);
        problemsHeadTable.setLockedWidth(true);
        PdfPCell cellHead = new PdfPCell(new Phrase("Reported Problem(s):", arial12));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("    " + "Date Repaired or Other Comments:", arial12));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        problemsHeadTable.setSpacingAfter(5f);
        PdfPTable problemsTable = new PdfPTable(5);
        try {
            problemsTable.setTotalWidth(new float[]{15, 260, 30, 15, 260});
        } catch (DocumentException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }

        problemsTable.setWidthPercentage(110);
        problemsTable.setLockedWidth(true);

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setFixedHeight(23f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getProblem1(), courier10));

        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), courier10));

        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getProblem2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
// cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getProblem3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getProblem4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getProblem5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(""));
//cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(15f);

        PdfPTable addInfoTable = new PdfPTable(1);
        try {
            addInfoTable.setTotalWidth(new float[]{580});
        } catch (DocumentException e1) {
            logger.info("document exception: ", e1);
            e1.printStackTrace();
        }
        addInfoTable.setWidthPercentage(110);
        addInfoTable.setLockedWidth(true);
        PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:", arial12));
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        cellAddInfo.setHorizontalAlignment(Element.ALIGN_LEFT);
        cellAddInfo.setLeft(-100);
        addInfoTable.addCell(cellAddInfo);

        
        addInfoTable.setSpacingAfter(15);
        
        PdfPTable fullLineTable = new PdfPTable(1);
        try {
            fullLineTable.setTotalWidth(new float[]{580});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fullLineTable.setWidthPercentage(110);
        fullLineTable.setLockedWidth(true);
        //PdfPCell cellPT12 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getAdditionalInfoLine2()), courier10));
        PdfPCell cellPT12=new PdfPCell(new Phrase(""));
        cellPT12.setBorder(Rectangle.NO_BORDER);
        cellPT12.setBorderWidth(1f);
        cellPT12.enableBorderSide(2);
        fullLineTable.addCell(cellPT12);
        fullLineTable.setSpacingAfter(24f);

        PdfPTable fullLineTable1 = new PdfPTable(1);
        try {
        	fullLineTable1.setTotalWidth(new float[]{580});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fullLineTable1.setWidthPercentage(110);
        fullLineTable1.setLockedWidth(true);
        //PdfPCell cellPT12 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getAdditionalInfoLine2()), courier10));
        PdfPCell cellPT14=new PdfPCell(new Phrase(""));
        cellPT14.setBorder(Rectangle.NO_BORDER);
        cellPT14.setBorderWidth(1f);
        cellPT14.enableBorderSide(2);
        fullLineTable1.addCell(cellPT14);
        fullLineTable1.setSpacingAfter(10f);
//
        //common
        PdfPCell underlineBlankCell = createUnderlineCell();
        PdfPCell blankCell = createClearCell();
        //PdfPCell currentDateCell=new  PdfPCell(new Phrase(""));
       
        PdfPTable fca_zone_signature = new PdfPTable(3);
        try {
        	fca_zone_signature.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        //fca_zone_signature.setWidthPercentage(110);
        fca_zone_signature.setLockedWidth(true);
        // Line 1
        fca_zone_signature.addCell(underlineBlankCell);
        fca_zone_signature.addCell(blankCell);
        fca_zone_signature.addCell(underlineBlankCell);

        // Line 2
        fca_zone_signature.addCell(createSignatoryCell("FCA US LLC ZONE REPRESENTATIVE/TITLE", arial8, Rectangle.ALIGN_CENTER));
        fca_zone_signature.addCell(blankCell);
        fca_zone_signature.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        fca_zone_signature.setSpacingAfter(0f);
        
        
        PdfPTable fca_auction_signature = new PdfPTable(3);
        try {
        	fca_auction_signature.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fca_auction_signature.setWidthPercentage(110);
        fca_auction_signature.setLockedWidth(true);
        // Line 1
        fca_auction_signature.addCell(underlineBlankCell);
        fca_auction_signature.addCell(blankCell);
        fca_auction_signature.addCell(underlineBlankCell);

        // Line 2
        fca_auction_signature.addCell(createSignatoryCell("FCA US LLC AUCTION REPRESENTATIVE/TITLE", arial8, Rectangle.ALIGN_CENTER));
        fca_auction_signature.addCell(blankCell);
        fca_auction_signature.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        //fca_auction_signature.setSpacingAfter(10f);
        
        

        PdfPTable fca_dealer_signature = new PdfPTable(3);
        try {
        	fca_dealer_signature.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fca_dealer_signature.setWidthPercentage(110);
        fca_dealer_signature.setLockedWidth(true);
        // Line 1
        fca_dealer_signature.addCell(underlineBlankCell);
        fca_dealer_signature.addCell(blankCell);
        fca_dealer_signature.addCell(underlineBlankCell);

        // Line 2
        fca_dealer_signature.addCell(createSignatoryCell("DEALER REPRESENTATIVE/TITLE (Printed)", arial8, Rectangle.ALIGN_CENTER));
        fca_dealer_signature.addCell(blankCell);
        fca_dealer_signature.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        fca_dealer_signature.setSpacingAfter(0f);
        
        
        
        PdfPTable fca_dealer_signature1 = new PdfPTable(3);
        try {
        	fca_dealer_signature1.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fca_dealer_signature1.setWidthPercentage(110);
        fca_dealer_signature1.setLockedWidth(true);
        // Line 1
        fca_dealer_signature1.addCell(underlineBlankCell);
        fca_dealer_signature1.addCell(blankCell);
        fca_dealer_signature1.addCell(underlineBlankCell);

        // Line 2
        fca_dealer_signature1.addCell(createSignatoryCell("DEALER REPRESENTATIVE/TITLE (Signed)", arial8, Rectangle.ALIGN_CENTER));
        fca_dealer_signature1.addCell(blankCell);
        fca_dealer_signature1.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        fca_dealer_signature1.setSpacingAfter(10f);
       
        
        PdfPTable bigParaTable = new PdfPTable(1);
        bigParaTable.setWidthPercentage(110);

        try {
            bigParaTable.setTotalWidth(new float[]{580});
        } catch (DocumentException e2) {
            logger.info("document exception: ", e2);
            e2.printStackTrace();
        }
        bigParaTable.setLockedWidth(true);
        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement that disclosure of the above information will be made to the customer with the resale of the vehicle in the state it which it is resold. The dealer must retain a signed copy of this disclosure in the customer file",
                arial10));
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);
        bigParaTable.setSpacingAfter(15f);


        PdfPTable fca_cutomer_signature = new PdfPTable(3);
        try {
        	fca_cutomer_signature.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fca_cutomer_signature.setWidthPercentage(110);
        fca_cutomer_signature.setLockedWidth(true);
        // Line 1
        fca_cutomer_signature.addCell(underlineBlankCell);
        fca_cutomer_signature.addCell(blankCell);
        fca_cutomer_signature.addCell(underlineBlankCell);

        // Line 2
        fca_cutomer_signature.addCell(createSignatoryCell("CUSTOMER ACKONWLEDGEMENT (Printed)", arial8, Rectangle.ALIGN_CENTER));
        fca_cutomer_signature.addCell(blankCell);
        fca_cutomer_signature.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        fca_cutomer_signature.setSpacingAfter(0f);
        
        
        PdfPTable fca_cutomer_signature1 = new PdfPTable(3);
        try {
        	fca_cutomer_signature1.setTotalWidth(new float[]{275,30,275});
        } catch (DocumentException e) {
            logger.info("document exception: ", e);
            e.printStackTrace();
        }
        fca_cutomer_signature1.setWidthPercentage(110);
        fca_cutomer_signature1.setLockedWidth(true);
        // Line 1
        fca_cutomer_signature1.addCell(underlineBlankCell);
        fca_cutomer_signature1.addCell(blankCell);
        fca_cutomer_signature1.addCell(underlineBlankCell);

        // Line 2
        fca_cutomer_signature1.addCell(createSignatoryCell("CUSTOMER ACKONWLEDGEMENT (Signed)", arial8, Rectangle.ALIGN_CENTER));
        fca_cutomer_signature1.addCell(blankCell);
        fca_cutomer_signature1.addCell(createSignatoryCell("DATE", arial8, Rectangle.ALIGN_CENTER));
        fca_cutomer_signature1.setSpacingAfter(0);
        


        //document.add(cairPageNumTable);
        document.add(titleTable);
        document.add(Disclosure);
        document.add(lineTitle);
        document.add(checkOneTable);
        document.add(paraStartTable);
        document.add(paraStartTable1);
        document.add(paraStartTable2);
        
        document.add(paraStartTable3);
        document.add(fullLineTable2);
        document.add(paraStartTable4);
        document.add(paraStartTable5);
        //document.add(tableVehCoreData);
        document.add(problemsHeadTable);
        document.add(problemsTable);
        document.add(addInfoTable);
        document.add(fullLineTable);
        document.add(fullLineTable1);
        document.add(fca_zone_signature);
        document.add(fca_auction_signature);
        document.add(fca_dealer_signature);
        document.add(fca_dealer_signature1);
        document.add(bigParaTable);
        //document.add(dlr_rep_signature);
        document.add(fca_cutomer_signature);
        document.add(fca_cutomer_signature1);

        logger.info("###################### PDF Prepared Hawaii");

        return document;
    }

    /**
     * @param content   - content to be used
     * @param font      - font to be used
     * @param alignment - alignment of text
     * @return cell
     *//*
    private PdfPCell createUnderlineContentCell(String content, Font font, int alignment) {
        PdfPCell contentCell = createUnderlineCell();
        contentCell.setPaddingBottom(4);
        Paragraph contentParagraph = new Paragraph(content.trim(), font);
        contentParagraph.setAlignment(alignment);
        contentCell.addElement(contentParagraph);
        return contentCell;
    }

    *//**
     * @param content   - content to be used
     * @param font      - font to be used
     * @param alignment - alignment of text
     * @return cell
     *//*
    private PdfPCell createSignatoryCell(String content, Font font, int alignment) {
        PdfPCell signatoryCell = createClearCell();
        signatoryCell.setPaddingTop(-2);
        Paragraph signatoryText = new Paragraph(content, font);
        signatoryText.setAlignment(alignment);
        signatoryCell.addElement(signatoryText);
        return signatoryCell;
    }

    *//**
     * Utility method to create a cell with no borders and no content
     *
     * @return clear cell
     *//*
    private PdfPCell createClearCell() {
        PdfPCell clearCell = new PdfPCell(new Paragraph(" "));
        clearCell.setBorder(Rectangle.NO_BORDER);
        return clearCell;
    }

    *//**
     * Utility method to create underlined cell
     *
     * @return underlined cell
     *//*
    private PdfPCell createUnderlineCell() {
        PdfPCell underlineCell = new PdfPCell(new Phrase(" "));
        underlineCell.setBorder(Rectangle.BOTTOM);
        underlineCell.setBorderWidth(1f);
        return underlineCell;
    }

    *//**
     * Utility method to generate signature table template
     *
     * @return Signature table template
     *//*
    private PdfPTable createSignatureTable() {
        PdfPTable signatureTable = new PdfPTable(5);
        signatureTable.setTotalWidth(210 + 65 + 30 + 210 + 65);
        try {
            signatureTable.setWidths(new float[]{210, 65, 30, 210, 65});
        } catch (DocumentException e) {
            logger.info("document exception in createSignatureTable: ", e);
            e.printStackTrace();
        }
        signatureTable.setLockedWidth(true);
        return signatureTable;
    }*/
}
