package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.createFullWidthTable;
import static com.chrysler.vbbs.pdf.PdfUtility.createImage;

/**
 * @author 1214662
 * T9450NP 7/16/2018
 */

public class DisclosureNoticeTexas {
    Logger logger = Logger.getLogger(DisclosureNoticeTexas.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {

        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_times_bd = BaseFont.createFont("fonts/TIMESBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_times = BaseFont.createFont("fonts/TIMES.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font times14bold = new Font(bf_times_bd, 14);
        final Font times9bold = new Font(bf_times_bd, 9);
        final Font times10 = new Font(bf_times, 10);
        final Font times10bold = new Font(bf_times_bd, 10);
        final Font times8 = new Font(bf_times, 8);
        final Font times7 = new Font(bf_times, 7);
        final Font times9 = new Font(bf_times, 9);
        final Font arial10 = new Font(bf_arial, 10);
        final Font arial8 = new Font(bf_arial, 8);
        final Font arial7 = new Font(bf_arial, 7);
        final Font courier10 = new Font(bf_courierNew, 10);

        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);
        // Table 1
        // ********************************************************************************************************************
        PdfPTable cairPageNumTable = createFullWidthTable(3, new float[]{100, 380, 100});

        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        // cairCell.setIndent(-5);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);
        cairPageNumTable.setSpacingAfter(11f);

        // Table 2
        // **************************************************************************************************************************


        PdfPTable titleTable = createFullWidthTable(4, new float[]{100, 355, 55, 70});

        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        // titleCell.setBorderColor(new BaseColor(255,0,0));
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        // titleCell.setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase("REACQUIRED VEHICLE DISCLOSURE STATEMENT", times14bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setFixedHeight(15f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("- TEXAS", times9bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setPaddingTop(6f);
        titleCell.setFixedHeight(7f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", arial7));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);

        // Table 3 draw line start
        // ***************************************************************************************************************************
        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(3.3f);
        // Table 3 draw line start
        // ************************************************************************************************************************

// tableVehCoreData start-by prerana 5/7/2018
// ***************************************************************************************************************************
        PdfPTable tableVehCoreData = createFullWidthTable(8, new float[]{25, 140, 40, 75, 50, 180, 40, 30});

        PdfPCell c1 = new PdfPCell(new Phrase("VIN", times10));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getVin(), times10));// I have given normal font here because texas data for vin gets printed in
        // times new Roman
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MAKE", times10));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getMake(), times10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MODEL", times10));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getModel(), times10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("YEAR", times10));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getYear(), times10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setSpacingAfter(1f);
        tableVehCoreData.setSpacingBefore(5f);

// tableVehCoreData end-by prerana 5/7/2018
// ***************************************************************************************************************************

// tableVehCoreData1 start-by prerana 5/7/2018
// ***************************************************************************************************************************

        PdfPTable tableVehCoreData1 = createFullWidthTable(5, new float[]{27, 254, 180, 50, 70});
        tableVehCoreData1.setWidthPercentage(100);
        tableVehCoreData1.setLockedWidth(true);

        PdfPCell c2 = new PdfPCell(new Phrase("TO:", times10bold));
        c2.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData1.addCell(c2);

        c2 = new PdfPCell(new Phrase("PROSPECTIVE RETAIL PURCHASER(S)", times10bold));
        c2.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData1.addCell(c2);

        c2 = new PdfPCell(new Phrase(" "));
        c2.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData1.addCell(c2);

        c2 = new PdfPCell(new Phrase("Mileage", times10));
        c2.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData1.addCell(c2);

        c2 = new PdfPCell(new Phrase(dto.getCurrentMileage(), times10));
        c2.setBorder(Rectangle.NO_BORDER);
        c2.enableBorderSide(2);
        tableVehCoreData1.addCell(c2);

// tableVehCoreData1 end-by prerana 5/7/2018
// ***************************************************************************************************************************

// paraStartTable -1,2,3,4 start-by prerana 5/7/2018
// ***************************************************************************************************************************			
        PdfPTable paraStartTable = createFullWidthTable(2, new float[]{400, 180});

        PdfPCell paraStartCell = new PdfPCell(new Phrase("FCA US LLC repurchased or replaced the above vehicle pursuant to:", times10));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartTable.addCell(paraStartCell);

        paraStartCell = new PdfPCell(new Phrase(" "));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartTable.addCell(paraStartCell);
        paraStartTable.setSpacingAfter(-5);

        PdfPTable paraStartTable1 = createFullWidthTable(4, new float[]{67, 15, 17, 566});
        paraStartTable1.getDefaultCell().setPaddingTop(5);

        PdfPCell paraStartCell1 = new PdfPCell(new Phrase(" "));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);

        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDER);
        paraStartTable1.setPaddingTop(0f);

        paraStartCell1 = new PdfPCell(new Phrase(""));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);
        paraStartCell1.setPadding(0f);

        paraStartCell1 = new PdfPCell(new Phrase("An effort to promote customer satisfaction", times10));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);
        paraStartCell1.setBorderWidthBottom(2f);
        paraStartCell1.setLeading(11, 0);
        paraStartCell1.setPadding(0);
        paraStartTable1.setSpacingAfter(-6);

        PdfPTable paraStartTable2 = createFullWidthTable(4, new float[]{67, 15, 17, 566});
        paraStartTable2.getDefaultCell().setPaddingTop(5);
        PdfPCell paraStartCell2 = new PdfPCell(new Phrase(""));
        paraStartCell2.setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable2.addCell(paraStartCell2);

        paraStartTable2.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable2.addCell(checkNO_BORDER);
        paraStartCell2.setPadding(0f);

        paraStartCell2 = new PdfPCell(new Phrase(""));
        paraStartCell2.setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable2.addCell(paraStartCell2);

        paraStartCell2 = new PdfPCell(new Phrase("An order of the Texas Motor Vehicle Board to repurchase or replace the vehicle.", times10));
        paraStartCell2.setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable2.addCell(paraStartCell2);
        paraStartTable2.setSpacingAfter(-6);

        PdfPTable paraStartTable3 = createFullWidthTable(4, new float[]{67, 15, 17, 566});
        paraStartTable3.getDefaultCell().setPaddingTop(5);
        PdfPCell paraStartCell3 = new PdfPCell(new Phrase(""));
        paraStartCell3.setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable3.addCell(paraStartCell3);

        paraStartTable3.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable3.addCell(checkNO_BORDERCross);

        paraStartCell3 = new PdfPCell(new Phrase(""));
        paraStartCell3.setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable3.addCell(paraStartCell3);

        paraStartCell3 = new PdfPCell(new Phrase("The Settlement of a Texas lemon law or general warranty complaint.", times10));
        paraStartCell3.setLeading(11, 0);
        paraStartCell3.setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable3.addCell(paraStartCell3);
        paraStartTable3.setSpacingAfter(-6);

        PdfPTable paraStartTable4 = createFullWidthTable(6, new float[]{73, 15, 19, 145, 50, 376});
        paraStartTable4.getDefaultCell().setPaddingTop(5);
        PdfPCell paraStartCell4 = new PdfPCell(new Phrase(""));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(paraStartCell4);

        paraStartTable4.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(checkNO_BORDER);

        paraStartCell4 = new PdfPCell(new Phrase(""));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(paraStartCell4);

        paraStartCell4 = new PdfPCell(new Phrase("A warranty claim or lemon law of", times10));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setLeading(11, 0);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(paraStartCell4);

        paraStartCell4 = new PdfPCell(new Phrase("      ", times10));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.enableBorderSide(2);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(paraStartCell4);

        paraStartCell4 = new PdfPCell(new Phrase(". (Specify State)", times10));
        paraStartCell4.setBorder(Rectangle.NO_BORDER);
        paraStartCell4.setLeading(11, 0);
        paraStartCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable4.addCell(paraStartCell4);

        PdfPTable problemsHeadTable = createFullWidthTable(2, new float[]{290, 290});

        PdfPCell cellHead = new PdfPCell(new Phrase("The original owner or lessee complained of the following defects:", times10));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("        " + "Of the defects listed, the following have been repaired:", times10));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        problemsHeadTable.setSpacingAfter(5f);

        PdfPTable problemsTable = createFullWidthTable(5, new float[]{15, 260, 30, 15, 260});

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", times10));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setFixedHeight(23f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", times10));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", times10));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), times9));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(3f);

//problemsTable end-by prerana 5/7/2018
// ***************************************************************************************************************************

//addInfoTable start-by prerana 5/7/2018
// ***************************************************************************************************************************

        PdfPTable addInfoTable = createFullWidthTable(2, new float[]{100, 480});

        PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:", times10));
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        addInfoTable.addCell(cellAddInfo);

        cellAddInfo = new PdfPCell(new Phrase(dto.getAdditionalInfoLine1(), times10));
        cellAddInfo.setBorderWidth(1f);
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        cellAddInfo.enableBorderSide(2);
        addInfoTable.addCell(cellAddInfo);
        addInfoTable.setSpacingAfter(3f);

        PdfPTable fullLineTable = createFullWidthTable(1, new float[]{580});

        PdfPCell cellPT12 = new PdfPCell(new Phrase(dto.getAdditionalInfoLine2(), times10));
        cellPT12.setBorder(Rectangle.NO_BORDER);
        cellPT12.setBorderWidth(1f);
        cellPT12.enableBorderSide(2);
        fullLineTable.addCell(cellPT12);
        fullLineTable.setSpacingAfter(3f);

        PdfPTable brkLineSignTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT1 = new PdfPCell(new Phrase("                                                                                           " + dto.getCurrentDate(), courier10));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setFixedHeight(18f);
        cellPT1.setBorderWidth(1f);
        cellPT1.enableBorderSide(2);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase(""));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase("                                                                " + " ", courier10));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setBorderWidth(1f);
        cellPT1.setFixedHeight(18f);
        cellPT1.enableBorderSide(2);
        brkLineSignTable.addCell(cellPT1);

        PdfPTable brkLineSignTable1 = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT11 = new PdfPCell(new Phrase("                                                                                           " + dto.getCurrentDate(), courier10));
        cellPT11.setBorder(Rectangle.NO_BORDER);
        cellPT11.setFixedHeight(18f);
        cellPT11.setBorderWidth(1f);
        cellPT11.enableBorderSide(2);
        brkLineSignTable1.addCell(cellPT11);

        cellPT11 = new PdfPCell(new Phrase(""));
        cellPT11.setBorder(Rectangle.NO_BORDER);
        brkLineSignTable1.addCell(cellPT11);

        cellPT11 = new PdfPCell(new Phrase(dto.getAuctionName(), times10));
        cellPT11.setBorder(Rectangle.NO_BORDER);
        cellPT11.setBorderWidth(1f);
        cellPT11.setFixedHeight(18f);
        cellPT11.enableBorderSide(2);
        brkLineSignTable1.addCell(cellPT11);

        PdfPTable repSignTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT32 = new PdfPCell(new Phrase("FCA US LLC Representative Signature/Title" + "                                                   " + "Date", times7));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase(""));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        // cellPT32.setBorderWidth(1f);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase("FCA US LLC Representative Printed Name & Title", times7));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);
        repSignTable.setSpacingAfter(3f);

        PdfPTable repSignTable1 = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT33 = new PdfPCell(new Phrase("Auction Official Signature" + "                                                                                  " + "Date", times7));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        repSignTable1.addCell(cellPT33);

        cellPT33 = new PdfPCell(new Phrase(""));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        repSignTable1.addCell(cellPT33);

        cellPT33 = new PdfPCell(new Phrase("Printed Name of Auction and Auction Official", times7));
        cellPT33.setBorder(Rectangle.NO_BORDER);
        repSignTable1.addCell(cellPT33);
        repSignTable1.setSpacingAfter(3f);


        PdfPTable brkLineDelRepTable = createFullWidthTable(3, new float[]{280, 20, 280});
        PdfPCell cellPrintD = new PdfPCell(new Phrase(" ", times10));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.enableBorderSide(2);
        cellPrintD.setBorderWidth(1f);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(" "));
        cellPrintD.setBorderWidth(1f);
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(""));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.setBorderWidth(1f);
        cellPrintD.enableBorderSide(2);
        brkLineDelRepTable.addCell(cellPrintD);

        PdfPTable printDealerRepTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPrintDR = new PdfPCell(new Phrase("Signature of Dealer Representative, Title                                                     Date", times8));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        cellPrintDR = new PdfPCell(new Phrase(""));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        cellPrintDR = new PdfPCell(new Phrase("Printed Name of Dealer Representative", times8));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        PdfPTable brkLineDealerNameMailingAddressTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellDealerName = new PdfPCell(new Phrase());
        cellDealerName.setBorder(Rectangle.NO_BORDER);
        cellDealerName.enableBorderSide(2);
        cellDealerName.setBorderWidth(1f);
        brkLineDealerNameMailingAddressTable.addCell(cellDealerName);

        cellDealerName = new PdfPCell(new Phrase(" "));
        cellDealerName.setBorderWidth(1f);
        cellDealerName.setBorder(Rectangle.NO_BORDER);
        brkLineDealerNameMailingAddressTable.addCell(cellDealerName);

        cellDealerName = new PdfPCell(new Phrase(""));
        cellDealerName.setBorder(Rectangle.NO_BORDER);
        cellDealerName.setBorderWidth(1f);
        cellDealerName.enableBorderSide(2);
        brkLineDealerNameMailingAddressTable.addCell(cellDealerName);

        PdfPTable DealershipNameMailingAddressTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellDealershipName = new PdfPCell(new Phrase("Dealership Name                                                         Mailing Address", times8));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);

        DealershipNameMailingAddressTable.addCell(cellDealershipName);
        cellDealershipName = new PdfPCell(new Phrase(""));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);
        DealershipNameMailingAddressTable.addCell(cellDealershipName);

        cellDealershipName = new PdfPCell(new Phrase("City/Town                    State              Zip                           Area Code & Phone No.", times8));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);
        DealershipNameMailingAddressTable.addCell(cellDealershipName);
        DealershipNameMailingAddressTable.setSpacingAfter(3f);

        PdfPTable brkLineAcknowledgementTable = createFullWidthTable(5, new float[]{2, 350, 80, 150, 2});

        PdfPCell cellAcknowledgement = new PdfPCell(new Phrase(" "));
        cellAcknowledgement.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgement.enableBorderSide(4);
        brkLineAcknowledgementTable.addCell(cellAcknowledgement);

        cellAcknowledgement = new PdfPCell(new Phrase());
        cellAcknowledgement.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgement.enableBorderSide(2);
        cellAcknowledgement.setBorderWidth(1f);
        brkLineAcknowledgementTable.addCell(cellAcknowledgement);

        cellAcknowledgement = new PdfPCell(new Phrase(" "));
        cellAcknowledgement.setBorder(Rectangle.NO_BORDER);
        brkLineAcknowledgementTable.addCell(cellAcknowledgement);

        cellAcknowledgement = new PdfPCell(new Phrase(""));
        cellAcknowledgement.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgement.enableBorderSide(2);
        cellAcknowledgement.setBorderWidth(1f);
        brkLineAcknowledgementTable.addCell(cellAcknowledgement);

        cellAcknowledgement = new PdfPCell(new Phrase(" "));
        cellAcknowledgement.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgement.enableBorderSide(40);
        brkLineAcknowledgementTable.addCell(cellAcknowledgement);

        PdfPTable AcknowledgementTable = createFullWidthTable(5, new float[]{2, 350, 30, 200, 2});
        PdfPCell cellAcknowledgementName = new PdfPCell(new Phrase(" ", times8));
        cellAcknowledgementName.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgementName.enableBorderSide(4);
        AcknowledgementTable.addCell(cellAcknowledgementName);

        cellAcknowledgementName = new PdfPCell(new Phrase("Acknowledgement/Signature of Retail Buyer                                                                    Printed Name", times7));
        cellAcknowledgementName.setBorder(Rectangle.NO_BORDER);
        AcknowledgementTable.addCell(cellAcknowledgementName);

        cellAcknowledgementName = new PdfPCell(new Phrase(""));
        cellAcknowledgementName.setBorder(Rectangle.NO_BORDER);
        AcknowledgementTable.addCell(cellAcknowledgementName);

        cellAcknowledgementName = new PdfPCell(new Phrase("                                              Date of Delivery", times7));
        cellAcknowledgementName.setBorder(Rectangle.NO_BORDER);
        AcknowledgementTable.addCell(cellAcknowledgementName);

        cellAcknowledgementName = new PdfPCell(new Phrase(" ", times8));
        cellAcknowledgementName.setBorder(Rectangle.NO_BORDER);
        cellAcknowledgementName.enableBorderSide(40);
        AcknowledgementTable.addCell(cellAcknowledgementName);

        PdfPTable brkLineRetailBuyerTable = createFullWidthTable(5, new float[]{2, 350, 80, 150, 2});

        PdfPCell cellRetailBuyer = new PdfPCell(new Phrase(" "));
        cellRetailBuyer.setBorder(Rectangle.NO_BORDER);
        cellRetailBuyer.enableBorderSide(4);
        brkLineRetailBuyerTable.addCell(cellRetailBuyer);

        cellRetailBuyer = new PdfPCell(new Phrase());
        cellRetailBuyer.setBorder(Rectangle.NO_BORDER);
        cellRetailBuyer.enableBorderSide(2);
        cellRetailBuyer.setBorderWidth(1f);
        brkLineRetailBuyerTable.addCell(cellRetailBuyer);

        cellRetailBuyer = new PdfPCell(new Phrase(" "));
        cellRetailBuyer.setBorder(Rectangle.NO_BORDER);
        brkLineRetailBuyerTable.addCell(cellRetailBuyer);

        cellRetailBuyer = new PdfPCell(new Phrase(""));
        cellRetailBuyer.setBorder(Rectangle.NO_BORDER);
        cellRetailBuyer.enableBorderSide(2);
        cellRetailBuyer.setBorderWidth(1f);
        brkLineRetailBuyerTable.addCell(cellRetailBuyer);

        cellRetailBuyer = new PdfPCell(new Phrase(" "));
        cellRetailBuyer.setBorder(Rectangle.NO_BORDER);
        cellRetailBuyer.enableBorderSide(40);
        brkLineRetailBuyerTable.addCell(cellRetailBuyer);


        PdfPTable RetailBuyerTable = createFullWidthTable(5, new float[]{2, 350, 30, 200, 2});
        PdfPCell cellRetailName = new PdfPCell(new Phrase(""));
        cellRetailName.setBorder(Rectangle.NO_BORDER);
        cellRetailName.enableBorderSide(4);
        cellRetailName.enableBorderSide(2);
        RetailBuyerTable.addCell(cellRetailName);

        cellRetailName = new PdfPCell(new Phrase("Retail Buyer's Printed Mailing Address                     City/Town                     State                          Zip ", times7));
        cellRetailName.setBorder(Rectangle.NO_BORDER);
        cellRetailName.enableBorderSide(2);
        RetailBuyerTable.addCell(cellRetailName);

        cellRetailName = new PdfPCell(new Phrase(""));
        cellRetailName.setBorder(Rectangle.NO_BORDER);
        cellRetailName.enableBorderSide(2);
        RetailBuyerTable.addCell(cellRetailName);

        cellRetailName = new PdfPCell(new Phrase("                                      Area Code & Phone Number", times7));
        cellRetailName.setBorder(Rectangle.NO_BORDER);
        cellRetailName.enableBorderSide(2);
        RetailBuyerTable.addCell(cellRetailName);

        cellRetailName = new PdfPCell(new Phrase(""));
        cellRetailName.setBorder(Rectangle.NO_BORDER);
        cellRetailName.enableBorderSide(42);
        RetailBuyerTable.addCell(cellRetailName);

// RetailBuyerTable end -by prerana 5/7/2018
//******************************************************************************************
        PdfPTable bigParaTable = createFullWidthTable(1, new float[]{580});

        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above information will be made to the retail\n" +
                        "customer at the time of sale of this vehicle as provided by law in the state which it is resold.  The dealer agrees to defend, indemnify, and hold\n" +
                        "harmless FCA US LLC from all claims, causes of action, and any other liability arising from or related to the dealer's failure to make proper\n" +
                        "disclosure of the above information, whether or not disclosure is required by state or federal law.  In addition, Texas dealers certify that a\n" +
                        "disclosure decal was affixed to the vehicle at a location approved by the Motor Vehicle Division and that it accompanied the vehicle through the\n" +
                        "first retail purchase.",
                times10));
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaCell.setLeading(11, 0);
        bigParaTable.addCell(bigParaCell);

        PdfPTable bigParaTable1 = createFullWidthTable(3, new float[]{2, 580, 2});

        PdfPCell bigParaCell9 = new PdfPCell(new Phrase(" ", times10));
        bigParaCell9.setBorder(Rectangle.NO_BORDER);
        bigParaCell9.enableBorderSide(4);
        bigParaCell9.enableBorderSide(1);
        bigParaTable1.addCell(bigParaCell9);

        bigParaCell9 = new PdfPCell(new Phrase("I acknowledge that I was informed of the previous repurchase of this vehicle under the lemon law or goodwill policies of\r\n"
                + "FCA US LLC, and that a copy of this disclosure statement was given to me at the time of purchase.", times10));
        bigParaCell9.setBorder(Rectangle.NO_BORDER);
        bigParaCell9.enableBorderSide(1);
        bigParaTable1.addCell(bigParaCell9);

        bigParaCell9 = new PdfPCell(new Phrase(" ", times10));
        bigParaCell9.setBorder(Rectangle.NO_BORDER);
        bigParaCell9.enableBorderSide(41);
        bigParaTable1.addCell(bigParaCell9);

        PdfPTable bigParaTable13 = createFullWidthTable(1, new float[]{580});

        PdfPCell bigParaCell93 = new PdfPCell(new Phrase());
        bigParaCell93.setBorder(Rectangle.NO_BORDER);
        bigParaTable13.addCell(bigParaCell93);
        bigParaTable13.addCell(cellDealershipName);

        PdfPTable bigParaTable2 = createFullWidthTable(1, new float[]{580});
        Chunk chunk4 = new Chunk("NOTE 1: ", times10bold);
        Chunk chunk5 = new Chunk(
                "The manufacturer is required to (1) Affix a Board provided disclosure label to the vehicle: (2) Provide the Board, on transfer of the\n" +
                        "vehicle, in writing, the name, address and telephone number of the transferee, regardless of residence, within 60 days of the transfer; and (3)\n" +
                        "issue a 12 month/12,000 mile basic warranty on the vehicle, except for non-OEM items.",
                times10);
        Chunk chunk6 = new Chunk("  NOTE 2:", times10bold);
        Chunk chunk7 = new Chunk(" The disclosure statement and label\n" +
                "requirement also apply to vehicles reacquired in another state and transferred to Texas for resale.", times10);
        Chunk chunk8 = new Chunk("  NOTE 3:", times10bold);
        Chunk chunk9 = new Chunk(
                " The selling dealer is required to\n" +
                        "return the completed form within 60 days of the retail sale of the vehicle to Texas Department of Transportation, Motor Vehicle Division, P.O.\n" +
                        "Box 2293, Austin, Texas, 78768-2293.",
                times10);

        PdfPCell bigPara21 = new PdfPCell(new Paragraph());
        bigPara21.setCalculatedHeight(10f);

        bigPara21.setBorder(Rectangle.NO_BORDER);
        Paragraph bigPara2 = new Paragraph();
        bigPara2.setLeading(11, 0);
        bigPara2.add(chunk4);
        bigPara2.add(chunk5);
        bigPara2.add(chunk6);
        bigPara2.add(chunk7);
        bigPara2.add(chunk8);
        bigPara2.add(chunk9);

        bigPara2.setAlignment(Element.ALIGN_LEFT);
        bigPara21.addElement(bigPara2);
        bigParaTable2.addCell(bigPara21);

        PdfPTable bigParaTable3 = createFullWidthTable(1, new float[]{580});

        PdfPCell bigParaCell91 = new PdfPCell(new Phrase("FOR MORE INFORMATION, CALL THE MOTOR VEHICLE DIVISION AT 1-800-622-8682 OR (512) 416-4800", times10bold));
        bigParaCell91.setBorder(Rectangle.NO_BORDER);
        bigParaTable3.addCell(bigParaCell91);
        bigParaTable3.setSpacingAfter(5f);

        PdfPTable bigParaTable31 = createFullWidthTable(1, new float[]{580});

        PdfPCell bigParaCell911 = new PdfPCell(new Phrase());
        bigParaCell911.setBorder(Rectangle.NO_BORDER);
        bigParaTable31.addCell(bigParaCell911);
        bigParaTable31.setSpacingAfter(5f);

        try {
            document.add(cairPageNumTable);
            document.add(titleTable);
            document.add(lineTitle);
            document.add(tableVehCoreData);
            document.add(tableVehCoreData1);
            document.add(paraStartTable);
            document.add(paraStartTable1);
            document.add(paraStartTable2);
            document.add(paraStartTable3);
            document.add(paraStartTable4);
            document.add(problemsHeadTable);
            document.add(problemsTable);
            document.add(addInfoTable);
            document.add(fullLineTable);
            document.add(brkLineSignTable);
            document.add(repSignTable);
            document.add(brkLineSignTable1);
            document.add(repSignTable1);
            document.add(bigParaTable);
            document.add(brkLineDelRepTable);
            document.add(printDealerRepTable);
            document.add(brkLineDealerNameMailingAddressTable);
            document.add(DealershipNameMailingAddressTable);
            document.add(bigParaTable1);
            document.add(brkLineAcknowledgementTable);
            document.add(AcknowledgementTable);
            document.add(brkLineRetailBuyerTable);
            document.add(RetailBuyerTable);
            document.add(bigParaTable2);
            document.add(bigParaTable3);
            // document.add(canvas911);
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("###################### PDF Prepared Texas");
        return document;
    }

    /**
     * @param dtoData  - Data for the Pdf
     * @param document - The common pdf document object that will be used to add requested pages
     * @return document after adding the necessary pages
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        java.util.List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }
}
