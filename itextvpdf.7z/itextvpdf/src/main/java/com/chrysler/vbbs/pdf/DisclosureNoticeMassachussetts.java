package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.createImage;
import static com.chrysler.vbbs.pdf.PdfUtility.createTable;
import static com.chrysler.vbbs.pdf.PdfUtility.returnEmptyIfNull;

/**
 * @author 1214662
 * T9450NP 7/16/2018
 * ##FIX
 */

public class DisclosureNoticeMassachussetts {

    Logger logger = Logger.getLogger(DisclosureNoticeMassachussetts.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {

        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arialbd = BaseFont.createFont("fonts/ARIALBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);

        final Font arial14bold = new Font(bf_arialbd, 14);
        final Font arial10bold = new Font(bf_arialbd, 10);
        final Font arial7 = new Font(bf_arial, 7);
        final Font arial10 = new Font(bf_arial, 10);
        final Font arial12 = new Font(bf_arial, 12);
        final Font arial12bold = new Font(bf_arialbd, 12);
        final Font arial11bold = new Font(bf_arialbd, 11);
        final Font arial8 = new Font(bf_arial, 8);
        final Font courier10 = new Font(bf_courierNew, 10);
        final Font arial11 = new Font(bf_arial, 11);

        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);

        PdfPTable cairPageNumTable = createTable(3, 100, new float[]{100, 380, 100});
        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);

        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);
        cairPageNumTable.setSpacingAfter(11f);

        PdfPTable titleTable = createTable(4, 100, new float[]{150, 185, 110, 130});

        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase("RESALE VEHICLE NOTICE", arial14bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setFixedHeight(15f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("- MASSACHUSETTS", arial10bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setPaddingTop(5f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", arial7));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);


        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(3.3f);


        PdfPTable checkOneTable = createTable(1, 100, new float[]{580});

        PdfPCell checkOneCell = new PdfPCell(new Phrase("(Check One)", arial12));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        checkOneCell.setLeft(-100);
        checkOneTable.addCell(checkOneCell);

        PdfPTable paraStartTable = createTable(2, 100, new float[]{15, 565});
        paraStartTable.setSpacingAfter(14f);

        PdfPCell paraStartCell = new PdfPCell(new Phrase("", arial12));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable.getDefaultCell().setPaddingTop(5);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER);

        paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by FCA US LLC due to the problem(s) listed below.", arial12));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setLeading(13.75f, 0);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);
        paraStartTable.setSpacingAfter(1f);

        PdfPTable paraStartTable1 = createTable(2, 100, new float[]{15, 565});

        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", arial12));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable1.getDefaultCell().setPaddingTop(5);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartCell1.setPaddingTop(20f);
        paraStartTable1.addCell(checkNO_BORDERCross);

        Chunk chunk4 = new Chunk("This is a used vehicle.  It was originally sold on ", arial12bold);
        Chunk chunk5 = new Chunk(dto.getVehicleOriginallySoldDate()==null?"                  ":dto.getVehicleOriginallySoldDate(), arial12bold);
        chunk5.setUnderline(0.75f, -1.50f);
        Chunk chunk6 = new Chunk(".  The original owner returned this\n" + "vehicle to the manufacturer because it contained one or more defects which the manufacturer\n"
                + "was unable to repair adequately.  This vehicle is now being resold.", arial12bold);
        paraStartCell1 = new PdfPCell(new Paragraph());

        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        Paragraph bigPara2 = new Paragraph();
        bigPara2.setSpacingBefore(1f);
        bigPara2.add(chunk4);
        bigPara2.add(chunk5);
        bigPara2.add(chunk6);
        bigPara2.setLeading(13.75f);

        bigPara2.setAlignment(Element.ALIGN_LEFT);
        paraStartCell1.addElement(bigPara2);
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable1.addCell(paraStartCell1);

        PdfPTable paraStartTable2 = createTable(1, 100, new float[]{580});
        PdfPCell paraStartCell2 = new PdfPCell(new Phrase("Massachusetts law (M.G.L. c. 90, sec 7N1/2) allows a consumer who buys a new motor vehicle to\r\n"
                + "return the vehicle to its manufacturer if the vehicle has a defect which substantially impairs its use,\r\n"
                + "market value or safety and which is not repaired after a reasonable number of attempts or within a\r\n"
                + "certain period of time. The original owner returned this vehicle to its manufacturer under this law,\r\n" + "complaining of the following defects:", arial12bold));
        paraStartCell2.setBorder(Rectangle.NO_BORDER);
        paraStartCell2.setLeading(13.75f, 0);
        paraStartTable2.addCell(paraStartCell2);

        PdfPTable tableVehCoreData = createTable(8, 100, new float[]{28, 120, 35, 35, 38, 60, 44, 220});
        PdfPCell c1 = new PdfPCell(new Phrase("VIN:", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getVin(), courier10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Year:", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getYear(), courier10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Make:", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getMake(), courier10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("Model:", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getModel(), courier10));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.enableBorderSide(2);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setSpacingBefore(5f);

        PdfPTable problemsHeadTable = createTable(2, 100, new float[]{290, 290});

        PdfPCell cellHead = new PdfPCell(new Phrase(" ", arial11bold));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("Of the defects listed, the following have been repaired:", arial11bold));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        problemsHeadTable.setSpacingAfter(5f);

        PdfPTable problemsTable = createTable(5, 100, new float[]{17, 260, 10, 17, 260});

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT.setMinimumHeight(23f);
        cellPT.setPaddingTop(10f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setPaddingTop(10f);
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setMinimumHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(5f);

        PdfPTable problemsTable2 = createTable(5, 100, new float[]{17, 280, 20, 290, 17});

        PdfPCell cellPT2 = new PdfPCell(new Phrase(" ", arial12));
        cellPT2.setBorder(Rectangle.NO_BORDER);
        cellPT2.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable2.addCell(cellPT2);

        cellPT2 = new PdfPCell(new Phrase(" I ACKNOWLEDGE RECEIPT OF THIS NOTICE.", arial12));
        cellPT2.setBorder(Rectangle.NO_BORDER);
        cellPT2.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT2.setPaddingTop(2f);
        problemsTable2.addCell(cellPT2);

        cellPT2 = new PdfPCell(new Phrase(" ", arial12));
        cellPT2.setBorder(Rectangle.NO_BORDER);
        cellPT2.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable2.addCell(cellPT2);

        cellPT2 = new PdfPCell(new Phrase("PRINT OR TYPE THE INFORMATION BELOW. ", arial12));
        cellPT2.setBorder(Rectangle.NO_BORDER);
        cellPT2.setVerticalAlignment(Element.ALIGN_BOTTOM);

        problemsTable2.addCell(cellPT2);

        cellPT2 = new PdfPCell(new Phrase(" ", arial12));
        cellPT2.setBorder(Rectangle.NO_BORDER);
        cellPT2.setVerticalAlignment(Element.ALIGN_TOP);

        problemsTable2.addCell(cellPT2);

        PdfPTable problemsTable3 = createTable(6, 100, new float[]{17, 40, 240, 20, 280, 17});

        PdfPCell cellPT3 = new PdfPCell(new Phrase(" ", arial12));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT3.setFixedHeight(23f);
        cellPT3.setPaddingTop(2f);
        problemsTable3.addCell(cellPT3);

        cellPT3 = new PdfPCell(new Phrase("DATE:", arial10));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable3.addCell(cellPT3);

        cellPT3 = new PdfPCell(new Phrase(" ", arial12));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.enableBorderSide(2);
        problemsTable3.addCell(cellPT3);

        cellPT3 = new PdfPCell(new Phrase(" ", arial12));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.setVerticalAlignment(Element.ALIGN_TOP);

        problemsTable3.addCell(cellPT3);

        cellPT3 = new PdfPCell(new Phrase("                ", arial12));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.enableBorderSide(2);
        problemsTable3.addCell(cellPT3);

        cellPT3 = new PdfPCell(new Phrase(" ", arial12));
        cellPT3.setBorder(Rectangle.NO_BORDER);
        cellPT3.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable3.addCell(cellPT3);


        PdfPTable problemsTable4 = createTable(6, 100, new float[]{17, 40, 240, 20, 280, 17});

        PdfPCell cellPT4 = new PdfPCell(new Phrase(" ", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.setFixedHeight(23f);
        cellPT4.setPaddingTop(2f);
        problemsTable4.addCell(cellPT4);

        cellPT4 = new PdfPCell(new Phrase(" ", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.setFixedHeight(23f);
        cellPT4.enableBorderSide(2);
        problemsTable4.addCell(cellPT4);

        cellPT4 = new PdfPCell(new Phrase(" ", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.enableBorderSide(2);
        cellPT4.setFixedHeight(23f);
        problemsTable4.addCell(cellPT4);

        cellPT4 = new PdfPCell(new Phrase(" ", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.setFixedHeight(23f);
        problemsTable4.addCell(cellPT4);

        cellPT4 = new PdfPCell(new Phrase("(Buyer's Name)", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setPaddingTop(-1);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.enableBorderSide(2);
        cellPT4.setFixedHeight(23f);
        problemsTable4.addCell(cellPT4);

        cellPT4 = new PdfPCell(new Phrase(" ", arial8));
        cellPT4.setBorder(Rectangle.NO_BORDER);
        cellPT4.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.setFixedHeight(23f);
        cellPT4.setPaddingTop(2f);
        problemsTable4.addCell(cellPT4);
        problemsTable4.setSpacingAfter(1f);

        PdfPTable problemsTable6 = createTable(5, 100, new float[]{17, 280, 20, 280, 17});

        PdfPCell cellPT6 = new PdfPCell(new Phrase(" ", arial12));
        cellPT6.setBorder(Rectangle.NO_BORDER);
        cellPT6.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT6.setFixedHeight(23f);
        cellPT6.setPaddingTop(2f);
        problemsTable6.addCell(cellPT6);

        Chunk chunk = new Chunk("(Buyer's Signature)", arial8);
        chunk.setLineHeight(5f);
        Chunk chunk1 = new Chunk("                                                                                           ", arial8);
        Chunk chunk2 = new Chunk("This notice is required by M.G.L. c. 90, Sec. 7N1/2", arial11);
        Paragraph p1 = new Paragraph();
        p1.add(chunk);
        p1.add(chunk1);
        p1.add(chunk2);

        cellPT6 = new PdfPCell(new Paragraph());
        cellPT6.setBorder(Rectangle.NO_BORDER);
        cellPT6.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT6.setFixedHeight(25f);
        cellPT6.setPaddingTop(2f);
        cellPT6.addElement(p1);
        problemsTable6.addCell(cellPT6);

        cellPT6 = new PdfPCell(new Phrase(" ", arial12));
        cellPT6.setBorder(Rectangle.NO_BORDER);
        cellPT6.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT6.setFixedHeight(23f);
        cellPT6.setPaddingTop(2f);
        problemsTable6.addCell(cellPT6);

        cellPT6 = new PdfPCell(new Phrase("(Street and No.)", arial8));
        cellPT6.setBorder(Rectangle.NO_BORDER);
        cellPT6.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT6.setFixedHeight(23f);
        cellPT4.setPaddingTop(-3);
        cellPT6.enableBorderSide(2);
        problemsTable6.addCell(cellPT6);

        cellPT6 = new PdfPCell(new Phrase(" ", arial12));
        cellPT6.setBorder(Rectangle.NO_BORDER);
        cellPT6.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT6.setFixedHeight(23f);
        cellPT6.setPaddingTop(2f);
        problemsTable6.addCell(cellPT6);


        PdfPTable problemsTable7 = createTable(6, 100, new float[]{17, 40, 240, 20, 280, 17});

        PdfPCell cellPT7 = new PdfPCell(new Phrase(" ", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable7.addCell(cellPT7);

        cellPT7 = new PdfPCell(new Phrase(" ", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable7.addCell(cellPT7);

        cellPT7 = new PdfPCell(new Phrase(" ", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT7.setPaddingTop(2f);
        problemsTable7.addCell(cellPT7);

        cellPT7 = new PdfPCell(new Phrase(" ", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT7.setPaddingTop(2f);
        problemsTable7.addCell(cellPT7);

        cellPT7 = new PdfPCell(new Phrase("(City/Town)", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT4.setPaddingTop(-1);
        problemsTable7.addCell(cellPT7);

        cellPT7 = new PdfPCell(new Phrase(" ", arial8));
        cellPT7.setBorder(Rectangle.NO_BORDER);
        cellPT7.setVerticalAlignment(Element.ALIGN_TOP);
        problemsTable7.addCell(cellPT7);


        PdfPTable paraStartTable3 = createTable(1, 100, new float[]{580});

        PdfPCell paraStartCell3 = new PdfPCell(new Phrase("Massachusetts law entitles you to the name and address of the original owner of this vehicle. You\r\n"
                + "can obtain this information from the seller on request. Note - if less than one year has expired since\r\n"
                + "the date this vehicle was originally sold, and if it has traveled less than 15,000 miles, you as a buyer\r\n"
                + "have warranty and repair rights, also required by M.G.L. c. 90, Sec. 7N1/2. You should contact the\r\n"
                + "Massachusetts Executive Office of Consumer Affairs and Business Regulation for detailed\r\n" + "information on your rights under this law.", arial12bold));
        paraStartCell3.setBorder(Rectangle.NO_BORDER);
        paraStartCell3.setLeading(13.75f, 0);
        paraStartTable3.addCell(paraStartCell3);

        PdfPTable brkLineSignTable = createTable(3, 100, new float[]{280, 20, 280});

        PdfPCell cellPT1 = new PdfPCell(new Phrase("                                   " + dto.getCurrentDate(), arial7));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setVerticalAlignment(Element.ALIGN_TOP);
        cellPT1.setBorderWidth(1f);
        cellPT1.enableBorderSide(2);
        cellPT1.setHorizontalAlignment(Rectangle.ALIGN_RIGHT);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase(""));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase("                                    " + dto.getCurrentDate(), arial7));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setBorderWidth(1f);
        cellPT1.enableBorderSide(2);
        cellPT1.setHorizontalAlignment(Rectangle.ALIGN_RIGHT);
        brkLineSignTable.addCell(cellPT1);

        PdfPTable repSignTable = createTable(3, 100, new float[]{280, 20, 280});

        PdfPCell cellPT32 = new PdfPCell(new Phrase("FCA US LLC Representative Signature" + "                                                   " + "Date", arial8));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase(""));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase("Auction Representative Signature/Title" + "                                                     " + "Date", arial8));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);
        repSignTable.setSpacingAfter(1f);

        PdfPTable brkLineDelRepTable = createTable(3, 100, new float[]{280, 20, 280});

        PdfPCell cellPrintD = new PdfPCell(new Phrase(" ", courier10));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.enableBorderSide(2);
        cellPrintD.setBorderWidth(1f);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(" "));
        cellPrintD.setBorderWidth(1f);
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(""));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.setBorderWidth(1f);
        cellPrintD.enableBorderSide(2);
        brkLineDelRepTable.addCell(cellPrintD);

        PdfPTable printDealerRepTable = createTable(3, 100, new float[]{280, 20, 280});
        PdfPCell cellPrintDR = new PdfPCell(new Phrase("Dealer Representative Signature/Title                                                     Date", arial8));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);

        printDealerRepTable.addCell(cellPrintDR);

        cellPrintDR = new PdfPCell(new Phrase(""));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        cellPrintDR = new PdfPCell(new Phrase("Dealer Representative Printed Name/Title                                  Dealer Code", arial8));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        printDealerRepTable.setSpacingAfter(15f);

        PdfPTable bigParaTable = createTable(1, 100, new float[]{580});

        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above information will be\n" +
                        "made to the retail customer at the time of sale of this vehicle as provided by law in the state in which it is resold.  The dealer\n" +
                        "agrees to defend, indemnify, and hold harmless FCA US LLC from all claims, causes of action, or any other liability arising from or\n" +
                        "related to the dealer's failure to make proper disclosure of the above information, whether or not disclosure is reacquired by state\n" +
                        "or federal law.  FCA US LLC provides a supplemental Limited Warranty for a period of 12 months with unlimited mileage effective\n" +
                        "with the date of purchase or lease of this vehicle by the subsequent retail buyer.  Additionally, this vehicle may be eligible for any\n" +
                        "remaining new vehicle warranty coverage.",
                arial10));
        bigParaCell.setVerticalAlignment(Element.ALIGN_TOP);
        bigParaCell.setLeading(11f, 0);
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);
        bigParaTable.setSpacingAfter(5f);

        try {
            document.add(cairPageNumTable);
            document.add(titleTable);
            document.add(lineTitle);
            document.add(tableVehCoreData);
            document.add(checkOneTable);
            document.add(paraStartTable);
            document.add(paraStartTable1);
            document.add(paraStartTable2);
            document.add(problemsHeadTable);
            document.add(problemsTable);
            document.add(paraStartTable3);
            document.add(problemsTable2);
            document.add(problemsTable3);
            document.add(problemsTable4);
            document.add(problemsTable6);
            document.add(problemsTable7);
            document.add(brkLineSignTable);
            document.add(repSignTable);
            document.add(bigParaTable);
            document.add(brkLineDelRepTable);
            document.add(printDealerRepTable);

        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("###################### PDF Prepared Massachussetts");
        return document;
    }

    /**
     * @param dtoData  - Data for the Pdf
     * @param document - The common pdf document object that will be used to add requested pages
     * @return document after adding the necessary pages
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }

  /*  private PdfPTable createTable(int columns, int widthPercentage, float[] columnWidths) {
        PdfPTable table = new PdfPTable(columns);
        table.setWidthPercentage(widthPercentage);
        try {
            table.setTotalWidth(columnWidths);
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        table.setLockedWidth(true);
        return table;
    }

    private Image createImage(String imgPath, int alignment) {
        Image img = null;
        try {
            img = Image.getInstance(getClass().getResource(imgPath).getPath());
            img.setAlignment(alignment);
        } catch (IOException | BadElementException e1) {
            e1.printStackTrace();
        }
        return img;
    }*/
}
