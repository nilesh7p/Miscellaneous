package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.*;


/**
 * @author TCS
 */

public class DisclosureNoticeUtah {
    Logger logger = Logger.getLogger(DisclosureNoticeUtah.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arialBlack = BaseFont.createFont("fonts/ARIBLK.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arialBold = BaseFont.createFont("fonts/ARIALBD.TTF", "CP1251", BaseFont.EMBEDDED);

        final Font arial12bold = new Font(bf_arialBold, 12);
        final Font arial8 = new Font(bf_arial, 8);
        final Font arial7 = new Font(bf_arial, 7);
        final Font courier10 = new Font(bf_courierNew, 10);
        final Font arialBlack18 = new Font(bf_arialBlack, 18);
        final Font arial10bold = new Font(bf_arialBold, 10);
        final Font courier12 = new Font(bf_courierNew, 12);

        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);

        // Table 1
        PdfPTable cairPageNumTable = createTable(3, 110, new float[]{100, 380, 100});

        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);
        cairPageNumTable.setSpacingAfter(11f);

        // Table 2
        PdfPTable titleTable = createTable(2, 110, new float[]{75, 505});

        PdfPCell titleCell = new PdfPCell();
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(31.5f);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-8);
        titleTable.addCell(image);

        titleCell = new PdfPCell();
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleTable.addCell(titleCell);

        // Table 3 Main table
        PdfPTable mainTable = createTable(1, 100, new float[]{580});
        mainTable.getDefaultCell().setBorderWidth(1.5f);
        mainTable.getDefaultCell().setBorderColor(BaseColor.BLACK);
      /*  PdfPCell mainCell = new PdfPCell(new Phrase(""));
        mainCell.setBorderWidth(1f);
        mainCell.setBorderWidthRight(1.1f);*/

        //Table 4 Child1 veh. Details
        PdfPTable vehDetails = createTable(3, 90, new float[]{115, 345, 100}); //add

        PdfPCell vehDetailsC1 = new PdfPCell(new Phrase(""));
        vehDetailsC1.setBorder(Rectangle.NO_BORDER);
        vehDetails.addCell(vehDetailsC1);

        Chunk c1 = new Chunk("  DISCLOSURE STATEMENT", arialBlack18);
        Chunk c2 = new Chunk(" - UTAH", arial10bold);

        Phrase p = new Phrase();
        p.add(c1);
        p.add(c2);

        vehDetailsC1 = new PdfPCell(p);
        vehDetailsC1.setPaddingTop(1.4f);
        vehDetailsC1.setBorder(Rectangle.NO_BORDER);
        vehDetails.addCell(vehDetailsC1);

        vehDetailsC1 = new PdfPCell(new Phrase("Rev. 06/17 ", arial7));
        vehDetailsC1.setHorizontalAlignment(Element.ALIGN_RIGHT);
        vehDetailsC1.setPaddingTop(15F);
        vehDetailsC1.setBorder(Rectangle.NO_BORDER);
        vehDetails.addCell(vehDetailsC1);

        mainTable.addCell(createClearTableCell(vehDetails, true, false));
        //mainCell.addElement(vehDetails);

        // Table 5 Child2 vin Details
        PdfPTable vehVinDetails = createTable(2, 90, new float[]{200, 380});

        PdfPCell vehDetailVinCell = new PdfPCell(new Phrase("Vehicle Identification Number\n" + "(VIN):", arial12bold));
        vehDetailVinCell.setBorder(Rectangle.NO_BORDER);
        vehDetailVinCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        vehDetailVinCell.setIndent(10f);
        vehVinDetails.addCell(vehDetailVinCell);

        vehDetailVinCell = new PdfPCell(new Phrase("    " + dto.getVin(), courier12));
        vehDetailVinCell.setBorder(Rectangle.NO_BORDER);
        vehDetailVinCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        vehVinDetails.addCell(vehDetailVinCell);
        vehVinDetails.setSpacingAfter(3f);
        mainTable.addCell(createClearTableCell(vehVinDetails, false, false));
        // mainCell.addElement(vehVinDetails);

        //Table 6 Child3 other veh. Details
        PdfPTable vehDetails1 = createTable(6, 90, new float[]{37, 43, 40, 105, 45, 290});

        PdfPCell vehDetailsCell2 = new PdfPCell(new Phrase("Year:", arial12bold));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetails1.addCell(vehDetailsCell2);

        vehDetailsCell2 = new PdfPCell(new Phrase(dto.getYear(), courier10));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell2.enableBorderSide(2);
        vehDetailsCell2.setBorderWidthBottom(0.9f);
        vehDetails1.addCell(vehDetailsCell2);

        vehDetailsCell2 = new PdfPCell(new Phrase("Make:", arial12bold));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetails1.addCell(vehDetailsCell2);

        vehDetailsCell2 = new PdfPCell(new Phrase(dto.getMake(), courier10));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell2.setBorderWidthBottom(0.9f);
        vehDetails1.addCell(vehDetailsCell2);

        vehDetailsCell2 = new PdfPCell(new Phrase("Model:", arial12bold));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetails1.addCell(vehDetailsCell2);

        vehDetailsCell2 = new PdfPCell(new Phrase(dto.getModel(), courier10));
        vehDetailsCell2.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell2.enableBorderSide(2);
        vehDetailsCell2.setBorderWidthBottom(0.9f);

        vehDetails1.addCell(vehDetailsCell2);
        vehDetails1.setSpacingAfter(3f);
        mainTable.addCell(createClearTableCell(vehDetails1, false, false));
        // mainCell.addElement(vehDetails1);

        // Table 7 child4 other det.
        PdfPTable vehDetails2 = createTable(6, 90, new float[]{120, 110, 85, 75, 118, 57});

        PdfPCell vehDetailsCell3 = new PdfPCell(new Phrase(" Prior Title Number:", arial12bold));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetails2.addCell(vehDetailsCell3);

        vehDetailsCell3 = new PdfPCell(new Phrase(dto.getPreviousTitleNumber(), courier10));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell3.enableBorderSide(2);
        vehDetailsCell3.setBorderWidthBottom(1.2f);
        vehDetails2.addCell(vehDetailsCell3);

        vehDetailsCell3 = new PdfPCell(new Phrase("State of Title:", arial12bold));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetails2.addCell(vehDetailsCell3);

        vehDetailsCell3 = new PdfPCell(new Phrase(dto.getPreviousTitle(), courier10));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell3.enableBorderSide(2);
        vehDetailsCell3.setBorderWidthBottom(1.2f);
        vehDetails2.addCell(vehDetailsCell3);

        vehDetailsCell3 = new PdfPCell(new Phrase("Odometer Reading:", arial12bold));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetails2.addCell(vehDetailsCell3);

        vehDetailsCell3 = new PdfPCell(new Phrase(dto.getCurrentMileage(), courier10));
        vehDetailsCell3.setBorder(Rectangle.NO_BORDER);
        vehDetailsCell3.enableBorderSide(2);
        vehDetailsCell3.setBorderWidthBottom(1.2f);
        vehDetails2.addCell(vehDetailsCell3);
        mainTable.addCell(createClearTableCell(vehDetails2, false, false));
        //mainCell.addElement(vehDetails2);

        //Table 8 child 5 Check one
        PdfPTable checkOneTable = createTable(1, 90, new float[]{560});

        PdfPCell checkOneCell = new PdfPCell(new Phrase("(Check One)", arial12bold));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneTable.addCell(checkOneCell);
        checkOneTable.setSpacingBefore(5f);
        checkOneTable.setSpacingAfter(1f);
        mainTable.addCell(createClearTableCell(checkOneTable, false, false));
        //mainCell.addElement(checkOneTable);

        // Table 9 Child 6 check one1
        PdfPTable paraStartTable = createTable(2, 90, new float[]{15, 550});
        paraStartTable.setSpacingAfter(5f);
        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable.addCell(checkNO_BORDER);

        PdfPCell paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by\n"
                + "FCA US LLC due to the problem(s) listed below.", arial12bold));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setLeading(13f, 0);
        paraStartTable.addCell(paraStartCell);
        mainTable.addCell(createClearTableCell(paraStartTable, false, false));
        //mainCell.addElement(paraStartTable);

        //Table 10 child  check one point 2
        PdfPTable paraStartTable1 = createTable(2, 90, new float[]{15, 550});
        paraStartTable1.setSpacingAfter(6f);
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartTable1.addCell(checkNO_BORDERCross);

        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("This is a used motor vehicle. It was previously returned to the manufacturer or its agent in\r\n"
                + "exchange for a replacement motor vehicle or a refund because it was alleged or found to have\r\n"
                + "the following nonconformities", arial12bold));

        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartCell1.setLeading(13f, 0);
        paraStartTable1.addCell(paraStartCell1);
        mainTable.addCell(createClearTableCell(paraStartTable1, false, false));
        //mainCell.addElement(paraStartTable1);

        // Table 9 Reported Prob.
        PdfPTable problemsHeadTable = createTable(2, 90, new float[]{290, 290});

        PdfPCell cellHead = new PdfPCell(new Phrase("Reported Problem(s):", arial12bold));
        cellHead.setBorder(Rectangle.NO_BORDER);
        cellHead.setIndent(10f);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("    " + "  Date Repaired or Other Comments:", arial12bold));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        mainTable.addCell(createClearTableCell(problemsHeadTable, false, false));
        //mainCell.addElement(problemsHeadTable);

        //Table 10 prob. Table
        PdfPTable problemsTable = createTable(5, 90, new float[]{18, 250, 35, 22, 240});

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", arial12bold));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setFixedHeight(23f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setMinimumHeight(23f);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial12bold));
        cellPT.setBorderWidth(1f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setMinimumHeight(23f);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(4f);
        mainTable.addCell(createClearTableCell(problemsTable, false, false));
        //mainCell.addElement(problemsTable);

        // Table for THIS DISCLOSURE para.
        PdfPTable smallParaTable = createTable(1, 110, new float[]{580});

        PdfPCell smallParaCell = new PdfPCell(new Phrase("THIS DISCLOSURE MUST BE GIVEN BY THE SELLER TO THE BUYER EVERY TIME THIS\n" + "VEHICLE IS RESOLD", arial12bold));
        smallParaCell.setLeading(15f, 0);
        smallParaCell.setIndent(10f);
        smallParaCell.setBorder(Rectangle.NO_BORDER);
        smallParaTable.addCell(smallParaCell);
        mainTable.addCell(createClearTableCell(smallParaTable, false, false));
        // mainCell.addElement(smallParaTable);

        // Table add. info.
        PdfPTable addInfoTable = createTable(2, 110, new float[]{160, 400});

        PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:", arial12bold));
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        addInfoTable.addCell(cellAddInfo);

        cellAddInfo = new PdfPCell(new Phrase(dto.getAdditionalInfoLine1(), courier10));
        cellAddInfo.setBorderWidth(1f);
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        cellAddInfo.enableBorderSide(2);
        addInfoTable.addCell(cellAddInfo);
        addInfoTable.setSpacingAfter(6);
        mainTable.addCell(createClearTableCell(addInfoTable, false, false));
        //mainCell.addElement(addInfoTable);

        // Table sign. part 1
        PdfPTable fullLineTable = createTable(1, 90, new float[]{560});

        PdfPCell cellPT12 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getAdditionalInfoLine2()), courier10));
        cellPT12.setBorder(Rectangle.NO_BORDER);
        cellPT12.setBorderWidth(1.05f);
        cellPT12.enableBorderSide(2);
        fullLineTable.addCell(cellPT12);
        mainTable.addCell(createClearTableCell(fullLineTable, false, false));
        //  mainCell.addElement(fullLineTable);

        //Table sign. part 2
        // Init common cells/elements
        PdfPCell underlineBlankCell = createUnderlineCell();
        PdfPCell blankCell = createClearCell();
        PdfPCell currentDateCell = createUnderlineContentCell(dto.getCurrentDate(), arial7, Rectangle.ALIGN_LEFT);
        PdfPCell dateTextCell = createSignatoryCell("Date", arial8, Rectangle.ALIGN_RIGHT);
        dateTextCell.setPaddingRight(10);

        // FCA Representative and Auction Representative
        PdfPTable fca_rep_signature = createSignatureTable();

        // Line 1
        fca_rep_signature.addCell(underlineBlankCell);
        fca_rep_signature.addCell(currentDateCell);
        fca_rep_signature.addCell(blankCell);
        fca_rep_signature.addCell(underlineBlankCell);
        fca_rep_signature.addCell(currentDateCell);

        // Line 2
        fca_rep_signature.addCell(createSignatoryCell("FCA US LLC Representative Signature", arial8, Rectangle.ALIGN_LEFT));
        fca_rep_signature.addCell(dateTextCell);
        fca_rep_signature.addCell(blankCell);
        fca_rep_signature.addCell(createSignatoryCell("Auction Representative Signature/Title", arial8, Rectangle.ALIGN_LEFT));
        fca_rep_signature.addCell(dateTextCell);
        mainTable.addCell(createClearTableCell(fca_rep_signature, false, false));
        // mainCell.addElement(fca_rep_signature);

        //table
        //*****
        PdfPTable bigParaTable = createTable(1, 90, new float[]{560});
        bigParaTable.setSpacingBefore(8f);

        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above\n" +
                        "information will be made to the retail customer at the time of sale of this vehicle as provided by law in the state in\n" +
                        "which it is resold. The dealer agrees to defend, indemnify, and hold harmless FCA US LLC from all claims, causes of\n" +
                        "action, or any other liability arising from or related to the dealer's failure to make proper disclosure of the above\n" +
                        "information, whether or not disclosure is required by state or federal law. FCA US LLC provides a supplemental\n" +
                        "Limited Warranty for a period of 12 months with unlimited mileage effective with the date of purchase or lease of this\n" +
                        "vehicle by the subsequent retail buyer. Additionally, this vehicle may be eligible for any remaining new vehicle\n" +
                        "warranty coverage.", arial10bold));
        bigParaCell.setLeading(12, 0);
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);
        mainTable.addCell(createClearTableCell(bigParaTable, false, false));
        //mainCell.addElement(bigParaTable);

// Dealer Representative and Customer Acknowledgement
        PdfPTable dlr_rep_signature = createSignatureTable();
        dlr_rep_signature.setWidthPercentage(90);
        // Line 1
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(blankCell);
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(underlineBlankCell);

        // Line 2
        dlr_rep_signature.addCell(createSignatoryCell("Dealer Representative Signature/Title", arial8, Rectangle.ALIGN_LEFT));
        dlr_rep_signature.addCell(dateTextCell);
        dlr_rep_signature.addCell(blankCell);
        dlr_rep_signature.addCell(createSignatoryCell("Customer Acknowledgement/Signature", arial8, Rectangle.ALIGN_LEFT));
        dlr_rep_signature.addCell(dateTextCell);
        mainTable.addCell(createClearTableCell(dlr_rep_signature, false, false));
        // mainCell.addElement(dlr_rep_signature);

        // Printed names
        PdfPTable printed_name = createSignatureTable();
        printed_name.setWidthPercentage(90);
        // Line 1
        printed_name.addCell(underlineBlankCell);
        PdfPCell dealerCodeCell = createUnderlineContentCell(dto.getDealerCode(), courier10, Rectangle.ALIGN_RIGHT);
        dealerCodeCell.setPaddingRight(15);
        printed_name.addCell(dealerCodeCell);
        printed_name.addCell(blankCell);
        printed_name.addCell(underlineBlankCell);
        printed_name.addCell(underlineBlankCell);

        // Line 2
        // Dealer Code Text
        PdfPCell dealerCodeTextCell = createClearCell();
        dealerCodeTextCell.setPaddingTop(-2);
        dealerCodeTextCell.setPaddingRight(10);
        Paragraph dealerCodeText = new Paragraph("Dealer Code", arial8);
        dealerCodeText.setAlignment(Rectangle.ALIGN_RIGHT);
        dealerCodeTextCell.addElement(dealerCodeText);

        printed_name.addCell(createSignatoryCell("Printed Name", arial8, Rectangle.ALIGN_LEFT));
        printed_name.addCell(dealerCodeTextCell);
        printed_name.addCell(blankCell);
        printed_name.addCell(createSignatoryCell("Printed Name", arial8, Rectangle.ALIGN_LEFT));
        printed_name.addCell(blankCell);
        mainTable.addCell(createClearTableCell(printed_name, false, false));
        // mainCell.addElement(printed_name);
        // Dealership details table
        PdfPTable dealership_table = createSignatureTable();
        dealership_table.setWidthPercentage(90);

        // Line 1
        dealership_table.addCell(createUnderlineContentCell(CommonUtility.returnEmptyStringIfNull(dto.getDealerName()).trim().concat(","), courier10, Rectangle.ALIGN_LEFT));
        PdfPCell stateCodeCell = createUnderlineContentCell(dto.getDealerState(), courier10, Rectangle.ALIGN_RIGHT);
        stateCodeCell.setPaddingRight(15);
        dealership_table.addCell(stateCodeCell);
        dealership_table.addCell(blankCell);
        dealership_table.addCell(createUnderlineContentCell(" ", courier10, Rectangle.ALIGN_LEFT));
        dealership_table.addCell(createUnderlineContentCell(" ", courier10, Rectangle.ALIGN_LEFT));

        // Line 2
        dealership_table.addCell(createSignatoryCell("Dealership Name", arial8, Rectangle.ALIGN_LEFT));
        PdfPCell stateTextCell = createSignatoryCell("State", arial8, Rectangle.ALIGN_RIGHT);
        stateTextCell.setPaddingRight(10);
        dealership_table.addCell(stateTextCell);
        dealership_table.addCell(blankCell);
        dealership_table.addCell(createSignatoryCell("Street & No.                              City/Town", arial8, Rectangle.ALIGN_LEFT));
        PdfPCell cityTownState = createSignatoryCell("      State", arial8, Rectangle.ALIGN_CENTER);
        dealership_table.addCell(cityTownState);
        mainTable.addCell(createClearTableCell(dealership_table, false, true));
        //mainCell.addElement(dealership_table);

        //  mainTable.addCell(mainCell);


        try {
            document.add(cairPageNumTable);
            document.add(titleTable);
            document.add(mainTable);

        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("###################### PDF Prepared Utah");
        return document;
    }

    private PdfPCell createClearTableCell(PdfPTable table, boolean topBorder, boolean bottomBorder) {
        PdfPCell tableCell = new PdfPCell();
        float borderWidth = 0.8f;
        tableCell.setBorder(Rectangle.NO_BORDER);
        tableCell.enableBorderSide(Rectangle.RIGHT);
        tableCell.setBorderWidthRight(borderWidth);
        tableCell.enableBorderSide(Rectangle.LEFT);
        tableCell.setBorderWidthLeft(borderWidth);

        if (topBorder) {
            tableCell.enableBorderSide(Rectangle.TOP);
            tableCell.setBorderWidthTop(borderWidth);
        }
        if (bottomBorder) {
            tableCell.enableBorderSide(Rectangle.BOTTOM);
            tableCell.setBorderWidthBottom(borderWidth);
        }

        tableCell.addElement(table);
        return tableCell;
    }

    /**
     * @param dtoData  - Data for the Pdf
     * @param document - The common pdf document object that will be used to add requested pages
     * @return document after adding the necessary pages
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }
}
