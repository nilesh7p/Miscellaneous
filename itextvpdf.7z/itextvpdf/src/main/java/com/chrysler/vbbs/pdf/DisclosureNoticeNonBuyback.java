package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;

import static com.chrysler.vbbs.pdf.PdfUtility.createFullWidthTable;
import static com.chrysler.vbbs.pdf.PdfUtility.createImage;

/**
 * @author 474865
 * T9450NP 7/16/2018
 */
public class DisclosureNoticeNonBuyback {
    Logger logger = Logger.getLogger(DisclosureNoticeNonBuyback.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {

        final Font titleFont = new Font(Font.FontFamily.UNDEFINED, 18, Font.BOLD);
        final Font paraFont = new Font(Font.FontFamily.UNDEFINED, 10, Font.NORMAL);
        final Font normalFont = new Font(Font.FontFamily.UNDEFINED, 12, Font.NORMAL);
        final Font smmllFont = new Font(Font.FontFamily.UNDEFINED, 8, Font.NORMAL);
        final Font dataFont = new Font(Font.FontFamily.COURIER, 10, Font.NORMAL);
        final Font smallBold = new Font(Font.FontFamily.UNDEFINED, 12, Font.BOLD);
        final Font cairPageNumFont = new Font(Font.FontFamily.UNDEFINED, 10, Font.NORMAL);
        final Font cairPageNumFont1 = new Font(Font.FontFamily.UNDEFINED, 8, Font.NORMAL);
        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);
        // Table 2
        // **************************************************************************************************************************


        PdfPTable titleTable = createFullWidthTable(3, new float[]{100, 380, 100});

        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        // titleCell.setBorderColor(new BaseColor(255,0,0));
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        // titleCell.setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase("DISCLOSURE NOTICE", titleFont));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setFixedHeight(15f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", new Font(Font.FontFamily.UNDEFINED, 7, Font.NORMAL)));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);

        // Table 3 draw line
        // ***************************************************************************************************************************
        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(3.3f);
        // Table 3
        // ***************************************************************************************************************************

        // Table 4
        // ***************************************************************************************************************************

        PdfPTable checkOneTable = createFullWidthTable(1, new float[]{580});

        PdfPCell checkOneCell = new PdfPCell(new Phrase("(Check One)", normalFont));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        checkOneCell.setLeft(-100);
        checkOneTable.addCell(checkOneCell);
        checkOneTable.setSpacingBefore(10f);
        checkOneTable.setSpacingAfter(10f);

        // Table 4
        // ***************************************************************************************************************************

        PdfPTable paraStartTable = createFullWidthTable(2, new float[]{15, 565});
        paraStartTable.setSpacingAfter(14f);

        PdfPCell paraStartCell = new PdfPCell(new Phrase("", normalFont));
        // paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER);

        paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by FCA US LLC due to the problem(s) listed below.", normalFont));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);

        PdfPTable paraStartTable1 = createFullWidthTable(2, new float[]{15, 565});
        paraStartTable1.setSpacingAfter(25f);

        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", normalFont));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDERCross);

        paraStartCell1 = new PdfPCell(new Phrase("This vehicle was repurchased by FCA US LLC pursuant to consumer warranty laws due to the defect(s)/nonconformity(ies) listed below.", normalFont));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);

        // Table 5
        // ***************************************************************************************************************************

        PdfPTable tableVehCoreData = createFullWidthTable(4, new float[]{162, 52, 93, 270});

        PdfPCell c1 = new PdfPCell(new Phrase("VIN"));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_LEFT);

        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("YEAR"));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MAKE"));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MODEL"));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setHeaderRows(1);


        c1 = new PdfPCell(new Phrase(dto.getVin(), dataFont));
        c1.setBorderWidth(1f);
        c1.setFixedHeight(22f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getYear(), dataFont));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getMake(), dataFont));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getModel(), dataFont));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setSpacingAfter(11f);

        // Table 5
        // ***************************************************************************************************************************
        PdfPTable problemsHeadTable = createFullWidthTable(2, new float[]{290, 290});

        PdfPCell cellHead = new PdfPCell(new Phrase("Reported Problem(s):"));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("    " + "Date Repaired or Other Comments:"));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        problemsHeadTable.setSpacingAfter(5f);


        PdfPTable odometerTable = createFullWidthTable(5, new float[]{115, 160, 30, 210, 60});

        PdfPCell cellodometer = new PdfPCell(new Phrase("Odometer Reading:", normalFont));
        cellodometer.setBorder(Rectangle.NO_BORDER);
        cellodometer.setMinimumHeight(23f);
        odometerTable.addCell(cellodometer);

        cellodometer = new PdfPCell(new Phrase(dto.getOdoMeterReading(), dataFont));
        cellodometer.setBorder(Rectangle.NO_BORDER);
        cellodometer.enableBorderSide(2);
        cellodometer.setMinimumHeight(23f);
        odometerTable.addCell(cellodometer);

        cellodometer = new PdfPCell(new Phrase(""));
        cellodometer.setBorder(Rectangle.NO_BORDER);
        cellodometer.setMinimumHeight(23f);
        odometerTable.addCell(cellodometer);

        cellodometer = new PdfPCell(new Phrase("Factory warranty restriction yes/no"));
        cellodometer.setBorder(Rectangle.NO_BORDER);
        cellodometer.setMinimumHeight(23f);
        odometerTable.addCell(cellodometer);

        cellodometer = new PdfPCell(new Phrase(dto.getWarrentyrestrictionYesOrNo(), dataFont));
        cellodometer.setBorder(Rectangle.NO_BORDER);
        cellodometer.setVerticalAlignment(Element.ALIGN_LEFT);
        cellodometer.setMinimumHeight(23f);
        cellodometer.enableBorderSide(2);
        odometerTable.addCell(cellodometer);

        PdfPTable repairCostTable = createFullWidthTable(5, new float[]{115, 160, 30, 260, 10});

        PdfPCell cellRepairCost = new PdfPCell(new Phrase("Repair Costs", normalFont));
        cellRepairCost.setBorder(Rectangle.NO_BORDER);
        cellRepairCost.setMinimumHeight(23f);
        repairCostTable.addCell(cellRepairCost);

        cellRepairCost = new PdfPCell(new Phrase(dto.getRepairCost(), dataFont));
        cellRepairCost.setBorder(Rectangle.NO_BORDER);
        cellRepairCost.enableBorderSide(2);
        cellRepairCost.setMinimumHeight(23f);
        repairCostTable.addCell(cellRepairCost);

        cellRepairCost = new PdfPCell(new Phrase(""));
        cellRepairCost.setBorder(Rectangle.NO_BORDER);
        cellRepairCost.setMinimumHeight(23f);
        repairCostTable.addCell(cellRepairCost);

        cellRepairCost = new PdfPCell(new Phrase("If yes see additional information below."));
        cellRepairCost.setBorder(Rectangle.NO_BORDER);
        cellodometer.setMinimumHeight(23f);
        repairCostTable.addCell(cellRepairCost);

        cellRepairCost = new PdfPCell(new Phrase(""));
        cellRepairCost.setBorder(Rectangle.NO_BORDER);
        cellRepairCost.setVerticalAlignment(Element.ALIGN_LEFT);
        cellRepairCost.setMinimumHeight(23f);
        repairCostTable.addCell(cellRepairCost);


        PdfPTable problemsTable = createFullWidthTable(5, new float[]{15, 260, 30, 15, 260});

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", cairPageNumFont));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setFixedHeight(23f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", cairPageNumFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", cairPageNumFont));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), dataFont));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(15f);


        PdfPTable addInfoTable = createFullWidthTable(2, new float[]{130, 450});

        PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:"));
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        addInfoTable.addCell(cellAddInfo);

        cellAddInfo = new PdfPCell(new Phrase(dto.getAdditionalInfoLine1() + dto.getAdditionalInfoLine2(), dataFont));
        cellAddInfo.setBorderWidth(1f);
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        cellAddInfo.enableBorderSide(2);
        addInfoTable.addCell(cellAddInfo);
        addInfoTable.setSpacingAfter(25f);

        PdfPTable fullLineTable = createFullWidthTable(1, new float[]{580});

        PdfPCell cellPT12 = new PdfPCell(new Phrase(""));
        cellPT12.setBorder(Rectangle.NO_BORDER);
        cellPT12.setBorderWidth(1f);
        cellPT12.enableBorderSide(2);
        fullLineTable.addCell(cellPT12);
        fullLineTable.setSpacingAfter(20f);


        PdfPTable brkLineSignTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT1 = new PdfPCell(new Phrase("                                   " + dto.getCurrentDate(), dataFont));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setFixedHeight(18f);
        cellPT1.setBorderWidth(1f);
        cellPT1.enableBorderSide(2);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase(""));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        brkLineSignTable.addCell(cellPT1);

        cellPT1 = new PdfPCell(new Phrase("                                    " + dto.getCurrentDate(), dataFont));
        cellPT1.setBorder(Rectangle.NO_BORDER);
        cellPT1.setBorderWidth(1f);
        cellPT1.setFixedHeight(18f);
        cellPT1.enableBorderSide(2);
        brkLineSignTable.addCell(cellPT1);

        PdfPTable repSignTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPT32 = new PdfPCell(new Phrase("FCA US LLC Representative Signature" + "                                                   " + "Date", smmllFont));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase(""));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);

        cellPT32 = new PdfPCell(new Phrase("Auction Representative Signature/Title" + "                                                     " + "Date", smmllFont));
        cellPT32.setBorder(Rectangle.NO_BORDER);
        repSignTable.addCell(cellPT32);
        repSignTable.setSpacingAfter(12f);


        PdfPTable brkLinePrintNameTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPrintN = new PdfPCell(new Phrase("                                      " + "", dataFont));
        cellPrintN.setBorder(Rectangle.NO_BORDER);
        cellPrintN.enableBorderSide(2);
        cellPrintN.setBorderWidth(1f);
        brkLinePrintNameTable.addCell(cellPrintN);

        cellPrintN = new PdfPCell(new Phrase(" "));
        cellPrintN.setBorderWidth(1f);
        cellPrintN.setBorder(Rectangle.NO_BORDER);
        brkLinePrintNameTable.addCell(cellPrintN);

        cellPrintN = new PdfPCell(new Phrase(""));
        cellPrintN.setBorder(Rectangle.NO_BORDER);
        cellPrintN.setBorderWidth(1f);
        cellPrintN.enableBorderSide(2);
        brkLinePrintNameTable.addCell(cellPrintN);

        PdfPTable printNameTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPrintName = new PdfPCell(new Phrase("Printed Name                                                                                Dealer Code", smmllFont));
        cellPrintName.setBorder(Rectangle.NO_BORDER);

        printNameTable.addCell(cellPrintName);
        cellPrintName = new PdfPCell(new Phrase(""));
        cellPrintName.setBorder(Rectangle.NO_BORDER);
        printNameTable.addCell(cellPrintName);

        cellPrintName = new PdfPCell(new Phrase("Printed Name", smmllFont));
        cellPrintName.setBorder(Rectangle.NO_BORDER);
        printNameTable.addCell(cellPrintName);

        printNameTable.setSpacingAfter(15f);
        // Table 9*************************************************

        PdfPTable brkLineDelRepTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPrintD = new PdfPCell(new Phrase(" ", dataFont));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.enableBorderSide(2);
        cellPrintD.setBorderWidth(1f);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(" "));
        cellPrintD.setBorderWidth(1f);
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        brkLineDelRepTable.addCell(cellPrintD);

        cellPrintD = new PdfPCell(new Phrase(""));
        cellPrintD.setBorder(Rectangle.NO_BORDER);
        cellPrintD.setBorderWidth(1f);
        cellPrintD.enableBorderSide(2);
        brkLineDelRepTable.addCell(cellPrintD);

        PdfPTable printDealerRepTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellPrintDR = new PdfPCell(new Phrase("Dealer Representative Signature/Title                                                     Date", smmllFont));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);

        printDealerRepTable.addCell(cellPrintDR);
        cellPrintDR = new PdfPCell(new Phrase(""));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        cellPrintDR = new PdfPCell(new Phrase("Customer Acknowledgement/Signature                                                 Date", smmllFont));
        cellPrintDR.setBorder(Rectangle.NO_BORDER);
        printDealerRepTable.addCell(cellPrintDR);

        printDealerRepTable.setSpacingAfter(15f);

        // Table 10*************************************************
        PdfPTable brkLineDealerNameTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellDealerN = new PdfPCell(new Phrase("" + "                       " + "", dataFont));
        cellDealerN.setBorder(Rectangle.NO_BORDER);
        cellDealerN.enableBorderSide(2);
        cellDealerN.setBorderWidth(1f);
        brkLineDealerNameTable.addCell(cellDealerN);

        cellDealerN = new PdfPCell(new Phrase(" "));
        cellDealerN.setBorder(Rectangle.NO_BORDER);
        brkLineDealerNameTable.addCell(cellDealerN);

        cellDealerN = new PdfPCell(new Phrase(""));
        cellDealerN.setBorder(Rectangle.NO_BORDER);
        cellDealerN.enableBorderSide(2);
        cellDealerN.setBorderWidth(1f);
        brkLineDealerNameTable.addCell(cellDealerN);

        PdfPTable dealershipTable = createFullWidthTable(3, new float[]{280, 20, 280});

        PdfPCell cellDealershipName = new PdfPCell(new Phrase("Dealership Name                                                                                    State", smmllFont));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);
        dealershipTable.addCell(cellDealershipName);
        cellDealershipName = new PdfPCell(new Phrase(""));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);
        dealershipTable.addCell(cellDealershipName);

        cellDealershipName = new PdfPCell(new Phrase("Street & No.                                                                City or Town and State", smmllFont));
        cellDealershipName.setBorder(Rectangle.NO_BORDER);

        dealershipTable.addCell(cellDealershipName);
        dealershipTable.setSpacingAfter(15f);

        PdfPTable bigParaTable = createFullWidthTable(1, new float[]{580});

        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above information will be made to the retail customer at the time of sale of this vehicle as provided by law in the state in which it is resold. The dealer agrees to defend, indemnify, and hold harmless FCA US LLC from all claims, causes of action, or any other liability arising from or related to the dealer's failure to make proper disclosure of the above information, whether or not disclosure is required by state or federal law. FCA US LLC provides a supplemental Limited Warranty for a period of 12 months with unlimited mileage effective with the date of purchase or lease of this vehicle by the subsequent retail buyer. Additionally, this vehicle may be eligible for any remaining new vehicle warranty coverage.",
                paraFont));
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);
        bigParaTable.setSpacingAfter(25f);

        try {
            document.add(titleTable);
            document.add(lineTitle);
            document.add(checkOneTable);
            document.add(paraStartTable);
            document.add(paraStartTable1);
            document.add(tableVehCoreData);
            document.add(odometerTable);
            document.add(repairCostTable);
            document.add(problemsHeadTable);
            document.add(problemsTable);
            document.add(addInfoTable);
            document.add(fullLineTable);
            document.add(brkLineSignTable);
            document.add(repSignTable);
            document.add(bigParaTable);
            document.add(brkLineDelRepTable);
            document.add(printDealerRepTable);
            document.add(brkLinePrintNameTable);
            document.add(printNameTable);
            document.add(brkLineDealerNameTable);
            document.add(dealershipTable);

        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("###################### PDF Prepared NonBuyback");
        return document;
    }

    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws DocumentException, IOException {
        return createPage(dtoData, document, 1, 1);
    }

}
