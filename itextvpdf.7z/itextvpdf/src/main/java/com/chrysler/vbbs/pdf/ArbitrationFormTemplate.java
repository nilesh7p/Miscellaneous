package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import org.apache.log4j.Logger;

import java.io.IOException;

import static com.chrysler.vbbs.pdf.PdfUtility.createClearCell;
import static com.chrysler.vbbs.pdf.PdfUtility.createUnderlineCell;

/**
 * @author TCS
 */
public class ArbitrationFormTemplate {
    Logger logger = Logger.getLogger(ArbitrationFormTemplate.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document) throws DocumentException, IOException {
        BaseFont bf_courier = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_times = BaseFont.createFont("fonts/TIMES.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_times_bold = BaseFont.createFont("fonts/TIMESBD.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font times11Bold = new Font(bf_times_bold, 11);
        final Font times11 = new Font(bf_times, 11);
        final Font times9Bold = new Font(bf_times_bold, 8);
        final Font times12NormalBlue = new Font(bf_times, 12, Font.NORMAL, BaseColor.BLUE);
        final Font courier10 = new Font(bf_courier, 10);

        final String pageHeaderText = "THIS CONTRACT HAS A BINDING ARBITRATION PROVISION";
        final String pageSubHeaderText = "VEHICLE DISPUTE RESOLUTION PROCESS – BINDING ARBITRATION";
        final String vinFullText = "Vehicle Identification Number:";
        final String paragraph_1_Text = "THE CUSTOMER UNDERSTANDS THAT HE/SHE HAS A RIGHT TO HAVE ANY DISPUTES DECIDED\n"
                + "IN COURT BUT HAS AGREED TO HAVE ANY SUCH DISPUTE DETERMINED BY ARBITRATION IN\n" + "ORDER TO AVOID THE BURDEN, EXPENSE AND UNCERTAINTY OF THE JUDICIAL PROCESS.\n"
                + "ARBITRATION IS A PROCESS BY WHICH TWO OR MORE PARTIES RESOLVE A DISPUTE THROUGH\n" + "THE USE OF A THIRD PARTY NEUTRAL.";
        final String paragraph_2_Text_part1 = "AS A CONDITION OF SALE, THE DEALER, THE AUCTION REPRESENTATIVE AND THE RETAIL\n"
                + "CUSTOMER AGREE THAT BINDING ARBITRATION IS THE SOLE AND EXCLUSIVE REMEDY FOR\n" + "ANY DISPUTE, CONTROVERSY OR CLAIM ARISING OUT OF OR RELATING TO THIS VEHICLE.\n"
                + "THIS INCLUDES, BUT IS NOT LIMITED TO CLAIMS ARISING UNDER THE SUPPLEMENTAL LIMITED\n" + "WARRANTY, ANY REMAINING WARRANTY COVERAGE OR FAILURE TO MAKE PROPER\n"
                + "DISCLOSURE OF THE VEHICLE’S HISTORY.";
        final String paragraph_2_Text_Bold = " YOU MAY NOT BRING A SEPARATE LAWSUIT.\n";
        final String paragraph_2_Text_part2 = "PERSONAL INJURY OR OTHER PRODUCT LIABILITY SUITS ARE NOT SUBJECT TO THIS PROCESS.";

        final String paragraph_3_Text_part1 = "QUALIFYING CLAIMS WILL BE ADMINISTERED BY THE NATIONAL CENTER FOR DISPUTE\n"
                + "SETTLEMENT.  A COPY OF THE RULES ARE AVAILABLE BY CALLING 1-800-777-8119 OR AT\n";
        final String paragraph_3_Link = "WWW.NCDSUSA.ORG";
        final String paragraph_3_text_part2 = ".  BY AGREEING TO ARBITRATE, A PARTY FORGOES NO SUBSTANTIVE\n" + "RIGHTS. POTENTIAL RECOVERY IS THE SAME AS THAT AVAILABLE UNDER RELEVANT STATE\n"
                + "AND FEDERAL LAWS, AND THE ARBITRATORS HAVE DISCRETION TO AWARD REASONABLE\n" + "AND CUSTOMARY ATTORNEY AND EXPERT WITNESS FEES. JUDGMENT ON THE AWARD OF\n"
                + "THE ARBITRATOR MAY BE ENTERED IN ANY COURT OF COMPETENT JURISDICTION.";
        final String paragraph_4_Text = "THE CUSTOMER ACKNOWLEDGES THAT THE PRICE ESTABLISHED FOR THE VEHICLE REFLECTS:";
        final String paragraph_5_Text = "(1) THE SUPPLEMENTAL LIMITED WARRANTY PROVIDED BY FCA US LLC (2) ANY REMAINING\n" + "WARRANTY COVERAGE (3) THE PRECEEDING DISCLOSURES AND (4) THE POTENTIAL\n"
                + "REDUCTION IN LEGAL COSTS RESULTING FROM THE AGREEMENT TO ARBITRATE.";
        final String paragraph_6_Text = "THE CUSTOMER FURTHER ACKNOWLEDGES THAT THIS TRANSACTION AFFECTS INTERSTATE\n"
                + "COMMERCE AND IS GOVERNED BY THE FEDERAL ARBITRATION ACT. THIS IS A KNOWING AND\n" + "WILLING WAIVER OF ANY RIGHT TO A JURY TRIAL OR OTHER JUDICIAL OR ADMINISTRATIVE\n"
                + "DETERMINATION.";

        // Header
        Paragraph pageHeader = new Paragraph(pageHeaderText, times11Bold);
        pageHeader.setAlignment(Element.ALIGN_CENTER);
        pageHeader.setSpacingAfter(10);

        // Sub Header
        Chunk subHeaderChunk = new Chunk(pageSubHeaderText);
        subHeaderChunk.setUnderline(0.5f, -1.5f);
        subHeaderChunk.setFont(times11);
        Paragraph pageSubHeader = new Paragraph(subHeaderChunk);
        pageSubHeader.setAlignment(Element.ALIGN_CENTER);
        pageSubHeader.setSpacingAfter(7);

        // VIN Num
        PdfPTable vinTable = new PdfPTable(3);
        vinTable.setTotalWidth(new float[]{150, 200, 200});
        vinTable.setLockedWidth(true);

        Paragraph p = new Paragraph(vinFullText, times11);
        p.setAlignment(Rectangle.ALIGN_RIGHT);
        PdfPCell vinDesc = new PdfPCell(p);
        vinDesc.setBorder(Rectangle.NO_BORDER);
        vinDesc.setPaddingLeft(5);

        PdfPCell vinNum = new PdfPCell(new Phrase(dto.getVin(), times11));
        vinNum.setBorder(Rectangle.NO_BORDER);
        vinNum.setBorderWidthBottom(1);

        PdfPCell blank = new PdfPCell(new Phrase());
        blank.setBorder(Rectangle.NO_BORDER);

        vinTable.addCell(vinDesc);
        vinTable.addCell(vinNum);
        vinTable.addCell(blank);
        vinTable.setSpacingAfter(7);

        // Paragraph 1
        Paragraph paragraph_1 = new Paragraph(paragraph_1_Text, times11);
        paragraph_1.setAlignment(Element.ALIGN_LEFT);
        paragraph_1.setLeading(13);
        paragraph_1.setSpacingAfter(10);

        // paragraph 2
        Paragraph paragraph_2 = new Paragraph();
        Chunk paragraph_2_chunk_1 = new Chunk(paragraph_2_Text_part1, times11);
        Chunk paragraph_2_chunk_2 = new Chunk(paragraph_2_Text_Bold, times11Bold);
        Chunk paragraph_2_chunk_3 = new Chunk(paragraph_2_Text_part2, times11);
        paragraph_2.add(paragraph_2_chunk_1);
        paragraph_2.add(paragraph_2_chunk_2);
        paragraph_2.add(paragraph_2_chunk_3);
        paragraph_2.setAlignment(Element.ALIGN_LEFT);
        paragraph_2.setLeading(13);
        paragraph_2.setSpacingAfter(10);

        // Paragraph 3
        Paragraph paragraph_3 = new Paragraph();
        Chunk paragraph_3_chunk_1 = new Chunk(paragraph_3_Text_part1, times11);
        Chunk paragraph_3_chunk_2 = new Chunk(paragraph_3_Link, times12NormalBlue).setUnderline(0.1f, -2);
        Chunk paragraph_3_chunk_3 = new Chunk(paragraph_3_text_part2, times11);
        paragraph_3.add(paragraph_3_chunk_1);
        paragraph_3.add(paragraph_3_chunk_2);
        paragraph_3.add(paragraph_3_chunk_3);
        paragraph_3.setAlignment(Element.ALIGN_LEFT);
        paragraph_3.setLeading(13);
        paragraph_3.setSpacingAfter(10);

        // Paragraph 4
        Paragraph paragraph_4 = new Paragraph(paragraph_4_Text, times11);
        paragraph_4.setAlignment(Element.ALIGN_LEFT);
        paragraph_4.setSpacingAfter(10);
        paragraph_4.setLeading(13);

        // Paragraph 5
        Paragraph paragraph_5 = new Paragraph(paragraph_5_Text, times11);
        paragraph_5.setAlignment(Element.ALIGN_LEFT);
        paragraph_5.setSpacingAfter(10);
        paragraph_5.setLeading(13);

        // Paragraph 6
        Paragraph paragraph_6 = new Paragraph(paragraph_6_Text, times11);
        paragraph_6.setAlignment(Element.ALIGN_LEFT);
        paragraph_6.setSpacingAfter(40);
        paragraph_6.setLeading(13);

        // Signatures Section
        float topPadding = -5.0f;
        float[] colWidths = new float[]{220, 40, 16, 220, 40};
        // line 1
        PdfPTable signaturesTable_1 = new PdfPTable(5);
        signaturesTable_1.setTotalWidth(536);
        signaturesTable_1.setWidths(colWidths);
        signaturesTable_1.setLockedWidth(true);

        signaturesTable_1.addCell(createUnderlineCell());
        signaturesTable_1.addCell(createUnderlineCell());
        signaturesTable_1.addCell(createClearCell());
        signaturesTable_1.addCell(createUnderlineCell());
        signaturesTable_1.addCell(createUnderlineCell());

        PdfPCell cell = createClearCell();
        Paragraph paragraph = new Paragraph("DEALER/REPRESENTATIVE SIGNATURE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_1.addCell(cell);

        cell = createClearCell();
        paragraph = new Paragraph("DATE", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_1.addCell(cell);
        signaturesTable_1.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("CUSTOMER SIGNATURE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_1.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("DATE", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_1.addCell(cell);
        signaturesTable_1.setSpacingAfter(25);

        // line 2
        PdfPTable signaturesTable_2 = new PdfPTable(5);
        signaturesTable_2.setTotalWidth(536);
        signaturesTable_2.setWidths(colWidths);
        signaturesTable_2.setLockedWidth(true);

        signaturesTable_2.addCell(createUnderlineCell());
        signaturesTable_2.addCell(createUnderlineCell());
        signaturesTable_2.addCell(createClearCell());
        signaturesTable_2.addCell(createUnderlineCell());
        signaturesTable_2.addCell(createUnderlineCell());

        cell = createClearCell();
        paragraph = new Paragraph("PRINTED NAME AND TITLE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_2.addCell(cell);

        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_2.addCell(cell);
        signaturesTable_2.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("PRINTED NAME", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_2.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_2.addCell(cell);

        // line 3
        PdfPTable signaturesTable_3 = new PdfPTable(5);
        signaturesTable_3.setTotalWidth(536);
        signaturesTable_3.setWidths(colWidths);
        signaturesTable_3.setLockedWidth(true);

        cell = createUnderlineCell();
        cell.setColspan(2);
        cell.addElement(new Paragraph(dto.getDealerName(), courier10));
        signaturesTable_3.addCell(cell);
        signaturesTable_3.addCell(createClearCell());
        signaturesTable_3.addCell(createUnderlineCell());
        signaturesTable_3.addCell(createUnderlineCell());

        cell = createClearCell();
        paragraph = new Paragraph("DEALERSHIP NAME", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_3.addCell(cell);

        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_3.addCell(cell);
        signaturesTable_3.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("ADDRESS", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_3.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_3.addCell(cell);

        // line 4
        PdfPTable signaturesTable_4 = new PdfPTable(5);
        signaturesTable_4.setTotalWidth(536);
        signaturesTable_4.setWidths(colWidths);
        signaturesTable_4.setLockedWidth(true);

        cell = createUnderlineCell();
        cell.setColspan(2);
        cell.addElement(new Paragraph(dto.getDealerCode() + " - " + dto.getDealerCity() + ", " + dto.getDealerState() + " " + dto.getDealerZip(), courier10));
        signaturesTable_4.addCell(cell);
        signaturesTable_4.addCell(createClearCell());
        signaturesTable_4.addCell(createUnderlineCell());
        signaturesTable_4.addCell(createUnderlineCell());

        cell = createClearCell();
        paragraph = new Paragraph("DEALER CODE AND CITY, STATE AND ZIP", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        cell.setColspan(2);
        signaturesTable_4.addCell(cell);

        signaturesTable_4.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("CUSTOMER CITY, STATE AND ZIP CODE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_4.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_4.addCell(cell);
        signaturesTable_4.setSpacingAfter(25);

        // line 5
        PdfPTable signaturesTable_5 = new PdfPTable(5);
        signaturesTable_5.setTotalWidth(536);
        signaturesTable_5.setWidths(colWidths);
        signaturesTable_5.setLockedWidth(true);

        signaturesTable_5.addCell(createUnderlineCell());
        signaturesTable_5.addCell(createUnderlineCell());
        signaturesTable_5.addCell(createClearCell());
        signaturesTable_5.addCell(createClearCell());
        signaturesTable_5.addCell(createClearCell());

        cell = createClearCell();
        paragraph = new Paragraph("AUCTION REPRESENTATIVE SIGNATURE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_5.addCell(cell);

        cell = createClearCell();
        paragraph = new Paragraph("DATE", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_5.addCell(cell);

        signaturesTable_5.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_5.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_5.addCell(cell);
        signaturesTable_5.setSpacingAfter(25);

        // line 6
        PdfPTable signaturesTable_6 = new PdfPTable(5);
        signaturesTable_6.setTotalWidth(536);
        signaturesTable_6.setWidths(colWidths);
        signaturesTable_6.setLockedWidth(true);

        signaturesTable_6.addCell(createUnderlineCell());
        signaturesTable_6.addCell(createUnderlineCell());
        signaturesTable_6.addCell(createClearCell());
        signaturesTable_6.addCell(createClearCell());
        signaturesTable_6.addCell(createClearCell());

        cell = createClearCell();
        paragraph = new Paragraph("PRINTED NAME AND TITLE", times11);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_6.addCell(cell);
        cell = createClearCell();
        paragraph = new Paragraph("", times11);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        signaturesTable_6.addCell(cell);

        signaturesTable_6.addCell(createClearCell());
        cell = createClearCell();
        paragraph = new Paragraph("VIN: " + dto.getVin(), times9Bold);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        cell.setPaddingTop(topPadding);
        cell.setColspan(2);
        signaturesTable_6.addCell(cell);

        // finalize document/page
        document.add(pageHeader);
        document.add(pageSubHeader);
        document.add(vinTable);
        document.add(paragraph_1);
        document.add(paragraph_2);
        document.add(paragraph_3);
        document.add(paragraph_4);
        document.add(paragraph_5);
        document.add(paragraph_6);
        document.add(signaturesTable_1);
        document.add(signaturesTable_2);
        document.add(signaturesTable_3);
        document.add(signaturesTable_4);
        document.add(signaturesTable_5);
        document.add(signaturesTable_6);
        logger.info("###################### PDF Prepared Arbitration Form");
        return document;
    }
}
