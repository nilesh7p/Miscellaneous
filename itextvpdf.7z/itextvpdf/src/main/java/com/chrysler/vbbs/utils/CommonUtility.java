package com.chrysler.vbbs.utils;

public class CommonUtility {
    public static String returnEmptyStringIfNull(String str) {
        return str==null ?"":str.trim();
    }
}
