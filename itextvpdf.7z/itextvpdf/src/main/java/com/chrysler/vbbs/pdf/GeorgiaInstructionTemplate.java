package com.chrysler.vbbs.pdf;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

import java.io.IOException;

import static com.chrysler.vbbs.pdf.PdfUtility.createClearCell;
import static com.chrysler.vbbs.pdf.PdfUtility.createTable;

public class GeorgiaInstructionTemplate {

    /**
     * @param document
     * @param pageNum
     * @return
     * @throws DocumentException
     * @throws IOException
     */
    public Document createPage(Document document, int pageNum) throws DocumentException, IOException {
        BaseFont bf_verdana_bold = BaseFont.createFont("fonts/VERDANAB.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_verdana = BaseFont.createFont("fonts/VERDANA.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_verdana_italic = BaseFont.createFont("fonts/VERDANAI.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font verdana8bold = new Font(bf_verdana_bold, 8);
        final Font verdana8 = new Font(bf_verdana, 8);
        final Font verdana8italic = new Font(bf_verdana_italic, 8);
        final Font verdana9bolditalic = new Font(bf_verdana_bold, 8, Font.ITALIC);

        PdfPTable mainTable = createTable(1, 100, new float[]{580});

        Paragraph title0 = new Paragraph("Page " + pageNum + " of " + pageNum, verdana8);
        title0.setAlignment(Element.ALIGN_RIGHT);
        title0.setSpacingAfter(5f);

        Paragraph title = new Paragraph("GEORGIA LEMON LAW NOTICE FOR REACQUIRED VEHICLES", verdana8bold);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(5f);

        Paragraph title1 = new Paragraph("INSTRUCTIONS", verdana8bold);
        title1.setAlignment(Element.ALIGN_CENTER);
        title1.setSpacingAfter(5f);

        Paragraph bigPara = new Paragraph("These instructions are to be printed on the reverse side of the GEORGIA LEMON LAW NOTICE FOR REACQUIRED VEHICLES or attached thereto. Any reproduction of this Notice shall have these instructions on the reverse side or attached thereto. ", verdana8);
        bigPara.setLeading(10);
        bigPara.setAlignment(Element.ALIGN_LEFT);
        bigPara.setSpacingAfter(5f);

        Chunk chunk1 = new Chunk("VERY IMPORTANT:", verdana8bold);
        chunk1.setUnderline(0.1f, -2f);
        Chunk chunk2 = new Chunk(" This Notice applies to any reacquired vehicle (as defined below) that is", verdana8);
        Chunk chunk3 = new Chunk(" reacquired on or after January 1, 2009", verdana8italic);
        chunk3.setUnderline(0.1f, -2f);
        Chunk chunk4 = new Chunk(", either: (A) under Georgia’s Lemon Law; ", verdana8);
        Chunk chunk5 = new Chunk("OR ", verdana8bold);
        Chunk chunk6 = new Chunk("(B) under a similar statute of another state and transferred into Georgia.", verdana8);


        Paragraph bigPara1 = new Paragraph();
        bigPara1.add(chunk1);
        bigPara1.add(chunk2);
        bigPara1.add(chunk3);
        bigPara1.add(chunk4);
        bigPara1.add(chunk5);
        bigPara1.add(chunk6);
        bigPara1.setLeading(10);
        bigPara1.setAlignment(Element.ALIGN_LEFT);
        bigPara1.setSpacingAfter(5f);

        Chunk chunk11 = new Chunk("The Notice is to be completed", verdana8);
        Chunk chunk12 = new Chunk(" and all copies must be legible. Copies of the Notice regarding the respective reacquisition, transfer and sale or lease of a reacquired vehicle are to be sent within the statutorily-required time period indicated below to:", verdana8);
        Chunk chunk13 = new Chunk(" legibly and accurately,", verdana8italic);
        chunk13.setUnderline(0.1f, -2f);

        Paragraph bigPara2 = new Paragraph();
        bigPara2.add(chunk11);
        bigPara2.add(chunk13);
        bigPara2.add(chunk12);
        bigPara2.setLeading(10);
        bigPara2.setAlignment(Element.ALIGN_LEFT);
        bigPara2.setSpacingAfter(5f);

        Chunk bigParaChunk31 = new Chunk("Governor’s Office of Consumer Affairs\n", verdana8);
        Chunk bigParaChunk32 = new Chunk("Lemon Law Division\n", verdana8);
        Chunk bigParaChunk33 = new Chunk("2 M.L. King, Jr. Drive, Suite 356\n", verdana8);
        Chunk bigParaChunk34 = new Chunk("Atlanta, GA 30334", verdana8);

        Paragraph bigPara34 = new Paragraph();
        bigPara34.add(bigParaChunk31);
        bigPara34.add(bigParaChunk32);
        bigPara34.add(bigParaChunk33);
        bigPara34.add(bigParaChunk34);
        bigPara34.setLeading(10);
        bigPara34.setAlignment(Element.ALIGN_CENTER);
        bigPara34.setSpacingAfter(5f);

        Chunk chunk8 = new Chunk("Part I", verdana8bold);
        chunk5 = new Chunk(" is to be ", verdana8);
        chunk6 = new Chunk("completely", verdana8italic);
        chunk6.setUnderline(0.1f, -2f);
        Chunk chunk7 = new Chunk(" filled out by the manufacturer or its representative following acceptance of a reacquired vehicle.", verdana8);

        Paragraph bigPara4 = new Paragraph();
        bigPara4.add(chunk8);
        bigPara4.add(chunk5);
        bigPara4.add(chunk6);
        bigPara4.add(chunk7);

        bigPara4.setAlignment(Element.ALIGN_LEFT);
        bigPara4.setSpacingAfter(5f);

        Chunk chunk51 = new Chunk("Check ", verdana8);
        Chunk chunk52 = new Chunk("both", verdana8italic);
        chunk52.setUnderline(0.1f, -2f);
        Chunk chunk53 = new Chunk(" the correct category space and box and, where applicable, fill in the blank to indicate the circumstances under which the vehicle" + " was reacquired.",
                verdana8);
        Chunk chunk54 = new Chunk(" Part I-A", verdana8bold);
        Chunk chunk55 = new Chunk(" applies to reacquired vehicles covered under Georgia’s Lemon Law.", verdana8);
        Chunk chunk56 = new Chunk(" Part I-B", verdana8bold);
        Chunk chunk57 = new Chunk(" applies to vehicles reacquired under\n a similar statute of another state that are transferred into Georgia.", verdana8);

        Paragraph bigPara5 = new Paragraph();
        bigPara5.add(chunk51);
        bigPara5.add(chunk52);
        bigPara5.add(chunk53);
        bigPara5.add(chunk54);
        bigPara5.add(chunk55);
        bigPara5.add(chunk56);
        bigPara5.add(chunk57);
        bigPara5.setLeading(10);
        bigPara5.setAlignment(Element.ALIGN_LEFT);
        bigPara5.setSpacingAfter(5f);

        Chunk chunk61 = new Chunk("List the nonconformity or nonconformities resulting in the repurchase or replacement of the vehicle ", verdana8);
        Chunk chunk62 = new Chunk("as alleged by the consumer or as found \nby an arbitrator or judge.", verdana8italic);
        chunk62.setUnderline(0.1f, -2f);
        Chunk chunk63 = new Chunk("  Do ", verdana8);
        Chunk chunk64 = new Chunk("not", verdana8italic);
        chunk64.setUnderline(0.1f, -2f);
        Chunk chunk65 = new Chunk(" write on the Notice that a nonconformity has been repaired or corrected.", verdana8);
        Paragraph bigPara51 = new Paragraph();
        bigPara51.add(chunk61);
        bigPara51.add(chunk62);
        bigPara51.add(chunk63);
        bigPara51.add(chunk64);
        bigPara51.add(chunk65);
        bigPara51.setLeading(10);
        bigPara51.setAlignment(Element.ALIGN_LEFT);
        bigPara51.setSpacingAfter(5f);

        Chunk chunk71 = new Chunk(
                "When a vehicle covered under Georgia’s Lemon Law is repurchased or replaced, the manufacturer or its representative is to sign and date \nPart I of the Notice and send a copy to the Governor’s Office of Consumer Affairs within",
                verdana8);
        Chunk chunk72 = new Chunk(" 30 days from the date of reacquisition of the \nvehicle.", verdana9bolditalic);
        Paragraph bigPara52 = new Paragraph();
        bigPara52.add(chunk71);
        bigPara52.add(chunk72);
        bigPara52.setLeading(10);
        bigPara52.setAlignment(Element.ALIGN_LEFT);
        bigPara52.setSpacingAfter(5f);

        Chunk chunk81 = new Chunk("Part II", verdana8bold);
        Chunk chunk82 = new Chunk(
                " is to be completed, signed and dated by the manufacturer or its representative upon transfer of a reacquired vehicle. Indicate the name and address of the transferee and have the transferee sign and date the Notice. The manufacturer or its representative is to give the"
                        + " original Notice to the transferee. If the vehicle was transferred to be sold for scrap, check the box.",
                verdana8);

        Paragraph bigPara53 = new Paragraph();
        bigPara53.add(chunk81);
        bigPara53.add(chunk82);
        bigPara53.setLeading(10);
        bigPara53.setAlignment(Element.ALIGN_LEFT);
        bigPara53.setSpacingAfter(5f);

        Chunk chunk91 = new Chunk("If the reacquired vehicle is covered under Georgia’s Lemon Law, the manufacturer or its representative has", verdana8);
        Chunk chunk92 = new Chunk(" 30 days from the date of transfer of the vehicle", verdana9bolditalic);
        Chunk chunk93 = new Chunk(
                " to send a copy of the Notice to the Governor’s Office of Consumer Affairs. If the transfer occurs within 30 days of \nthe date of reacquisition, Parts I and II can be sent together on the same copy at that time.",
                verdana8);

        Paragraph bigPara54 = new Paragraph();
        bigPara54.add(chunk91);
        bigPara54.add(chunk92);
        bigPara54.add(chunk93);
        bigPara54.setLeading(10);
        bigPara54.setAlignment(Element.ALIGN_LEFT);
        bigPara54.setSpacingAfter(5f);

        Chunk chunk01 = new Chunk("If the vehicle was reacquired under a similar statute of another state and transferred into Georgia, Parts I and II are to be completed"
                + "\ntogether and the manufacturer or its representative is to send a copy of the Notice to the Governor’s Office of Consumer Affairs within", verdana8);
        Chunk chunk02 = new Chunk(" 30\ndays from the date of transfer of the vehicle", verdana9bolditalic);

        Paragraph bigPara55 = new Paragraph();
        bigPara55.add(chunk01);
        bigPara55.add(chunk02);
        bigPara55.setLeading(10);
        bigPara55.setAlignment(Element.ALIGN_LEFT);
        bigPara55.setSpacingAfter(5f);

        Chunk chunk03 = new Chunk("Part III -", verdana8bold);
        Chunk chunk04 = new Chunk(" The selling or leasing entity must allow a prospective consumer the opportunity to read the Notice", verdana8);
        Chunk chunk05 = new Chunk(" BEFORE", verdana8bold);
        Chunk chunk06 = new Chunk(
                " the sale or lease of the reacquired vehicle. At the time of sale or lease, the seller’s or lessor’s representative is to indicate the name and address of the ultimate "
                        + "consumer; list the current mileage on the vehicle and the date of sale or lease; and, have the ultimate consumer sign and date the Notice.",
                verdana8);

        Paragraph bigPara56 = new Paragraph();
        bigPara56.add(chunk03);
        bigPara56.add(chunk04);
        bigPara56.add(chunk05);
        bigPara56.add(chunk06);
        bigPara56.setLeading(10);
        bigPara56.setAlignment(Element.ALIGN_LEFT);
        bigPara56.setSpacingAfter(5f);

        Paragraph bigPara57 = new Paragraph("The seller’s or lessor’s representative is to complete the rest of Part III; sign and date the Notice; and, give the original Notice to the"
                + "\nultimate consumer.  The sale or lease of the vehicle activates the mandatory one year/12,000 mile (whichever occurs first) term within\n"
                + " which the manufacturer warrants to correct the nonconformity or nonconformities indicated on the Notice.", verdana8);
        bigPara57.setAlignment(Element.ALIGN_LEFT);
        bigPara57.setSpacingAfter(5f);
        bigPara57.setLeading(10);

        Chunk chunk100 = new Chunk("The selling or leasing entity has", verdana8);
        Chunk chunk101 = new Chunk(" 30 days from the sale or lease of the vehicle", verdana9bolditalic);
        Chunk chunk102 = new Chunk(" to send a copy of the Notice to the Governor’s Office of Consumer Affairs.  The manufacturer has", verdana8);
        Chunk chunk103 = new Chunk(" 90 days from the sale or lease of the vehicle", verdana8bold);
        Chunk chunk104 = new Chunk(
                " to notify the Governor’s Office of Consumer \nAffairs that the statutory warranty has been activated.  The manufacturer shall use the Governor’s Office of Consumer Affairs’ Reacquired\nVehicle Warranty Activation Notice for this purpose.",
                verdana8);

        Paragraph bigPara58 = new Paragraph();
        bigPara58.add(chunk100);
        bigPara58.add(chunk101);
        bigPara58.add(chunk102);
        bigPara58.add(chunk103);
        bigPara58.add(chunk104);
        bigPara58.setLeading(10);
        bigPara58.setAlignment(Element.ALIGN_LEFT);
        bigPara58.setSpacingAfter(5f);

        Paragraph bigPara59 = new Paragraph("DEFINITIONS", verdana8bold);
        bigPara59.setAlignment(Element.ALIGN_CENTER);
        bigPara59.setSpacingAfter(5f);

        Paragraph bigPara6 = new Paragraph("“Reacquired vehicle” means a new motor vehicle with an alleged nonconformity that has been replaced or repurchased by the manufacturer"
                + " as the result of any court order or judgment, arbitration decision, voluntary settlement entered into between a manufacturer and the"
                + " consumer, or voluntary settlement between a new motor vehicle dealer and a consumer in which the manufacturer directly or indirectly " + "participated.", verdana8);
        bigPara6.setAlignment(Element.ALIGN_LEFT);
        bigPara6.setLeading(10);
        bigPara6.setSpacingAfter(5f);

        Paragraph bigPara61 = new Paragraph("“Transfer” as used in connection with a reacquired vehicle means a change of ownership, by gift or any other means.", verdana8);
        bigPara61.setAlignment(Element.ALIGN_LEFT);
        bigPara61.setSpacingAfter(5f);

        Paragraph bigPara62 = new Paragraph("“Ultimate consumer” means the first person who purchases or leases a reacquired vehicle for purposes other than resale or sublease.", verdana8);
        bigPara62.setAlignment(Element.ALIGN_LEFT);
        bigPara62.setSpacingAfter(5f);

        Paragraph bigPara63 = new Paragraph("GAOCA—LL01—02/02/09", verdana8bold);
        bigPara63.setAlignment(Element.ALIGN_RIGHT);
        bigPara63.setSpacingAfter(5f);

        PdfPCell cell = createClearCell();

        cell.addElement(title0);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(title);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(title1);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara1);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara2);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara34);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara4);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara5);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara51);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara52);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara53);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara54);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara55);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara56);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara57);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara58);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara59);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara6);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara61);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara62);
        mainTable.addCell(cell);

        cell = createClearCell();
        cell.addElement(bigPara63);
        mainTable.addCell(cell);

        document.add(mainTable);

        System.out.println("Georgia Instruction printed ........................");
        return document;
    }
}
