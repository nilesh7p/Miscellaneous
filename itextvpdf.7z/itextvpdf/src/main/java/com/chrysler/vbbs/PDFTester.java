package com.chrysler.vbbs;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.pdf.DisclosureNoticeGeorgia;
import com.chrysler.vbbs.pdf.DisclosureNoticeIllinois;
import com.chrysler.vbbs.pdf.DisclosureNoticeIowa;
import com.chrysler.vbbs.pdf.DisclosureNoticeMassachussetts;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class PDFTester {
    static List<String> list = Arrays.asList("",
            "Bolts from hard top stripped.",
            "heat does not blow hot.",
            "water sloshing around dash.",
            "disc changing noise when vehicle is off.",
            "water leaks in from the hard top. water leaks in from the hard top. water leaks in from the hard top. water leaks in from the hard top. water leaks in from the hard top.",
            "oil leak.",
            "wind noise from the windshield area.",
            "plastic door step missing fastener.",
            "loose wires behind front tires.",
            "loose wires behind front tires."
    );

    public static void main(String[] args) throws IOException, DocumentException {
        DisclosureTemplatePlaceHolderDto dto = DisclosureTemplatePlaceHolderDto.samplePreviewData();
        dto.setProblems(list);
        dto.setRepairsMade(list);
        dto.setVin("ZACCJABT3FPB44930");
        dto.setYear("2018");
        dto.setMake("RAM");
        dto.setModel("2500 SLT 4X4 ");
        dto.setDealerName("MARTIN MOTORS");
        dto.setDealerCode("63938");
        dto.setDealerCity("NASHVILLE");
        dto.setDealerState("GA");
        dto.setDealerZip("316392620");
        dto.setBuybackCair("32147980");
        dto.setCurrDate("07192018");
        dto.setAdditionalInfoLine1("Testing additional information details");
        dto.setVehicleOriginallySoldDate("07/24/2018");
        dto.setAdditionalInfoLine2("Testing additional information details again");
        dto.setCurrentDate("07/24/2018");
        dto.setCurrentMileage("66,850");
        dto.setDateOfVehicleReacquation("10/04/2017");
        dto.setPreviousTitleNumber("06P1258332");
        dto.setStateOfTitle("CO");
        dto.setOriginalCustomerName("MS. MELANIE STROMBERG");
        dto.setOriginalCustomerAddress("2749 Patrick Henry street ");
        Document document = new Document(PageSize.LETTER);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:\\PDF\\Georgia_disclosure.pdf"));
        document.open();
        document = new DisclosureNoticeGeorgia().createPdf(dto, document);
        document.close();
    }
}
