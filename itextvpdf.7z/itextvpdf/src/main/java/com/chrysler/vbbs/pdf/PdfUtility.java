package com.chrysler.vbbs.pdf;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import org.apache.log4j.Logger;

import java.io.IOException;

public class PdfUtility {
    private static Logger logger = Logger.getLogger(PdfUtility.class);

    /**
     * @param columns         number of columns in table
     * @param widthPercentage width percentage
     * @param columnWidths    widths of columns
     * @return table
     */
    public static PdfPTable createTable(int columns, int widthPercentage, float[] columnWidths) {
        PdfPTable table = new PdfPTable(columns);
        table.setWidthPercentage(widthPercentage);
        try {
            table.setTotalWidth(columnWidths);
        } catch (DocumentException docEx) {
            docEx.printStackTrace();
        }
        table.setLockedWidth(true);
        return table;
    }
    public static PdfPTable createFullWidthTable(int columns, float[] columnWidths) {
        return createTable(columns,100,columnWidths);
    }

    /**
     * @param imgPath   path to image file
     * @param alignment alignment
     * @return created image
     */
    public static Image createImage(String imgPath, int alignment) {
        Image img = null;
        try {
            img = Image.getInstance(PdfUtility.class.getResource(imgPath).getPath());
            img.setAlignment(alignment);
        } catch (IOException | BadElementException ex) {
            ex.printStackTrace();
        }
        return img;
    }


    /**
     * @param content   - content to be used
     * @param font      - font to be used
     * @param alignment - alignment of text
     * @return cell
     */
    public static PdfPCell createUnderlineContentCell(String content, Font font, int alignment) {
        PdfPCell contentCell = PdfUtility.createUnderlineCell();
        contentCell.setPaddingBottom(4);
        Paragraph contentParagraph = new Paragraph(content.trim(), font);
        contentParagraph.setAlignment(alignment);
        contentCell.addElement(contentParagraph);
        return contentCell;
    }
    /**
     * @param content   - content to be used
     * @param font      - font to be used
     * @param alignment - alignment of text
     * @return cell
     */
    public static PdfPCell createUnderlineChunkCell(String content, Font font, int alignment,float thickness,float yPos) {
        PdfPCell contentCell = PdfUtility.createClearCell();
        contentCell.setPaddingBottom(4);
        Chunk chunk = new Chunk(content,font);
        chunk.setUnderline(thickness,yPos);
        Paragraph contentParagraph = new Paragraph(chunk);
        contentParagraph.setAlignment(alignment);
        contentCell.addElement(contentParagraph);
        return contentCell;
    }
    /**
     * @param content   - content to be used
     * @param font      - font to be used
     * @param alignment - alignment of text
     * @return cell
     */
    public static PdfPCell createSignatoryCell(String content, Font font, int alignment) {
        PdfPCell signatoryCell = createClearCell();
        signatoryCell.setPaddingTop(-2);
        Paragraph signatoryText = new Paragraph(returnEmptyIfNull(content), font);
        signatoryText.setAlignment(alignment);
        signatoryCell.addElement(signatoryText);
        return signatoryCell;
    }

    public static String returnEmptyIfNull(String content) {
        return content == null ? "" : content.trim();
    }

    /**
     * Utility method to create a cell with no borders and no content
     *
     * @return clear cell
     */
    public static PdfPCell createClearCell() {
        PdfPCell clearCell = new PdfPCell(new Paragraph(" "));
        clearCell.setBorder(Rectangle.NO_BORDER);
        return clearCell;
    }

    /**
     * @param content
     * @param font
     * @param alignment
     * @return
     */
    public static PdfPCell createClearContentCell(String content, Font font, int alignment) {
        PdfPCell clearCell = new PdfPCell();
        Paragraph contentParagraph = new Paragraph(content, font);
        contentParagraph.setAlignment(alignment);
        clearCell.setBorder(Rectangle.NO_BORDER);
        clearCell.addElement(contentParagraph);

        return clearCell;
    }

    /**
     * Utility method to create underlined cell
     *
     * @return underlined cell
     */
    public static PdfPCell createUnderlineCell() {
        PdfPCell underlineCell = new PdfPCell(new Phrase(" "));
        underlineCell.setBorder(Rectangle.BOTTOM);
        underlineCell.setBorderWidth(1f);
        return underlineCell;
    }

    /**
     * Utility method to generate signature table template
     *
     * @return Signature table template
     */
    public static PdfPTable createSignatureTable() {
        PdfPTable signatureTable = new PdfPTable(5);
        signatureTable.setTotalWidth(210 + 65 + 30 + 210 + 65);
        try {
            signatureTable.setWidths(new float[]{210, 65, 30, 210, 65});
        } catch (DocumentException docEx) {
            logger.info("document exception in createSignatureTable: ");
            docEx.printStackTrace();
        }
        signatureTable.setLockedWidth(true);
        return signatureTable;
    }
}
