package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 1214662 T9450NP 7/16/2018
 */

public class DisclosureNoticeGeorgia {
    Logger logger = Logger.getLogger(DisclosureNoticeGeorgia.class);

    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {
        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_verdana_bold = BaseFont.createFont("fonts/VERDANAB.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_timesNew = BaseFont.createFont("fonts/TIMES.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_timesNewbd = BaseFont.createFont("fonts/TIMESBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_timesNewBdIttalic = BaseFont.createFont("fonts/TIMESBI.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font verdana11bold = new Font(bf_verdana_bold, 11);
        final Font arial7 = new Font(bf_arial, 7);
        final Font arial12 = new Font(bf_arial, 12);
        final Font times12bold = new Font(bf_timesNewbd, 12);
        final Font times9bold = new Font(bf_timesNewbd, 9);
        final Font times9 = new Font(bf_timesNew, 9);
        final Font arial8 = new Font(bf_arial, 8);
        final Font times8 = new Font(bf_timesNew, 8);
        final Font times10 = new Font(bf_timesNew, 10);
        final Font times11bolditalic = new Font(bf_timesNewBdIttalic, 11);
        final Font times12bolditalic = new Font(bf_timesNewBdIttalic, 12);
        final Font times10bold = new Font(bf_timesNewbd, 10);
        final Font courier8 = new Font(bf_courierNew, 8);
        final Font times7 = new Font(bf_timesNew, 7);


        PdfPTable cairPageNumTable = new PdfPTable(3);
        cairPageNumTable.setWidthPercentage(110);
        try {
            cairPageNumTable.setTotalWidth(new float[]{100, 360, 100});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        cairPageNumTable.setLockedWidth(true);
        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);

        Image image = null;
        try {
            image = Image.getInstance(getClass().getResource("/images/logo-fca.png").getPath());
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        PdfPTable titleTable = new PdfPTable(5);
        titleTable.setWidthPercentage(110);
        try {
            titleTable.setTotalWidth(new float[]{65, 20, 380, 15, 80});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        titleTable.setLockedWidth(true);
        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(-3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        //titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase());
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);

        Chunk chunk = new Chunk("GEORGIA LEMON LAW NOTICE FOR REACQUIRED VEHICLES", verdana11bold);
        chunk.setUnderline(1f, -2f);

        titleCell = new PdfPCell(new Paragraph());
        Paragraph p = new Paragraph();
        p.add(chunk);

        titleCell.addElement(p);
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setPaddingBottom(2f);
        titleCell.setPaddingLeft(5f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase());
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", arial7));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleCell.setPaddingBottom(2f);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);

        PdfPTable titleTable1 = new PdfPTable(5);
        titleTable1.setWidthPercentage(110);
        try {
            titleTable1.setTotalWidth(new float[]{50, 40, 450, 40, 50});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        titleTable1.setLockedWidth(true);
        PdfPCell titleCell1 = new PdfPCell(new Phrase("", arial12));
        titleCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        titleCell1.setBorder(Rectangle.NO_BORDER);
        titleCell1.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable1.getDefaultCell().setPaddingTop(1);
        titleTable1.addCell(titleCell1);

        titleCell1 = new PdfPCell(new Phrase());
        titleCell1.setBorder(Rectangle.NO_BORDER);
        titleCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleTable1.addCell(titleCell1);

        titleCell1 = new PdfPCell(new Phrase("     (For vehicles reacquired on or after January 1, 2009 -- See attached page for Notice completion and compliance instructions)", times8));
        titleCell1.setBorder(Rectangle.NO_BORDER);
        titleCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        titleCell1.setPaddingTop(-7);
        titleTable1.addCell(titleCell1);

        titleCell1 = new PdfPCell(new Phrase());
        titleCell1.setBorder(Rectangle.NO_BORDER);
        titleCell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable1.addCell(titleCell1);

        titleCell1 = new PdfPCell(new Phrase());
        titleCell1.setBorder(Rectangle.NO_BORDER);
        titleCell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable1.addCell(titleCell1);
        titleTable1.setSpacingAfter(-3);

        PdfPTable detailTable = new PdfPTable(9);

        try {
            detailTable.setTotalWidth(new float[]{57, 50, 30, 140, 25, 30, 62, 55, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable.setWidthPercentage(110);

        // 1row
        PdfPCell cell = new PdfPCell(new Phrase("  Vehicle Make:", times10));
        cell.setBorder(Rectangle.NO_BORDER);
        detailTable.addCell(cell);

        // 2 row
        cell = new PdfPCell(new Phrase(dto.getMake(), times9));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setBorderWidth(1f);
        cell.enableBorderSide(2);
        detailTable.addCell(cell);

        // 3 row
        cell = new PdfPCell(new Phrase("  Model:", times10));
        cell.setBorder(Rectangle.NO_BORDER);
        detailTable.addCell(cell);

        // 4 row
        cell = new PdfPCell(new Phrase(dto.getModel(), times9));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setBorderWidth(1f);
        cell.enableBorderSide(2);
        detailTable.addCell(cell);

        // 5row
        cell = new PdfPCell(new Phrase("Year:", times10));
        cell.setBorder(Rectangle.NO_BORDER);
        detailTable.addCell(cell);

        // 6 row
        cell = new PdfPCell(new Phrase(dto.getYear(), times9));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.enableBorderSide(2);
        cell.setBorderWidth(1f);
        detailTable.addCell(cell);

        // 7 row
        cell = new PdfPCell(new Phrase("Current Mileage:", times10));
        cell.setBorder(Rectangle.NO_BORDER);
        detailTable.addCell(cell);

        // 8 row
        cell = new PdfPCell(new Phrase(dto.getCurrentMileage(), times9));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.enableBorderSide(2);
        cell.setBorderWidth(1f);
        detailTable.addCell(cell);

        cell = new PdfPCell(new Phrase("", times9));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setBorderWidth(1f);
        detailTable.addCell(cell);
        detailTable.setSpacingAfter(2f);

        PdfPTable detail1Table = new PdfPTable(5);

        try {
            detail1Table.setTotalWidth(new float[]{25, 225, 110, 110, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detail1Table.setWidthPercentage(110);

        // 1 row
        PdfPCell cell1 = new PdfPCell(new Phrase("  VIN:", times10));
        cell1.setBorder(Rectangle.NO_BORDER);
        detail1Table.addCell(cell1);

        // 2 row
        cell1 = new PdfPCell(new Phrase(dto.getVin(), times9));
        cell1.setBorder(Rectangle.NO_BORDER);
        cell1.enableBorderSide(2);
        cell1.setBorderWidth(1f);
        detail1Table.addCell(cell1);

        // 3 row
        cell1 = new PdfPCell(new Phrase("Date of Vehicle Reacquisition:", times10));
        cell1.setBorder(Rectangle.NO_BORDER);
        detail1Table.addCell(cell1);

        // 4 row
        cell1 = new PdfPCell(new Phrase(dto.getDateOfVehicleReacquation(), times9));
        cell1.setBorder(Rectangle.NO_BORDER);
        cell1.enableBorderSide(2);
        cell1.setBorderWidth(1f);
        detail1Table.addCell(cell1);

        cell1 = new PdfPCell(new Phrase("", times9));
        cell1.setBorder(Rectangle.NO_BORDER);
        cell1.setBorderWidth(1f);
        detail1Table.addCell(cell1);

        detail1Table.setSpacingAfter(2f);

        PdfPTable detail2Table = new PdfPTable(7);

        try {
            detail2Table.setTotalWidth(new float[]{70, 100, 25, 50, 110, 145, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detail2Table.setWidthPercentage(110);

        // 1 row
        PdfPCell cell2 = new PdfPCell(new Phrase("  Previous Title #:", times10));
        cell2.setBorder(Rectangle.NO_BORDER);
        detail2Table.addCell(cell2);

        // 2row
        cell2 = new PdfPCell(new Phrase(dto.getPreviousTitleNumber(), times9));
        cell2.setBorder(Rectangle.NO_BORDER);
        cell2.enableBorderSide(2);
        cell2.setBorderWidth(1f);
        detail2Table.addCell(cell2);

        // 3 row
        cell2 = new PdfPCell(new Phrase("State:", times10));
        cell2.setBorder(Rectangle.NO_BORDER);
        detail2Table.addCell(cell2);

        // 4 row
        cell2 = new PdfPCell(new Phrase(dto.getStateOfTitle(), times9));
        cell2.setBorder(Rectangle.NO_BORDER);
        cell2.enableBorderSide(2);
        cell2.setBorderWidth(1f);

        detail2Table.addCell(cell2);
        // 5 row
        cell2 = new PdfPCell(new Phrase("Name of Original Consumer:", times10));
        cell2.setBorder(Rectangle.NO_BORDER);
        detail2Table.addCell(cell2);
        // 6 row
        cell2 = new PdfPCell(new Phrase(dto.getOriginalCustomerName(), times9));
        cell2.setBorder(Rectangle.NO_BORDER);
        cell2.enableBorderSide(2);
        cell2.setBorderWidth(1f);
        detail2Table.addCell(cell2);

        cell2 = new PdfPCell(new Phrase(" ", times9));
        cell2.setBorder(Rectangle.NO_BORDER);
        cell2.setBorderWidth(1f);
        detail2Table.addCell(cell2);

        detail2Table.setSpacingAfter(2f);

        PdfPTable detail3Table = new PdfPTable(3);

        try {
            detail3Table.setTotalWidth(new float[]{260, 785, 35});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detail3Table.setWidthPercentage(110);

        // 1 row
        PdfPCell cell3 = new PdfPCell(new Phrase("  Address of Original Consumer:", times10));
        cell3.setBorder(Rectangle.NO_BORDER);
        detail3Table.addCell(cell3);

        // 2row
        cell3 = new PdfPCell(new Phrase(dto.getOriginalCustomerAddress(), times9));
        cell3.setBorder(Rectangle.NO_BORDER);
        cell3.enableBorderSide(2);
        cell3.setBorderWidth(1f);
        detail3Table.addCell(cell3);

        cell3 = new PdfPCell(new Phrase("", times9));
        cell3.setBorder(Rectangle.NO_BORDER);
        cell3.setBorderWidth(1f);
        detail3Table.addCell(cell3);

        detail3Table.setSpacingAfter(10f);
        detail3Table.setSpacingAfter(4f);

        PdfPTable detailTable4 = new PdfPTable(7);

        try {
            detailTable4.setTotalWidth(new float[]{7, 170, 15, 150, 15, 120, 15});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable4.setWidthPercentage(110);

        // 1row
        PdfPCell cell4 = new PdfPCell(new Phrase("", times10));
        cell4.setBorder(Rectangle.NO_BORDER);
        detailTable4.addCell(cell4);

        // 2 row
        cell4 = new PdfPCell(new Phrase("   Name and Title of FCA US LLC Representative (print)    ", times8));
        cell4.setBorder(Rectangle.NO_BORDER);
        cell4.setBorderWidth(1f);
        cell4.enableBorderSide(1);
        detailTable4.addCell(cell4);

        // 3 row
        cell4 = new PdfPCell(new Phrase("", times10));
        cell4.setBorder(Rectangle.NO_BORDER);
        detailTable4.addCell(cell4);

        // 4 row
        cell4 = new PdfPCell(new Phrase("    Signature of FCA US LLC Representative    ", times8));
        cell4.setBorder(Rectangle.NO_BORDER);
        cell4.setBorderWidth(1f);
        cell4.enableBorderSide(1);
        detailTable4.addCell(cell4);

        // 5row
        cell4 = new PdfPCell(new Phrase(" ", times9));
        cell4.setBorder(Rectangle.NO_BORDER);
        cell4.setBorderWidth(1f);
        detailTable4.addCell(cell4);

        // 6 row
        cell4 = new PdfPCell(new Phrase("         Date        ", times8));
        cell4.setBorder(Rectangle.NO_BORDER);
        cell4.setBorderWidth(1f);
        cell4.enableBorderSide(1);
        detailTable4.addCell(cell4);

        // 7 row
        cell4 = new PdfPCell(new Phrase(" ", times9));
        cell4.setBorder(Rectangle.NO_BORDER);
        cell4.setBorderWidth(1f);
        detailTable4.addCell(cell4);

        PdfPTable detailTable5 = new PdfPTable(8);

        try {
            detailTable5.setTotalWidth(new float[]{7, 230, 5, 80, 5, 110, 270, 23});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable5.setWidthPercentage(110);

        // 1row
        PdfPCell cell5 = new PdfPCell(new Phrase(""));
        cell5.setBorder(Rectangle.NO_BORDER);
        detailTable5.addCell(cell5);

// 2 row
        cell5 = new PdfPCell(new Phrase("This vehicle was transferred by FCA US LLC on (Date)", times8));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);
        detailTable5.addCell(cell5);

// 3 row
        cell5 = new PdfPCell(new Phrase("", times9));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);

        detailTable5.addCell(cell5);

// 4 row
        cell5 = new PdfPCell(new Phrase(dto.getCurrentDate(), times9));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);
        cell5.enableBorderSide(2);
        detailTable5.addCell(cell5);

// 5row
        cell5 = new PdfPCell(new Phrase("", times8));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);

        detailTable5.addCell(cell5);

// 6 row
        cell5 = new PdfPCell(new Phrase("to (Name of Transferee),", times8));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);
        detailTable5.addCell(cell5);

// 7 row
        cell5 = new PdfPCell(new Phrase(dto.getTransfareeName(), times9));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);
        cell5.enableBorderSide(2);
        detailTable5.addCell(cell5);

// 8 row
        cell5 = new PdfPCell(new Phrase("", times9));
        cell5.setBorder(Rectangle.NO_BORDER);
        cell5.setBorderWidth(1f);

        detailTable5.addCell(cell5);

        PdfPTable detailTable6 = new PdfPTable(4);

        try {
            detailTable6.setTotalWidth(new float[]{7, 100, 520, 20});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable6.setWidthPercentage(110);
        PdfPCell cell6 = new PdfPCell(new Phrase("", times10));
        cell6.setBorder(Rectangle.NO_BORDER);
        detailTable6.addCell(cell6);

// 1row
        cell6 = new PdfPCell(new Phrase("(Address of Transferee)", times9));
        cell6.setBorder(Rectangle.NO_BORDER);
        detailTable6.addCell(cell6);

// 2 row
        cell6 = new PdfPCell(new Phrase("", times10));
        cell6.setBorder(Rectangle.NO_BORDER);
        cell6.enableBorderSide(2);
        detailTable6.addCell(cell6);

// 3 row
        cell6 = new PdfPCell(new Phrase("", times10));
        cell6.setBorder(Rectangle.NO_BORDER);
        detailTable6.addCell(cell6);

        PdfPTable detailTable7 = new PdfPTable(7);

        try {
            detailTable7.setTotalWidth(new float[]{5, 10, 130, 130, 5, 133, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable7.setWidthPercentage(110);

        Image checkNO_BORDER = null;
        try {
            checkNO_BORDER = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        PdfPCell cell7 = new PdfPCell(new Phrase("", times9));
        cell7.setBorder(Rectangle.NO_BORDER);
        detailTable7.addCell(cell7);

// 1row
        cell7 = new PdfPCell(new Phrase(""));
        detailTable7.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        detailTable7.addCell(checkNO_BORDER);

// 2 row
        cell7 = new PdfPCell(new Phrase("Check this box if vehicle is being sold for scrap", times9));
        cell7.setBorder(Rectangle.NO_BORDER);
        detailTable7.addCell(cell7);

// 3 row
        cell7 = new PdfPCell(new Phrase("", times10));
        cell7.setBorder(Rectangle.NO_BORDER);
        cell7.enableBorderSide(2);
        detailTable7.addCell(cell7);

// 4 row
        cell7 = new PdfPCell(new Phrase("", times10));
        cell7.setBorder(Rectangle.NO_BORDER);
        detailTable7.addCell(cell7);
// 5row
        cell7 = new PdfPCell(new Phrase("", times10));
        cell7.setBorder(Rectangle.NO_BORDER);
        cell7.enableBorderSide(2);
        detailTable7.addCell(cell7);

// 6 row
        cell7 = new PdfPCell(new Phrase("", times10));
        cell7.setBorder(Rectangle.NO_BORDER);
        detailTable7.addCell(cell7);

        PdfPTable detailTable8 = new PdfPTable(7);

        try {
            detailTable8.setTotalWidth(new float[]{7, 155, 25, 150, 20, 150, 5});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable8.setWidthPercentage(110);

// 1row
        PdfPCell cell8 = new PdfPCell(new Phrase("", times10));
        cell8.setBorder(Rectangle.NO_BORDER);
        detailTable8.addCell(cell8);

// 2 row
        cell8 = new PdfPCell(new Phrase("            ", times8));
        cell8.setBorder(Rectangle.NO_BORDER);
        cell8.setBorderWidth(1f);
        detailTable8.addCell(cell8);

// 3 row
        cell8 = new PdfPCell(new Phrase("", times10));
        cell8.setBorder(Rectangle.NO_BORDER);
        detailTable8.addCell(cell8);

// 4 row
        cell8 = new PdfPCell(new Phrase("Name and Title of FCA US LLC Representative (print) ", times7));
        cell8.setBorder(Rectangle.NO_BORDER);
        cell8.setBorderWidth(1f);
        detailTable8.addCell(cell8);

// 5row
        cell8 = new PdfPCell(new Phrase(" ", times9));
        cell8.setBorder(Rectangle.NO_BORDER);
        cell8.setBorderWidth(1f);
        detailTable8.addCell(cell8);

// 6 row
        cell8 = new PdfPCell(new Phrase("Signature of FCA US LLC Representative", times7));
        cell8.setBorder(Rectangle.NO_BORDER);
        cell8.setBorderWidth(1f);
        detailTable8.addCell(cell8);

// 7 row
        cell8 = new PdfPCell(new Phrase(" ", times9));
        cell8.setBorder(Rectangle.NO_BORDER);
        cell8.setBorderWidth(1f);
        detailTable8.addCell(cell8);
        detailTable8.setSpacingAfter(10f);

        PdfPTable detailTable9 = new PdfPTable(7);

        try {
            detailTable9.setTotalWidth(new float[]{5, 180, 15, 150, 15, 120, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable9.setWidthPercentage(110);

// 1row
        PdfPCell cell9 = new PdfPCell(new Phrase("", times10));
        cell9.setBorder(Rectangle.NO_BORDER);
        detailTable9.addCell(cell9);

// 2 row
        cell9 = new PdfPCell(new Phrase("Name and Title of FCA US LLC Representative (print)", times7));
        cell9.setBorder(Rectangle.NO_BORDER);
        cell9.setBorderWidth(1f);
        cell9.enableBorderSide(1);
        detailTable9.addCell(cell9);

// 3 row
        cell9 = new PdfPCell(new Phrase("", times10));
        cell9.setBorder(Rectangle.NO_BORDER);
        detailTable9.addCell(cell9);

// 4 row
        cell9 = new PdfPCell(new Phrase("Signature of FCA US LLC Representative    ", times7));
        cell9.setBorder(Rectangle.NO_BORDER);
        cell9.setBorderWidth(1f);
        cell9.enableBorderSide(1);
        detailTable9.addCell(cell9);

// 5row
        cell9 = new PdfPCell(new Phrase(" ", times9));
        cell9.setBorder(Rectangle.NO_BORDER);
        cell9.setBorderWidth(1f);
        detailTable9.addCell(cell9);

// 6 row
        cell9 = new PdfPCell(new Phrase("         Date        ", times8));
        cell9.setBorder(Rectangle.NO_BORDER);
        cell9.setBorderWidth(1f);
        cell9.enableBorderSide(1);
        detailTable9.addCell(cell9);

// 7 row
        cell9 = new PdfPCell(new Phrase(" ", times9));
        cell9.setBorder(Rectangle.NO_BORDER);
        cell9.setBorderWidth(1f);
        detailTable9.addCell(cell9);
        detailTable9.setSpacingAfter(5f);

        PdfPTable detailTable91 = new PdfPTable(4);

        try {
            detailTable91.setTotalWidth(new float[]{5, 120, 430, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable91.setWidthPercentage(110);

        PdfPCell cell91 = new PdfPCell(new Phrase("", times10));
        cell91.setBorder(Rectangle.NO_BORDER);
        detailTable91.addCell(cell91);
// 1row
        cell91 = new PdfPCell(new Phrase("VERY IMPORTANT:", times12bold));
        cell91.setBorder(Rectangle.NO_BORDER);
        cell91.enableBorderSide(1);
        cell91.enableBorderSide(2);
        cell91.setBorderWidth(2f);
        cell91.setPaddingTop(-1);
        cell91.setBackgroundColor(BaseColor.LIGHT_GRAY);
        detailTable91.addCell(cell91);

// 2 row
        cell91 = new PdfPCell(new Phrase("At the time of each transfer of this vehicle, the transferor shall ensure that the transferee receives this Notice.", times9bold));
        cell91.setBorder(Rectangle.NO_BORDER);
        cell91.enableBorderSide(1);
        cell91.enableBorderSide(2);
        cell91.setBackgroundColor(BaseColor.LIGHT_GRAY);
        cell91.setBorderWidth(2f);
        detailTable91.addCell(cell91);

// 3 row
        cell91 = new PdfPCell(new Phrase("", times10));
        cell91.setBorder(Rectangle.NO_BORDER);
        detailTable91.addCell(cell91);

        PdfPTable detailTable92 = new PdfPTable(3);

        try {
            detailTable92.setTotalWidth(new float[]{5, 600, 30});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable92.setWidthPercentage(110);

// 3 row
        PdfPCell cell92 = new PdfPCell(new Phrase("", times10));
        cell92.setBorder(Rectangle.NO_BORDER);
        detailTable92.addCell(cell92);

// 1row
        cell92 = new PdfPCell(new Phrase("PART III: TO BE COMPLETED AT THE TIME OF SALE OR LEASE OF THE VEHICLE TO THE", times12bolditalic));
        cell92.setBorder(Rectangle.NO_BORDER);
        cell92.enableBorderSide(2);
        cell92.setBorderWidth(1f);
        detailTable92.addCell(cell92);

// 3 row
        cell92 = new PdfPCell(new Phrase("", times10));
        cell92.setBorder(Rectangle.NO_BORDER);
        detailTable92.addCell(cell92);

        PdfPTable detailTable93 = new PdfPTable(2);

        try {
            detailTable93.setTotalWidth(new float[]{545, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable93.setWidthPercentage(110);

// 1row
        PdfPCell cell93 = new PdfPCell(new Paragraph(" "));
        cell93.setBorder(Rectangle.NO_BORDER);

        Paragraph p3 = new Paragraph();
        Chunk chunk9 = new Chunk("ULTIMATE CONSUMER -", times11bolditalic);
        chunk9.setUnderline(1f, -2f);
        Chunk chun91 = new Chunk(
                "I understand this vehicle was reacquired by FCA US LLC for the reason indicated above and that if I purchase or lease it, I will be given the original Notice, and not a copy. In addition to any other warranties that may come with this vehicle, FCA US LLC warrants to correct the nonconformities indicated above for a term of one year with unlimited mileage starting from:",
                times9);
        p3.setLeading(10);

        p3.add(chunk9);
        p3.add(chun91);
        cell93.addElement(p3);
        cell93.setBorder(Rectangle.NO_BORDER);
        detailTable93.addCell(cell93);

// 3 row
        PdfPCell cell931 = new PdfPCell(new Phrase("", times10));
        cell931.setBorder(Rectangle.NO_BORDER);
        detailTable93.addCell(cell931);

        PdfPTable detailTable94 = new PdfPTable(5);

        try {
            detailTable94.setTotalWidth(new float[]{250, 65, 15, 105, 10});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable94.setWidthPercentage(110);

// 1row
        PdfPCell cell94 = new PdfPCell(new Phrase("", times10));
        cell94.setBorder(Rectangle.NO_BORDER);
        detailTable94.addCell(cell94);

// 3 row
        cell94 = new PdfPCell(new Phrase("", times10));
        cell94.setBorder(Rectangle.NO_BORDER);
        cell94.enableBorderSide(2);
        cell94.setBorderWidth(1f);
        detailTable94.addCell(cell94);
// 3 row
        cell94 = new PdfPCell(new Phrase("and", times9bold));
        cell94.setBorder(Rectangle.NO_BORDER);
        detailTable94.addCell(cell94);

// 3 row
        cell94 = new PdfPCell(new Phrase("", times10));
        cell94.setBorder(Rectangle.NO_BORDER);
        cell94.enableBorderSide(2);
        cell94.setBorderWidth(1f);
        detailTable94.addCell(cell94);

// 3 row
        cell94 = new PdfPCell(new Phrase("", times10));
        cell94.setBorder(Rectangle.NO_BORDER);
        detailTable94.addCell(cell94);

        PdfPTable detailTable95 = new PdfPTable(5);

        try {
            detailTable95.setTotalWidth(new float[]{250, 65, 15, 65, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable95.setWidthPercentage(110);

// 1row
        PdfPCell cell95 = new PdfPCell(new Phrase("I read the information on this Notice BEFORE I purchased or leased this vehicle.", times10bold));
        cell95.setBorder(Rectangle.NO_BORDER);
        detailTable95.addCell(cell95);

// 3 row
        cell95 = new PdfPCell(new Phrase("   Today's Date   ", times8));
        cell95.setBorder(Rectangle.NO_BORDER);
        detailTable95.addCell(cell95);
// 3 row
        cell95 = new PdfPCell(new Phrase("", times10));
        cell95.setBorder(Rectangle.NO_BORDER);
        detailTable95.addCell(cell95);

// 3 row
        cell95 = new PdfPCell(new Phrase("   Current Mileage   ", times8));
        cell95.setBorder(Rectangle.NO_BORDER);
        detailTable95.addCell(cell95);

// 3 row
        cell95 = new PdfPCell(new Phrase("", times10));
        cell95.setBorder(Rectangle.NO_BORDER);
        detailTable95.addCell(cell95);
        detailTable95.setSpacingAfter(15f);

        PdfPTable detailTable96 = new PdfPTable(7);

        try {
            detailTable96.setTotalWidth(new float[]{0, 190, 15, 50, 15, 190, 10});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable96.setWidthPercentage(110);

// 1row
        PdfPCell cell96 = new PdfPCell(new Phrase("", times10));
        cell96.setBorder(Rectangle.NO_BORDER);
        detailTable96.addCell(cell96);

// 2 row
        cell96 = new PdfPCell(new Phrase("                 Signature of Buyer or Lessee        ", times8));
        cell96.setBorder(Rectangle.NO_BORDER);
        cell96.setBorderWidth(1f);
        cell96.enableBorderSide(1);
        detailTable96.addCell(cell96);

// 3 row
        cell96 = new PdfPCell(new Phrase("", times10));
        cell96.setBorder(Rectangle.NO_BORDER);
        detailTable96.addCell(cell96);

// 4 row
        cell96 = new PdfPCell(new Phrase("        Date    ", times8));
        cell96.setBorder(Rectangle.NO_BORDER);
        cell96.setBorderWidth(1f);
        cell96.enableBorderSide(1);
        detailTable96.addCell(cell96);

// 5row
        cell96 = new PdfPCell(new Phrase(" ", times9));
        cell96.setBorder(Rectangle.NO_BORDER);
        cell96.setBorderWidth(1f);
        detailTable96.addCell(cell96);

// 6 row
        cell96 = new PdfPCell(new Phrase("                    Name of Buyer or Lessee (print)        ", times8));
        cell96.setBorder(Rectangle.NO_BORDER);
        cell96.setBorderWidth(1f);
        cell96.enableBorderSide(1);
        detailTable96.addCell(cell96);

// 7 row
        cell96 = new PdfPCell(new Phrase(" ", times9));
        cell96.setBorder(Rectangle.NO_BORDER);
        cell96.setBorderWidth(1f);
        detailTable96.addCell(cell96);
        detailTable96.setSpacingAfter(15f);

        PdfPTable detailTable97 = new PdfPTable(2);

        try {
            detailTable97.setTotalWidth(new float[]{600, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable97.setWidthPercentage(110);

// 1 row
        PdfPCell cell97 = new PdfPCell(new Phrase("Address of Buyer or Lessee (print)", times8));
        cell97.setBorder(Rectangle.NO_BORDER);
        cell97.enableBorderSide(1);
        cell97.setHorizontalAlignment(Element.ALIGN_CENTER);
        detailTable97.addCell(cell97);

// 1 row
        cell97 = new PdfPCell(new Phrase(" ", times10));
        cell97.setBorder(Rectangle.NO_BORDER);
        detailTable97.addCell(cell97);
        detailTable97.setSpacingAfter(15f);

        PdfPTable detailTable98 = new PdfPTable(2);

        try {
            detailTable98.setTotalWidth(new float[]{600, 10});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable98.setWidthPercentage(110);

// 1 row
        PdfPCell cell98 = new PdfPCell(new Phrase("Name and Address of Selling or Leasing Dealer (print)", times8));
        cell98.setBorder(Rectangle.NO_BORDER);
        cell98.enableBorderSide(1);
        cell98.setBorderWidth(1f);
        detailTable98.addCell(cell98);

// 1 row
        cell98 = new PdfPCell(new Phrase(" ", times10));
        cell98.setBorder(Rectangle.NO_BORDER);
        detailTable98.addCell(cell98);
        detailTable98.setSpacingAfter(15f);

        PdfPTable detailTable99 = new PdfPTable(7);

        try {
            detailTable99.setTotalWidth(new float[]{0, 190, 15, 150, 15, 150, 10});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable99.setWidthPercentage(110);

// 1row
        PdfPCell cell99 = new PdfPCell(new Phrase("", times10));
        cell99.setBorder(Rectangle.NO_BORDER);
        detailTable99.addCell(cell99);

// 2 row
        cell99 = new PdfPCell(new Phrase("Name and Title of Seller's Representative (print)", times8));
        cell99.setBorder(Rectangle.NO_BORDER);
        cell99.setBorderWidth(1f);
        cell99.enableBorderSide(1);
        detailTable99.addCell(cell99);

// 3 row
        cell99 = new PdfPCell(new Phrase("", times10));
        cell99.setBorder(Rectangle.NO_BORDER);
        detailTable99.addCell(cell99);

// 4 row
        cell99 = new PdfPCell(new Phrase("    Signature of Seller's or Lessor's Representative    ", times8));
        cell99.setBorder(Rectangle.NO_BORDER);
        cell99.setBorderWidth(1f);
        cell99.enableBorderSide(1);
        detailTable99.addCell(cell99);

// 5row
        cell99 = new PdfPCell(new Phrase(" ", times9));
        cell99.setBorder(Rectangle.NO_BORDER);
        cell99.setBorderWidth(1f);
        detailTable99.addCell(cell99);

// 6 row
        cell99 = new PdfPCell(new Phrase("         Date        ", times8));
        cell99.setBorder(Rectangle.NO_BORDER);
        cell99.setBorderWidth(1f);
        cell99.enableBorderSide(1);
        detailTable99.addCell(cell99);

// 7 row
        cell99 = new PdfPCell(new Phrase(" ", times9));
        cell99.setBorder(Rectangle.NO_BORDER);
        cell99.setBorderWidth(1f);
        detailTable99.addCell(cell99);

        PdfPTable detailTable931 = new PdfPTable(2);

        try {
            detailTable931.setTotalWidth(new float[]{760, 15});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable931.setWidthPercentage(110);

// 1row
        PdfPCell cell311 = new PdfPCell(new Paragraph(" "));
        cell93.setBorder(Rectangle.NO_BORDER);
        cell93.setPaddingTop(-25);

        Paragraph p311 = new Paragraph();
        Chunk chunk8 = new Chunk("Within", times8);
        Chunk chunk81 = new Chunk(" 30 days", times9bold);
        Chunk chunk82 = new Chunk("of the sale or lease of this vehicle to the ultimate consumer (see definition on attached page), the seller or lessor must send a copy of this\r\n" + "Notice to:",
                times8);
        Chunk chunk83 = new Chunk("Governor's Office of Consumer Affairs, Lemon Law Division, 2 M. L. King, Jr., Drive, Suite 356, Atlanta, GA 30334.", times9bold);
        p311.setLeading(11);
        p311.setPaddingTop(-25);
        p311.add(chunk8);
        p311.add(chunk81);
        p311.add(chunk82);
        p311.add(chunk83);
        cell311.addElement(p311);
        cell311.setBorder(Rectangle.NO_BORDER);
        detailTable931.addCell(cell311);

// 3 row
        PdfPCell cell3111 = new PdfPCell(new Phrase("", times10));
        cell3111.setBorder(Rectangle.NO_BORDER);
        detailTable931.addCell(cell3111);
        detailTable931.setSpacingAfter(2f);

// Table
// 1---------------------------------------------------------------------------------
        PdfPTable detailTable991 = new PdfPTable(3);
        try {
            detailTable991.setTotalWidth(new float[]{15, 880, 30});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable991.setWidthPercentage(110);

        PdfPCell cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        cell991.setPadding(0);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.getDefaultCell().setPaddingTop(-3);

//Table 1---------------------------------------------------------------------------------
        PdfPTable detailTable992 = new PdfPTable(1);
        try {
            detailTable992.setTotalWidth(new float[]{880});
        } catch (DocumentException e1) {

            e1.printStackTrace();
        }
        detailTable992.setWidthPercentage(110);

// 1row
        PdfPCell cell992 = new PdfPCell(new Paragraph("This vehicle was reacquired by FCA US LLC from the original consumer as a result of:  ", times10));
        cell992.setBorder(Rectangle.NO_BORDER);
        detailTable992.addCell(cell992);
        cell992.setBorderWidth(1f);
        detailTable991.getDefaultCell().disableBorderSide(2);
        detailTable991.getDefaultCell().setLeading(11, 0);
        detailTable991.addCell(detailTable992);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setPadding(0);
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 1---------------------------------------------------------------------------------

// Table
// 2---------------------------------------------------------------------------------
        PdfPTable detailTable993 = new PdfPTable(5);
        try {
            detailTable993.setTotalWidth(new float[]{33, 285, 35, 43, 77});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable993.setWidthPercentage(110);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

        PdfPCell cell993 = new PdfPCell(new Paragraph("Part I-A", times9bold));
        cell993.setBorder(Rectangle.NO_BORDER);
        detailTable993.addCell(cell993);
        Paragraph cell993Paragraph = new Paragraph("Check one category and one box within that category for a reacquired vehicle covered under", times9);
        cell993Paragraph.setAlignment(Element.ALIGN_LEFT);
        cell993 = new PdfPCell(cell993Paragraph);
        cell993.setBorder(Rectangle.NO_BORDER);
        cell993.enableBorderSide(2);
        detailTable993.addCell(cell993);
        ;
        cell993 = new PdfPCell(new Paragraph("Georgia's", times9bold));
        cell993.setBorder(Rectangle.NO_BORDER);
        cell993.enableBorderSide(2);
        detailTable993.addCell(cell993);

        cell993 = new PdfPCell(new Paragraph("Lemon Law:", times9));
        cell993.setBorder(Rectangle.NO_BORDER);
        cell993.enableBorderSide(2);
        detailTable993.addCell(cell993);
        cell993 = new PdfPCell(new Paragraph(" ", times9));
        cell993.setBorder(Rectangle.NO_BORDER);
        detailTable993.addCell(cell993);
        cell993.setLeading(10, 0);
        detailTable993.addCell(cell993);
        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable993);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 2---------------------------------------------------------------------------------

        PdfPTable detailTable994 = new PdfPTable(8);
        try {
            detailTable994.setTotalWidth(new float[]{10, 35, 280, 15, 90, 15, 220, 10});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDER2 = null;
        try {
            checkNO_BORDER2 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER2.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        detailTable994.setWidthPercentage(110);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell994 = new PdfPCell(new Paragraph(" ", times9bold));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);

        cell994 = new PdfPCell(new Paragraph(" ", times9bold));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);

        cell994 = new PdfPCell(new Paragraph("A voluntary agreement entered into between the consumer and", times9));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);

        cell994 = new PdfPCell(new Paragraph(""));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell994.enableBorderSide(2);
        detailTable994.addCell(checkNO_BORDER2);

        cell994 = new PdfPCell(new Paragraph("FCA US LLC (or", times9));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);

        cell994 = new PdfPCell(new Paragraph(""));
        detailTable994.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(checkNO_BORDER2);

        cell994 = new PdfPCell(new Paragraph("dealer with FCA US LLC assistance) prior to", times9));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);

        cell994 = new PdfPCell(new Paragraph(" ", times9bold));
        cell994.setBorder(Rectangle.NO_BORDER);
        detailTable994.addCell(cell994);
        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable994);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 3---------------------------------------------------------------------------------

//Table 4---------------------------------------------------------------------------------
        PdfPTable detailTable995 = new PdfPTable(5);
        try {
            detailTable995.setTotalWidth(new float[]{15, 30, 300, 380, 30});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }
        detailTable995.setWidthPercentage(110);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell995 = new PdfPCell(new Paragraph(""));
        cell995.setBorder(Rectangle.NO_BORDER);
        cell995.enableBorderSide(2);
        detailTable995.addCell(cell995);

        cell995 = new PdfPCell(new Paragraph("                            "));
        cell995.setBorder(Rectangle.NO_BORDER);
        cell995.enableBorderSide(2);
        detailTable995.addCell(cell995);

        cell995 = new PdfPCell(new Paragraph("  filing for arbitration or bringing a legal action in Georgia.", times9));
        cell995.setBorder(Rectangle.NO_BORDER);

        detailTable995.addCell(cell995);

        cell995 = new PdfPCell(new Paragraph(" ", times9));
        cell995.setBorder(Rectangle.NO_BORDER);
        detailTable995.addCell(cell995);

        cell995 = new PdfPCell(new Paragraph(""));
        cell995.setBorder(Rectangle.NO_BORDER);
        detailTable995.addCell(cell995);

        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable995);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 4---------------------------------------------------------------------------------

//Table 5---------------------------------------------------------------------------------
        PdfPTable detailTable997 = new PdfPTable(9);
        try {
            detailTable997.setTotalWidth(new float[]{10, 25, 23, 15, 135, 15, 100, 270, 30});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDER3 = null;
        try {
            checkNO_BORDER3 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER3.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        detailTable997.setWidthPercentage(110);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
//1row
        PdfPCell cell997 = new PdfPCell(new Paragraph(" ", times9bold));
        cell997.setBorder(Rectangle.NO_BORDER);
        cell997.enableBorderSide(2);
        detailTable997.addCell(cell997);
        detailTable997.setSpacingBefore(0);

        cell997 = new PdfPCell(new Paragraph(" ", times9bold));
        cell997.setBorder(Rectangle.NO_BORDER);
        cell997.enableBorderSide(2);
        detailTable997.addCell(cell997);

        cell997 = new PdfPCell(new Paragraph(" A", times9bold));
        cell997.setBorder(Rectangle.NO_BORDER);
        detailTable997.addCell(cell997);

        cell997 = new PdfPCell(new Paragraph(""));
        detailTable997.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell997.setBorder(Rectangle.NO_BORDER);
        detailTable997.addCell(checkNO_BORDER3);

        cell997 = new PdfPCell(new Paragraph("settlement reached through or a", times9));
        cell997.setBorder(Rectangle.NO_BORDER);
        detailTable997.addCell(cell997);

        cell997 = new PdfPCell(new Paragraph(""));
        detailTable997.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell997.setBorder(Rectangle.NO_BORDER);
        detailTable997.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        detailTable997.addCell(checkNO_BORDER3);

        cell997 = new PdfPCell(new Paragraph("decision rendered by:", times9));
        cell997.setBorder(Rectangle.NO_BORDER);
        detailTable997.addCell(cell997);

        cell997 = new PdfPCell(new Paragraph("", times9));

        cell997.setBorder(Rectangle.NO_BORDER);
        cell997.enableBorderSide(2);
        cell997.setBorderWidth(1f);
        detailTable997.addCell(cell997);

        cell997 = new PdfPCell(new Paragraph(" ", times9bold));
        cell997.setBorder(Rectangle.NO_BORDER);
        cell997.enableBorderSide(2);
        cell997.setBorderWidth(1f);
        detailTable997.addCell(cell997);

        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable997);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 5---------------------------------------------------------------------------------
//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable44 = new PdfPTable(4);
        try {
            detailTable44.setTotalWidth(new float[]{15, 150, 360, 30});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }

        detailTable44.setWidthPercentage(110);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
//1row
        PdfPCell cell44 = new PdfPCell(new Paragraph(" ", times9bold));
        cell44.setBorder(Rectangle.NO_BORDER);
        detailTable44.addCell(cell44);

        cell44 = new PdfPCell(new Paragraph(" ", times9bold));
        cell44.setBorder(Rectangle.NO_BORDER);
        detailTable44.addCell(cell44);

        cell44 = new PdfPCell(new Paragraph("                                                                         (Name of Informal Dispute Settlement Mechanism [IDSM] for Georgia)", times7));
        cell44.setLeading(8, 0);
        cell44.setBorder(Rectangle.NO_BORDER);
        detailTable44.addCell(cell44);

        cell44 = new PdfPCell(new Paragraph(" ", times9bold));
        cell44.setBorder(Rectangle.NO_BORDER);
        detailTable44.addCell(cell44);
        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable44);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable998 = new PdfPTable(7);
        try {
            detailTable998.setTotalWidth(new float[]{35, 20, 15, 130, 15, 290, 96});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDER4 = null;
        try {
            checkNO_BORDER4 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER4.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        detailTable998.setWidthPercentage(110);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
//1row
        PdfPCell cell998 = new PdfPCell(new Paragraph(" ", times9bold));
        cell998.setBorder(Rectangle.NO_BORDER);
        cell998.enableBorderSide(2);
        detailTable998.addCell(cell998);

        cell998 = new PdfPCell(new Paragraph("A", times9bold));
        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(cell998);

        cell998 = new PdfPCell(new Paragraph(""));
        detailTable998.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(checkNO_BORDER4);

        cell998 = new PdfPCell(new Paragraph("settlement reached through or a", times9));
        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(cell998);

        cell998 = new PdfPCell(new Paragraph(""));
        detailTable998.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(checkNO_BORDER4);

        cell998 = new PdfPCell(new Paragraph("decision rendered by the Georgia New Motor Vehicle Arbitration Panel.", times9));
        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(cell998);

        cell998 = new PdfPCell(new Paragraph("", times9));

        cell998.setBorder(Rectangle.NO_BORDER);
        detailTable998.addCell(cell998);

        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable998);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 5---------------------------------------------------------------------------------

//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable999 = new PdfPTable(7);
        try {
            detailTable999.setTotalWidth(new float[]{35, 20, 15, 130, 15, 290, 96});
        } catch (DocumentException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDER5 = null;
        try {
            checkNO_BORDER5 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER5.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        detailTable999.setWidthPercentage(110);
//detailTable.setLockedWidth(true);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell999 = new PdfPCell(new Paragraph(" ", times9bold));
        cell999.setBorder(Rectangle.NO_BORDER);
        cell999.enableBorderSide(2);
        detailTable999.addCell(cell999);

        cell999 = new PdfPCell(new Paragraph("A", times9bold));
        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(cell999);

        cell999 = new PdfPCell(new Paragraph(""));
        detailTable999.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(checkNO_BORDER5);

        cell999 = new PdfPCell(new Paragraph("settlement reached through or a", times9));
        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(cell999);

        cell999 = new PdfPCell(new Paragraph(""));
        detailTable999.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(checkNO_BORDER5);

        cell999 = new PdfPCell(new Paragraph("decision rendered by a Georgia Court.", times9));
        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(cell999);

        cell999 = new PdfPCell(new Paragraph("", times9));

        cell999.setBorder(Rectangle.NO_BORDER);
        detailTable999.addCell(cell999);

        detailTable991.getDefaultCell().disableBorderSide(1);
        detailTable991.addCell(detailTable999);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 5---------------------------------------------------------------------------------

//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable990 = new PdfPTable(4);
        try {
            detailTable990.setTotalWidth(new float[]{40, 145, 21, 350});
        } catch (DocumentException e1) {
//TODO Auto-generated catch block
            e1.printStackTrace();
        }
        detailTable990.setWidthPercentage(110);
//detailTable.setLockedWidth(true);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell990 = new PdfPCell(new Paragraph("Part I-B", times9bold));
        cell990.setBorder(Rectangle.NO_BORDER);
        detailTable990.addCell(cell990);

        cell990 = new PdfPCell(new Paragraph("Check this category and applicable box only if vehicle was reacquired under a similar statute of another state and was transferred to Georgia:", times9));
        cell990.setBorder(Rectangle.NO_BORDER);
        cell990.enableBorderSide(2);
        detailTable990.addCell(cell990);

        cell990 = new PdfPCell(new Paragraph("only", times9bold));
        cell990.setBorder(Rectangle.NO_BORDER);
        cell990.enableBorderSide(2);
        detailTable990.addCell(cell990);
        cell990 = new PdfPCell(new Paragraph("if vehicle was reacquired under a similar statute of another state and was transferred to Georgia:", times9));
        cell990.setBorder(Rectangle.NO_BORDER);
        cell990.enableBorderSide(2);
        detailTable990.addCell(cell990);
        detailTable991.addCell(detailTable990);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 6---------------------------------------------------------------------------------
//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable11 = new PdfPTable(8);
        try {
            detailTable11.setTotalWidth(new float[]{35, 15, 15, 300, 15, 130, 15, 96});
        } catch (DocumentException e1) {
//TODO Auto-generated catch block
            e1.printStackTrace();
        }

        Image checkNO_BORDER6 = null;
        try {
            checkNO_BORDER6 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER6.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDERCross = null;
        try {
            checkNO_BORDERCross = Image.getInstance(getClass().getResource("/images/checkbox-crossed-31x31.png").getPath());
            checkNO_BORDERCross.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        detailTable11.setWidthPercentage(110);
//detailTable.setLockedWidth(true);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell11 = new PdfPCell(new Paragraph("X", times9bold));
        cell11.setBorder(Rectangle.NO_BORDER);
        cell11.setHorizontalAlignment(Rectangle.ALIGN_CENTER);
        cell11.enableBorderSide(2);
        detailTable11.addCell(cell11);

        cell11 = new PdfPCell(new Paragraph("A", times9bold));
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(cell11);

        cell11 = new PdfPCell(new Paragraph(""));
        detailTable11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(checkNO_BORDERCross);

        cell11 = new PdfPCell(new Paragraph("voluntary agreement entered into without arbitration or a legal action, or a", times9));
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(cell11);

        cell11 = new PdfPCell(new Paragraph(""));
        detailTable11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(checkNO_BORDER6);

        cell11 = new PdfPCell(new Paragraph("settlement reached through or a", times9));
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(cell11);

        cell11 = new PdfPCell(new Paragraph(""));
        detailTable11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(checkNO_BORDER6);

        cell11 = new PdfPCell(new Paragraph("decision", times9));
        cell11.setBorder(Rectangle.NO_BORDER);
        detailTable11.addCell(cell11);
        detailTable991.addCell(detailTable11);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 5---------------------------------------------------------------------------------
//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable22 = new PdfPTable(6);
        try {
            detailTable22.setTotalWidth(new float[]{35, 80, 160, 10, 180, 170});
        } catch (DocumentException e1) {
//TODO Auto-generated catch block
            e1.printStackTrace();
        }

        detailTable22.setWidthPercentage(110);
//detailTable.setLockedWidth(true);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

//1row
        PdfPCell cell22 = new PdfPCell(new Paragraph(" ", times9bold));
        cell22.setBorder(Rectangle.NO_BORDER);
        cell22.enableBorderSide(2);
        detailTable22.addCell(cell22);

        cell22 = new PdfPCell(new Paragraph("rendered by:", times9));
        cell22.setBorder(Rectangle.NO_BORDER);
        detailTable22.addCell(cell22);

        cell22 = new PdfPCell(new Paragraph(""));
        detailTable22.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell22.setBorder(Rectangle.NO_BORDER);
        cell22.enableBorderSide(2);
        detailTable22.addCell(cell22);

        cell22 = new PdfPCell(new Paragraph(", ", times9bold));
        cell22.setBorder(Rectangle.NO_BORDER);
        detailTable22.addCell(cell22);

        cell22 = new PdfPCell(new Paragraph("under a similar statute of the state of:", times9));
        cell22.setBorder(Rectangle.NO_BORDER);
        detailTable22.addCell(cell22);

        cell22 = new PdfPCell(new Paragraph(dto.getStateOfTitle()));
        cell22.setBorder(Rectangle.NO_BORDER);
        cell22.enableBorderSide(2);
        detailTable22.addCell(cell22);

        detailTable991.addCell(detailTable22);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

//Table 6---------------------------------------------------------------------------------
        PdfPTable detailTable33 = new PdfPTable(3);
        try {
            detailTable33.setTotalWidth(new float[]{137, 260, 362});
        } catch (DocumentException e1) {
//TODO Auto-generated catch block
            e1.printStackTrace();
        }

        detailTable33.setWidthPercentage(110);
//detailTable.setLockedWidth(true);
        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        detailTable991.addCell(cell991);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);
        cell991.enableBorderSide(2);
        detailTable991.getDefaultCell().enableBorderSide(2);

//1row
        PdfPCell cell33 = new PdfPCell(new Paragraph(" ", times9bold));
        cell33.setBorder(Rectangle.NO_BORDER);
        detailTable33.addCell(cell33);

        cell33 = new PdfPCell(new Paragraph("Name of IDSM/Arbitration Program/Court", times8));
        cell33.setBorder(Rectangle.NO_BORDER);
        detailTable33.addCell(cell33);

        cell33 = new PdfPCell(new Paragraph("   "));
        detailTable33.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        cell33.setBorder(Rectangle.NO_BORDER);
        detailTable33.addCell(cell33);
        detailTable991.addCell(detailTable33);

        cell991 = new PdfPCell(new Phrase("", times10));
        cell991.setBorder(Rectangle.NO_BORDER);

        detailTable991.addCell(cell991);

        PdfPTable paraStartTable = new PdfPTable(2);
        paraStartTable.setWidthPercentage(110);
        paraStartTable.setSpacingAfter(14f);
        try {
            paraStartTable.setTotalWidth(new float[]{15, 565});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        Image checkNO_BORDER1 = null;
        try {
            checkNO_BORDER1 = Image.getInstance(getClass().getResource("/images/checkbox-blank-31x31.png").getPath());
            checkNO_BORDER1.setAlignment(Image.ALIGN_LEFT);

        } catch (IOException e1) {
            e1.printStackTrace();
        }

        Image checkNO_BORDERCross1 = null;
        try {
            checkNO_BORDERCross1 = Image.getInstance(getClass().getResource("/images/checkbox-crossed-31x31.png").getPath());
            checkNO_BORDERCross1.setAlignment(Image.ALIGN_LEFT);
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        paraStartTable.setLockedWidth(true);
        PdfPCell paraStartCell = new PdfPCell(new Phrase("", arial12));
// paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER1);

        paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by FCA US LLC due to the problem(s) listed below.", arial12));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);

        PdfPTable paraStartTable1 = new PdfPTable(2);
        paraStartTable1.setWidthPercentage(110);
// paraStartTable1.setSpacingAfter(25f);
        try {
            paraStartTable1.setTotalWidth(new float[]{15, 565});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        paraStartTable1.setLockedWidth(true);
        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", arial12));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDERCross1);

        paraStartCell1 = new PdfPCell(new Phrase(
                "IMPORTANT  This vehicle was previously sold as new. It was subsequently returned to the manufacturer or authorized dealer in exchange for a replacement vehicle or a refund because it did not conform to the manufacturer's express warranty and the nonconformity was not cured within a reasonable time as provided by Indiana law.",
                times12bold));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);
        paraStartTable1.setSpacingAfter(15f);

// bigParaTable1
        PdfPTable bigParaTable1 = new PdfPTable(1);
        bigParaTable1.setWidthPercentage(110);

        try {
            bigParaTable1.setTotalWidth(new float[]{580});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        bigParaTable1.setLockedWidth(true);
        PdfPCell bigParaCell1 = new PdfPCell(new Phrase("This vehicle was reacaquired because it was alleged or determined to have one or more of the following nonconformities:", times10bold));
        bigParaCell1.setBorder(Rectangle.NO_BORDER);
        bigParaCell1.setBorderWidth(1f);
        bigParaTable1.addCell(bigParaCell1);

// bigParaTable2
        PdfPTable bigParaTable2 = new PdfPTable(3);
        bigParaTable2.setWidthPercentage(110);

        try {
            bigParaTable2.setTotalWidth(new float[]{20, 565, 30});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        bigParaTable2.setLockedWidth(true);
        PdfPCell bigParaCell2 = new PdfPCell(new Phrase("", courier8));
        bigParaCell2.setBorder(Rectangle.NO_BORDER);
        bigParaTable2.addCell(bigParaCell2);

        bigParaCell2 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getProblem1()), courier8));
        bigParaCell2.setBorder(Rectangle.NO_BORDER);
        bigParaCell2.enableBorderSide(2);
        bigParaCell2.setBorderWidth(1f);
        bigParaTable2.addCell(bigParaCell2);

        bigParaCell2 = new PdfPCell(new Phrase("", courier8));
        bigParaCell2.setBorder(Rectangle.NO_BORDER);
        bigParaTable2.addCell(bigParaCell2);

// bigParaTable3
        PdfPTable bigParaTable3 = new PdfPTable(3);
        bigParaTable3.setWidthPercentage(110);

        try {
            bigParaTable3.setTotalWidth(new float[]{20, 565, 30});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        bigParaTable3.setLockedWidth(true);

        PdfPCell bigParaCell3 = new PdfPCell(new Phrase("", courier8));
        bigParaCell3.setBorder(Rectangle.NO_BORDER);
        bigParaTable3.addCell(bigParaCell3);

        bigParaCell3 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getProblem2()), courier8));
        bigParaCell3.setBorder(Rectangle.NO_BORDER);
        bigParaCell3.enableBorderSide(2);
        bigParaCell3.setBorderWidth(1f);
        bigParaTable3.addCell(bigParaCell3);

        bigParaCell3 = new PdfPCell(new Phrase("", courier8));
        bigParaCell3.setBorder(Rectangle.NO_BORDER);
        bigParaTable3.addCell(bigParaCell3);

// bigParaTable4
        PdfPTable bigParaTable4 = new PdfPTable(3);
        bigParaTable4.setWidthPercentage(110);

        try {
            bigParaTable4.setTotalWidth(new float[]{20, 565, 30});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        bigParaTable4.setLockedWidth(true);

        PdfPCell bigParaCell4 = new PdfPCell(new Phrase("", courier8));
        bigParaCell4.setBorder(Rectangle.NO_BORDER);
        bigParaTable4.addCell(bigParaCell4);

        bigParaCell4 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getProblem3()), courier8));
        bigParaCell4.setBorder(Rectangle.NO_BORDER);
        bigParaCell4.enableBorderSide(2);
        bigParaCell4.setBorderWidth(1f);
        bigParaTable4.addCell(bigParaCell4);

        bigParaCell4 = new PdfPCell(new Phrase("", courier8));
        bigParaCell4.setBorder(Rectangle.NO_BORDER);
        bigParaTable4.addCell(bigParaCell4);

// bigParaTable5
        PdfPTable bigParaTable5 = new PdfPTable(3);
        bigParaTable5.setWidthPercentage(110);

        try {
            bigParaTable5.setTotalWidth(new float[]{20, 565, 30});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        bigParaTable5.setLockedWidth(true);

        PdfPCell bigParaCell5 = new PdfPCell(new Phrase("", courier8));
        bigParaCell5.setBorder(Rectangle.NO_BORDER);
        bigParaTable5.addCell(bigParaCell5);

        bigParaCell5 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getProblem4()), courier8));
        bigParaCell5.setBorder(Rectangle.NO_BORDER);
        bigParaCell5.enableBorderSide(2);
        bigParaCell5.setBorderWidth(1f);
        bigParaTable5.addCell(bigParaCell5);

        bigParaCell5 = new PdfPCell(new Phrase("", courier8));
        bigParaCell5.setBorder(Rectangle.NO_BORDER);
        bigParaTable5.addCell(bigParaCell5);
        bigParaTable5.setSpacingAfter(15f);

// bigParaTable5
        PdfPTable bigLineTable5 = new PdfPTable(3);
        bigLineTable5.setWidthPercentage(110);

        try {
            bigLineTable5.setTotalWidth(new float[]{20, 565, 30});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }
        bigLineTable5.setLockedWidth(true);

        PdfPCell bigLineCell5 = new PdfPCell(new Paragraph());
        bigLineCell5.setBorder(Rectangle.NO_BORDER);
        bigLineCell5.setBorderWidth(2f);
        bigLineTable5.addCell(bigLineCell5);

        bigLineCell5 = new PdfPCell(new Paragraph());
        bigLineCell5.setBorder(Rectangle.NO_BORDER);
        bigLineCell5.enableBorderSide(1);
        bigLineCell5.setBorderWidth(2f);

        Chunk chunk3 = new Chunk("PART II: TO BE COMPLETED BY FCA US LLC UPON TRANSFER OF THE VEHICLE      ", times12bolditalic);
        chunk3.setUnderline(1f, -2f);
        Paragraph p31 = new Paragraph();
        p31.add(chunk3);

        bigLineCell5.addElement(p31);
        bigLineCell5.setPaddingTop(1f);
        bigLineCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        bigLineTable5.addCell(bigLineCell5);

        bigLineCell5 = new PdfPCell(new Paragraph());
        bigLineCell5.setBorder(Rectangle.NO_BORDER);
        bigLineCell5.setBorderWidth(2f);
        bigLineTable5.addCell(bigLineCell5);

        PdfPTable bigParaTable = new PdfPTable(1);
        bigParaTable.setWidthPercentage(110);

        try {
            bigParaTable.setTotalWidth(new float[]{580});
        } catch (DocumentException e2) {
            e2.printStackTrace();
        }

        Chunk chunk1 = new Chunk("PART I: TO BE COMPLETED BY FCA US LLC FOLLOWING REACQUISITION OF THE VEHICLE", times11bolditalic);
        chunk1.setUnderline(1f, -2f);
        bigParaTable.setLockedWidth(true);
        PdfPCell bigParaCell = new PdfPCell(new Paragraph(""));
        Paragraph p1 = new Paragraph();
        p1.add(chunk1);
        bigParaCell.addElement(p1);
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);

        try {
            document.add(cairPageNumTable);
            document.add(titleTable);
            document.add(titleTable1);
            document.add(bigParaTable);
            document.add(detailTable);
            document.add(detail1Table);
            document.add(detail2Table);
            document.add(detail3Table);
            document.add(detailTable991);
            document.add(bigParaTable1);
            document.add(bigParaTable2);
            document.add(bigParaTable3);
            document.add(bigParaTable4);
            document.add(bigParaTable5);
            document.add(detailTable4);
            document.add(bigLineTable5);
            document.add(detailTable5);
            document.add(detailTable6);
            document.add(detailTable7);
            document.add(detailTable8);
            document.add(detailTable9);
            document.add(detailTable91);
            document.add(detailTable92);
            document.add(detailTable93);
            document.add(detailTable94);
            document.add(detailTable95);
            document.add(detailTable96);
            document.add(detailTable97);
            document.add(detailTable98);
            document.add(detailTable99);
            document.add(detailTable931);

        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("###################### PDF Prepared Georgia");
        return document;
    }

    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> list = dtoData.getProblems();

        int lineLength = 104;
        StringBuilder concatenated = new StringBuilder("");
        list.forEach((s) -> concatenated.append(s).append("; "));
        String str = concatenated.substring(0, concatenated.length() - 2);
        logger.info("Initial String: " + str);
        logger.info("Initial String length: " + str.length());

        Map<String, String> map = new HashMap<>();

        int pagesPrinted = 0;
        int linesPrinted = 0;

        while (str.length() > 0) {
            if (pagesPrinted == 0) {
                pagesPrinted++;
                logger.info("----------------printing page*** " + pagesPrinted);
            }
            if (linesPrinted == 4) {
                linesPrinted = 0;
                pagesPrinted++;
                logger.info("----------------printing page## " + pagesPrinted);
            }
            String string_104 = str.length() > lineLength ? str.substring(0, lineLength) : str;
            String remaining = str.length() > lineLength ? str.substring(lineLength) : "";

            if (string_104.endsWith(" ")) {
                logger.info("space     check 104: " + string_104);
                str = remaining;
            } else if (string_104.endsWith(";")) {
                logger.info("semicolon check 104: " + string_104);
                str = remaining.trim();
            } else {
                if (!(string_104.length() < lineLength)) {
                    String new104String = string_104;
                    int spaceIndex = string_104.lastIndexOf(' ');
                    string_104 = new104String.substring(0, spaceIndex);
                    String remaining104StringChunk = new104String.substring(spaceIndex);
                    StringBuilder sbr = new StringBuilder("");
                    sbr.append(remaining104StringChunk);
                    sbr.append(remaining);
                    remaining = sbr.toString();
                    str = remaining.trim();
                } else {
                    str = "";
                }
            }
            linesPrinted++;
            map.put(pagesPrinted + "#" + linesPrinted, string_104);
        }

        // Find total number of Pages to be printed
        int totalPages = pagesPrinted;
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages; pageNum++) {
            if (firstPagePrinted) {
                document.newPage();
            }
            int lineNum = 1;
            dtoData.setProblem1(CommonUtility.returnEmptyStringIfNull(map.get(pageNum + "#" + lineNum++)), false);
            dtoData.setProblem2(CommonUtility.returnEmptyStringIfNull(map.get(pageNum + "#" + lineNum++)), false);
            dtoData.setProblem3(CommonUtility.returnEmptyStringIfNull(map.get(pageNum + "#" + lineNum++)), false);
            dtoData.setProblem4(CommonUtility.returnEmptyStringIfNull(map.get(pageNum + "#" + lineNum)), false);
            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages + 1);
            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        // after all pages are printed, add the Instructions page
        document.newPage();
        document = new GeorgiaInstructionTemplate().createPage(document, totalPages + 1);

        return document;
    }

}
