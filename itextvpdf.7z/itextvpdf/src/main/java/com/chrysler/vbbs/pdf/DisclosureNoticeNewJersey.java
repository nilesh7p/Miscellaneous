package com.chrysler.vbbs.pdf;

import com.chrysler.vbbs.dto.DisclosureTemplatePlaceHolderDto;
import com.chrysler.vbbs.utils.CommonUtility;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.draw.LineSeparator;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

import static com.chrysler.vbbs.pdf.PdfUtility.*;

/**
 * @author 1214662
 * T9450NP 7/16/2018
 */

public class DisclosureNoticeNewJersey {
    Logger logger = Logger.getLogger(DisclosureNoticeNewJersey.class);

    /**
     * @param dtoData  - Data for the Pdf
     * @param document - The common pdf document object that will be used to add requested pages
     * @return document after adding the necessary pages
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPdf(DisclosureTemplatePlaceHolderDto dtoData, Document document) throws IOException, DocumentException {
        List<String> problems = dtoData.getProblems();
        List<String> repairs = dtoData.getRepairsMade();
        int problemsSize = problems.size();
        int repairsSize = repairs.size();

        // Find total number of Pages to be printed
        Double totalPages = problemsSize >= repairsSize ? Math.ceil(problemsSize / 5.0) : Math.ceil(repairsSize / 5.0);
        boolean firstPagePrinted = false;

        for (int pageNum = 1; pageNum <= totalPages.intValue(); pageNum++) {
          /*
          If the first page has been printed, then
          1. signal new page to be added
          2. set the next set of Repairs
          3. Set the next set of Problems
           */
            if (firstPagePrinted) {
                document.newPage();

                int startIndex = (pageNum - 1) * 5;
                dtoData.setRepairMade1(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade2(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade3(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade4(startIndex < repairsSize ? repairs.get(startIndex++) : "");
                dtoData.setRepairMade5(startIndex < repairsSize ? repairs.get(startIndex) : "");
                // Reinitialize Starting Index
                startIndex = (pageNum - 1) * 5;
                dtoData.setProblem1(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem2(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem3(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem4(startIndex < problemsSize ? problems.get(startIndex++) : "", false);
                dtoData.setProblem5(startIndex < problemsSize ? problems.get(startIndex) : "", false);
            }

            // Create the page
            // For the first page, the Problems and Repairs are as received in argument
            // From second page onwards, the Problems and Repairs are being set above
            document = createPage(dtoData, document, pageNum, totalPages.intValue());

            // If the first page is printed, set the flag to true
            if (!firstPagePrinted) {
                firstPagePrinted = true;
            }
        }
        return document;
    }

    /**
     * @param dto            - Data for the Pdf
     * @param document       - The common pdf document object that will be used to add requested pages
     * @param currentPageNum - Page Number of the document being printed
     * @param totalPages     - Total number of pages
     * @return document after adding a page
     * @throws IOException       io exception
     * @throws DocumentException document exception
     */
    public Document createPage(DisclosureTemplatePlaceHolderDto dto, Document document, int currentPageNum, int totalPages) throws DocumentException, IOException {
        BaseFont bf_arial = BaseFont.createFont("fonts/ARIAL.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_arial_bold = BaseFont.createFont("fonts/ARIALBD.TTF", "CP1251", BaseFont.EMBEDDED);
        BaseFont bf_courierNew = BaseFont.createFont("fonts/COUR.TTF", "CP1251", BaseFont.EMBEDDED);
        final Font titleFont = new Font(bf_arial_bold, 18);
        final Font arial7 = new Font(bf_arial, 7);
        final Font arial10 = new Font(bf_arial, 10);
        final Font arial12 = new Font(bf_arial, 12);

        final Font arial8 = new Font(bf_arial, 8);
        final Font courier10 = new Font(bf_courierNew, 10);
        final Font arial11 = new Font(bf_arial, 11);
        final Font arial10Bold = new Font(bf_arial_bold, 10);
        Image image = createImage("/images/logo-fca.png", Image.DEFAULT);
        Image checkNO_BORDER = createImage("/images/checkbox-blank-31x31.png", Image.ALIGN_LEFT);
        Image checkNO_BORDERCross = createImage("/images/checkbox-crossed-31x31.png", Image.ALIGN_LEFT);
        PdfPTable cairPageNumTable = createFullWidthTable(3,new float[]{100, 380, 100});

        PdfPCell cairCell = new PdfPCell(new Phrase(" " + CommonUtility.returnEmptyStringIfNull(dto.getBuybackCair()).trim() + " - " + CommonUtility.returnEmptyStringIfNull(dto.getCurrDate()).trim(), arial8));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(""));
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cairPageNumTable.addCell(cairCell);

        cairCell = new PdfPCell(new Phrase(" Page " + currentPageNum + " of " + totalPages, arial8));
        cairCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cairCell.setBorder(Rectangle.NO_BORDER);
        cairPageNumTable.addCell(cairCell);

        cairPageNumTable.setSpacingAfter(11f);


        PdfPTable titleTable = createFullWidthTable(4,new float[]{150, 200, 100, 130});

        PdfPCell titleCell = new PdfPCell();
        titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);

        titleTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);

        titleTable.getDefaultCell().setFixedHeight(32f);
        titleTable.getDefaultCell().setPaddingLeft(3);
        titleCell.setHorizontalAlignment(Element.ALIGN_TOP);
        titleTable.getDefaultCell().setPaddingTop(-7);
        titleTable.addCell(image);

        titleCell = new PdfPCell(new Phrase("DISCLOSURE NOTICE", titleFont));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        titleCell.setFixedHeight(15f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("- NEW JERSEY", arial10Bold));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setPaddingTop(10f);
        titleCell.setFixedHeight(1f);
        titleTable.addCell(titleCell);

        titleCell = new PdfPCell(new Phrase("\r Rev. 06/17", arial7));
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        titleTable.addCell(titleCell);
        titleTable.setSpacingAfter(-5f);

        LineSeparator lineTitle = new LineSeparator();
        lineTitle.setOffset(-5);
        lineTitle.setPercentage(107);
        lineTitle.setLineWidth(3.3f);

        PdfPTable checkOneTable = createFullWidthTable(1,new float[]{580});

        PdfPCell checkOneCell = new PdfPCell(new Phrase("(Check One)", arial12));
        checkOneCell.setBorder(Rectangle.NO_BORDER);
        checkOneCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        checkOneCell.setLeft(-100);
        checkOneTable.addCell(checkOneCell);
        checkOneTable.setSpacingBefore(10f);
        checkOneTable.setSpacingAfter(10f);

        PdfPTable paraStartTable = createFullWidthTable(2,new float[]{15, 565});

        paraStartTable.setSpacingAfter(14f);

        PdfPCell paraStartCell = new PdfPCell(new Phrase("", arial12));

        paraStartTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(checkNO_BORDER);

        paraStartCell = new PdfPCell(new Phrase("In an effort to promote customer satisfaction, this vehicle was repurchased by FCA US LLC due to the problem(s) listed below.", arial12));
        paraStartCell.setBorder(Rectangle.NO_BORDER);
        paraStartCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable.addCell(paraStartCell);

        PdfPTable paraStartTable1 = createFullWidthTable(2,new float[]{15, 565});

        paraStartTable1.setSpacingAfter(25f);

        PdfPCell paraStartCell1 = new PdfPCell(new Phrase("", arial12));
        paraStartTable1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(checkNO_BORDERCross);

        paraStartCell1 = new PdfPCell(new Phrase("IMPORTANT: THIS VEHICLE WAS RETURNED TO THE MANUFACTURER BECAUSE IT DID NOT CONFORM TO THE\n" +
                "MANUFACTURER'S WARRANTY AND THE NONCONFORMITY WAS NOT CORRECTED WITHIN A REASONABLE TIME\n" +
                "AS PROVIDED BY LAW.", arial10Bold));
        paraStartCell1.setBorder(Rectangle.NO_BORDER);
        paraStartCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        paraStartTable1.addCell(paraStartCell1);

        PdfPTable tableVehCoreData = createFullWidthTable(4,new float[]{162, 52, 93, 270});

        PdfPCell c1 = new PdfPCell(new Phrase("VIN", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_LEFT);

        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("YEAR", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MAKE", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase("MODEL", arial12));
        c1.setBorder(Rectangle.NO_BORDER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setHeaderRows(1);

        c1 = new PdfPCell(new Phrase(dto.getVin(), courier10));
        c1.setBorderWidth(1f);
        c1.setFixedHeight(22f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getYear(), courier10));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getMake(), courier10));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);

        c1 = new PdfPCell(new Phrase(dto.getModel(), courier10));
        c1.setBorderWidth(1f);
        c1.setVerticalAlignment(Element.ALIGN_CENTER);
        tableVehCoreData.addCell(c1);
        tableVehCoreData.setSpacingAfter(11f);

        PdfPTable problemsHeadTable = createFullWidthTable(2,new float[]{290, 290});

        PdfPCell cellHead = new PdfPCell(new Phrase("Reported Problem(s):", arial12));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);

        cellHead = new PdfPCell(new Phrase("    " + "Date Repaired or Other Comments:", arial12));
        cellHead.setBorder(Rectangle.NO_BORDER);
        problemsHeadTable.addCell(cellHead);
        problemsHeadTable.setSpacingAfter(5f);
        PdfPTable problemsTable = createFullWidthTable(5,new float[]{15, 260, 30, 15, 260});

        PdfPCell cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setFixedHeight(23f);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem1(), courier10));

        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("1. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade1(), courier10));

        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("2. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade2(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("3. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade3(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("4. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade4(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorderWidth(1f);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getProblem5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(" "));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase("5. ", arial11));
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.setFixedHeight(23f);
        cellPT.setVerticalAlignment(Element.ALIGN_BOTTOM);
        problemsTable.addCell(cellPT);

        cellPT = new PdfPCell(new Phrase(dto.getRepairMade5(), courier10));
        cellPT.setBorderWidth(1f);
        cellPT.setMinimumHeight(23f);
        cellPT.setBorder(Rectangle.NO_BORDER);
        cellPT.enableBorderSide(2);
        problemsTable.addCell(cellPT);
        problemsTable.setSpacingAfter(15f);

        PdfPTable addInfoTable = createFullWidthTable(2,new float[]{130, 450});

        PdfPCell cellAddInfo = new PdfPCell(new Phrase("Additional Information:", arial12));
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        addInfoTable.addCell(cellAddInfo);

        cellAddInfo = new PdfPCell(new Phrase(dto.getAdditionalInfoLine1(), courier10));
        cellAddInfo.setBorderWidth(1f);
        cellAddInfo.setBorder(Rectangle.NO_BORDER);
        cellAddInfo.enableBorderSide(2);
        addInfoTable.addCell(cellAddInfo);
        addInfoTable.setSpacingAfter(6);
        PdfPTable fullLineTable = createFullWidthTable(1,new float[]{580});

        PdfPCell cellPT12 = new PdfPCell(new Phrase(CommonUtility.returnEmptyStringIfNull(dto.getAdditionalInfoLine2()), courier10));
        cellPT12.setBorder(Rectangle.NO_BORDER);
        cellPT12.setBorderWidth(1f);
        cellPT12.enableBorderSide(2);
        fullLineTable.addCell(cellPT12);
        fullLineTable.setSpacingAfter(18f);

        PdfPTable bigParaTable = createFullWidthTable(1,new float[]{580});

        PdfPCell bigParaCell = new PdfPCell(new Phrase(
                "The signature of the dealer representative constitutes agreement by the dealer that disclosure of the above information will be made to the retail customer at the time of sale of this vehicle as provided by law in the state in which it is resold. The dealer agrees to defend, indemnify, and hold harmless FCA US LLC from all claims, causes of action, or any other liability arising from or related to the dealer's failure to make proper disclosure of the above information, whether or not disclosure is required by state or federal law. FCA US LLC provides a supplemental Limited Warranty for a period of 12 months with unlimited mileage effective with the date of purchase or lease of this vehicle by the subsequent retail buyer. Additionally, this vehicle may be eligible for any remaining new vehicle warranty coverage.",
                arial10));
        bigParaCell.setBorder(Rectangle.NO_BORDER);
        bigParaTable.addCell(bigParaCell);
        bigParaTable.setSpacingAfter(25f);

        // Init common cells/elements
        PdfPCell underlineBlankCell = createUnderlineCell();
        PdfPCell blankCell = createClearCell();
        PdfPCell currentDateCell = createUnderlineContentCell(dto.getCurrentDate(), courier10, Rectangle.ALIGN_LEFT);
        PdfPCell dateTextCell = createSignatoryCell("Date", arial8, Rectangle.ALIGN_RIGHT);
        dateTextCell.setPaddingRight(10);

        // FCA Representative and Auction Representative
        PdfPTable fca_rep_signature = createSignatureTable();
        // Line 1
        fca_rep_signature.addCell(underlineBlankCell);
        fca_rep_signature.addCell(currentDateCell);
        fca_rep_signature.addCell(blankCell);
        fca_rep_signature.addCell(underlineBlankCell);
        fca_rep_signature.addCell(currentDateCell);

        // Line 2
        fca_rep_signature.addCell(createSignatoryCell("FCA US LLC Representative Signature", arial8, Rectangle.ALIGN_LEFT));
        fca_rep_signature.addCell(dateTextCell);
        fca_rep_signature.addCell(blankCell);
        fca_rep_signature.addCell(createSignatoryCell("Auction Representative Signature/Title", arial8, Rectangle.ALIGN_LEFT));
        fca_rep_signature.addCell(dateTextCell);

        // Dealer Representative and Customer Acknowledgement
        PdfPTable dlr_rep_signature = createSignatureTable();
        // Line 1
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(blankCell);
        dlr_rep_signature.addCell(underlineBlankCell);
        dlr_rep_signature.addCell(underlineBlankCell);

        // Line 2
        dlr_rep_signature.addCell(createSignatoryCell("Dealer Representative Signature/Title", arial8, Rectangle.ALIGN_LEFT));
        dlr_rep_signature.addCell(dateTextCell);
        dlr_rep_signature.addCell(blankCell);
        dlr_rep_signature.addCell(createSignatoryCell("Customer Acknowledgement/Signature", arial8, Rectangle.ALIGN_LEFT));
        dlr_rep_signature.addCell(dateTextCell);

        // Printed names
        PdfPTable printed_name = createSignatureTable();
        // Line 1
        printed_name.addCell(underlineBlankCell);
        PdfPCell dealerCodeCell = createUnderlineContentCell(dto.getDealerCode(), courier10, Rectangle.ALIGN_RIGHT);
        dealerCodeCell.setPaddingRight(15);
        printed_name.addCell(dealerCodeCell);
        printed_name.addCell(blankCell);
        printed_name.addCell(underlineBlankCell);
        printed_name.addCell(underlineBlankCell);

        // Line 2
        // Dealer Code Text
        PdfPCell dealerCodeTextCell = createClearCell();
        dealerCodeTextCell.setPaddingTop(-2);
        dealerCodeTextCell.setPaddingRight(10);
        Paragraph dealerCodeText = new Paragraph("Dealer Code", arial8);
        dealerCodeText.setAlignment(Rectangle.ALIGN_RIGHT);
        dealerCodeTextCell.addElement(dealerCodeText);

        printed_name.addCell(createSignatoryCell("Printed Name", arial8, Rectangle.ALIGN_LEFT));
        printed_name.addCell(dealerCodeTextCell);
        printed_name.addCell(blankCell);
        printed_name.addCell(createSignatoryCell("Printed Name", arial8, Rectangle.ALIGN_LEFT));
        printed_name.addCell(blankCell);

        // Dealership details table
        PdfPTable dealership_table = createSignatureTable();

        // Line 1
        dealership_table.addCell(createUnderlineContentCell(CommonUtility.returnEmptyStringIfNull(dto.getDealerName()).trim().concat(","), courier10, Rectangle.ALIGN_LEFT));
        PdfPCell stateCodeCell = createUnderlineContentCell(dto.getDealerState(), courier10, Rectangle.ALIGN_RIGHT);
        stateCodeCell.setPaddingRight(15);
        dealership_table.addCell(stateCodeCell);
        dealership_table.addCell(blankCell);
        dealership_table.addCell(createUnderlineContentCell(" ", courier10, Rectangle.ALIGN_LEFT));
        dealership_table.addCell(createUnderlineContentCell(" ", courier10, Rectangle.ALIGN_LEFT));

        // Line 2
        dealership_table.addCell(createSignatoryCell("Dealership Name", arial8, Rectangle.ALIGN_LEFT));
        PdfPCell stateTextCell = createSignatoryCell("State", arial8, Rectangle.ALIGN_RIGHT);
        stateTextCell.setPaddingRight(10);
        dealership_table.addCell(stateTextCell);
        dealership_table.addCell(blankCell);
        dealership_table.addCell(createSignatoryCell("Street & No.                              City/Town", arial8, Rectangle.ALIGN_LEFT));
        PdfPCell cityTownState = createSignatoryCell("      State", arial8, Rectangle.ALIGN_CENTER);
        dealership_table.addCell(cityTownState);

        document.add(cairPageNumTable);
        document.add(titleTable);
        document.add(lineTitle);
        document.add(checkOneTable);
        document.add(paraStartTable);
        document.add(paraStartTable1);
        document.add(tableVehCoreData);
        document.add(problemsHeadTable);
        document.add(problemsTable);
        document.add(addInfoTable);
        document.add(fullLineTable);
        document.add(fca_rep_signature);
        document.add(bigParaTable);
        document.add(dlr_rep_signature);
        document.add(printed_name);
        document.add(dealership_table);

        logger.info("###################### PDF Prepared New Jersey");

        return document;
    }

}
