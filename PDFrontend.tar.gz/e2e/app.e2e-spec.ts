import { PDFrontendPage } from './app.po';

describe('pdfrontend App', () => {
  let page: PDFrontendPage;

  beforeEach(() => {
    page = new PDFrontendPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
