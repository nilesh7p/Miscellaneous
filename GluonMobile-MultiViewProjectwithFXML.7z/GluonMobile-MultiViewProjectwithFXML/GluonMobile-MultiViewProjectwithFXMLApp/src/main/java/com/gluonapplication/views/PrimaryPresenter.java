package com.gluonapplication.views;

import com.gluonhq.charm.glisten.application.MobileApplication;
import com.gluonhq.charm.glisten.control.AppBar;
import com.gluonhq.charm.glisten.mvc.View;
import com.gluonhq.charm.glisten.visual.MaterialDesignIcon;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PrimaryPresenter {


    @FXML
    private View primary;

    @FXML
    private Label label;

    @FXML
    private Label mainSongName;

    @FXML
    private Button selectMain;

    @FXML
    private Button playMain;

    @FXML
    private Button stopMain;

    @FXML
    private Label song1;

    @FXML
    private Button selectSong1;

    @FXML
    private Button playsong1;

    @FXML
    private Button stopsong1;

    @FXML
    private Label song2;

    @FXML
    private Button selectsong2;

    @FXML
    private Button playsong2;

    @FXML
    private Button stopsong2;

    @FXML
    private Label song3;

    @FXML
    private Button selectsong3;

    @FXML
    private Button playsong3;

    @FXML
    private Button stopsong3;

    @FXML
    private Label song4;

    @FXML
    private Button selectsong4;

    @FXML
    private Button playsong4;

    @FXML
    private Button stopsong4;

    @FXML
    private Label song5;

    @FXML
    private Button selectsong5;

    @FXML
    private Button playsong5;

    @FXML
    private Button stopsong5;

    @FXML
    private Label song6;

    @FXML
    private Button selectsong6;

    @FXML
    private Button playsong6;

    @FXML
    private Button stopsong6;

    @FXML
    private Label song7;

    @FXML
    private Button selectsong7;

    @FXML
    private Button playsong7;

    @FXML
    private Button stopsong7;

    @FXML
    private Label song8;

    @FXML
    private Button selectsong8;

    @FXML
    private Button playsong8;

    @FXML
    private Button stopsong8;

    @FXML
    private Label song9;

    @FXML
    private Button selectsong9;

    @FXML
    private Button playsong9;

    @FXML
    private Button stopsong9;

    @FXML
    private Label song10;

    @FXML
    private Button selectsong10;

    @FXML
    private Button playsong10;

    @FXML
    private Button stopsong10;

    @FXML
    private Label song11;

    @FXML
    private Button selectsong11;

    @FXML
    private Button playsong11;

    @FXML
    private Button stopsong11;

    @FXML
    private Label song12;

    @FXML
    private Button selectsong12;

    @FXML
    private Button playsong12;

    @FXML
    private Button stopsong12;

    @FXML
    private Label song13;

    @FXML
    private Button selectsong13;

    @FXML
    private Button playsong13;

    @FXML
    private Button stopsong13;

    @FXML
    private Label song14;

    @FXML
    private Button selectsong14;

    @FXML
    private Button playsong14;

    @FXML
    private Button stopsong14;

    @FXML
    private Label song15;

    @FXML
    private Button selectsong15;

    @FXML
    private Button playsong15;

    @FXML
    private Button stopsong15;

    @FXML
    private Label song16;

    @FXML
    private Button selectsong16;

    @FXML
    private Button playsong16;

    @FXML
    private Button stopsong16;

    @FXML
    private Label song17;

    @FXML
    private Button selectsong17;

    @FXML
    private Button playsong17;

    @FXML
    private Button stopsong17;

    @FXML
    private Label song18;

    @FXML
    private Button selectsong18;

    @FXML
    private Button playsong18;

    @FXML
    private Button stopsong18;

    @FXML
    private Label song19;

    @FXML
    private Button selectsong19;

    @FXML
    private Button playsong19;

    @FXML
    private Button stopsong19;

    @FXML
    private Label song20;

    @FXML
    private Button selectsong20;

    @FXML
    private Button playsong20;

    @FXML
    private Button stopsong20;

    @FXML
    private Label song21;

    @FXML
    private Button selectsong21;

    @FXML
    private Button playsong21;

    @FXML
    private Button stopsong21;

    @FXML
    void playMain(ActionEvent event) {

    }

    @FXML
    void playsong1(ActionEvent event) {

    }

    @FXML
    void playsong10(ActionEvent event) {

    }

    @FXML
    void playsong11(ActionEvent event) {

    }

    @FXML
    void playsong12(ActionEvent event) {

    }

    @FXML
    void playsong13(ActionEvent event) {

    }

    @FXML
    void playsong14(ActionEvent event) {

    }

    @FXML
    void playsong15(ActionEvent event) {

    }

    @FXML
    void playsong16(ActionEvent event) {

    }

    @FXML
    void playsong17(ActionEvent event) {

    }

    @FXML
    void playsong18(ActionEvent event) {

    }

    @FXML
    void playsong19(ActionEvent event) {

    }

    @FXML
    void playsong2(ActionEvent event) {

    }

    @FXML
    void playsong20(ActionEvent event) {

    }

    @FXML
    void playsong21(ActionEvent event) {

    }

    @FXML
    void playsong3(ActionEvent event) {

    }

    @FXML
    void playsong4(ActionEvent event) {

    }

    @FXML
    void playsong5(ActionEvent event) {

    }

    @FXML
    void playsong6(ActionEvent event) {

    }

    @FXML
    void playsong7(ActionEvent event) {

    }

    @FXML
    void playsong8(ActionEvent event) {

    }

    @FXML
    void playsong9(ActionEvent event) {

    }

    @FXML
    void selectMain(ActionEvent event) {

    }

    @FXML
    void selectSong1(ActionEvent event) {

    }

    @FXML
    void selectsong10(ActionEvent event) {

    }

    @FXML
    void selectsong11(ActionEvent event) {

    }

    @FXML
    void selectsong12(ActionEvent event) {

    }

    @FXML
    void selectsong13(ActionEvent event) {

    }

    @FXML
    void selectsong14(ActionEvent event) {

    }

    @FXML
    void selectsong15(ActionEvent event) {

    }

    @FXML
    void selectsong16(ActionEvent event) {

    }

    @FXML
    void selectsong17(ActionEvent event) {

    }

    @FXML
    void selectsong18(ActionEvent event) {

    }

    @FXML
    void selectsong19(ActionEvent event) {

    }

    @FXML
    void selectsong2(ActionEvent event) {

    }

    @FXML
    void selectsong20(ActionEvent event) {

    }

    @FXML
    void selectsong21(ActionEvent event) {

    }

    @FXML
    void selectsong3(ActionEvent event) {

    }

    @FXML
    void selectsong4(ActionEvent event) {

    }

    @FXML
    void selectsong5(ActionEvent event) {

    }

    @FXML
    void selectsong6(ActionEvent event) {

    }

    @FXML
    void selectsong7(ActionEvent event) {

    }

    @FXML
    void selectsong8(ActionEvent event) {

    }

    @FXML
    void selectsong9(ActionEvent event) {

    }

    @FXML
    void stopMain(ActionEvent event) {

    }

    @FXML
    void stopsong1(ActionEvent event) {

    }

    @FXML
    void stopsong10(ActionEvent event) {

    }

    @FXML
    void stopsong11(ActionEvent event) {

    }

    @FXML
    void stopsong12(ActionEvent event) {

    }

    @FXML
    void stopsong13(ActionEvent event) {

    }

    @FXML
    void stopsong14(ActionEvent event) {

    }

    @FXML
    void stopsong15(ActionEvent event) {

    }

    @FXML
    void stopsong16(ActionEvent event) {

    }

    @FXML
    void stopsong17(ActionEvent event) {

    }

    @FXML
    void stopsong18(ActionEvent event) {

    }

    @FXML
    void stopsong19(ActionEvent event) {

    }

    @FXML
    void stopsong2(ActionEvent event) {

    }

    @FXML
    void stopsong20(ActionEvent event) {

    }

    @FXML
    void stopsong21(ActionEvent event) {

    }

    @FXML
    void stopsong3(ActionEvent event) {

    }

    @FXML
    void stopsong4(ActionEvent event) {

    }

    @FXML
    void stopsong5(ActionEvent event) {

    }

    @FXML
    void stopsong6(ActionEvent event) {

    }

    @FXML
    void stopsong7(ActionEvent event) {

    }

    @FXML
    void stopsong8(ActionEvent event) {

    }

    @FXML
    void stopsong9(ActionEvent event) {

    }

    List<Button> selectButtons;
    List<Button> playButtons;
    List<Button> stopButtons;
    List<Label> labelNames;

    public void initialize() {
        primary.showingProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue) {
                AppBar appBar = MobileApplication.getInstance().getAppBar();
                appBar.setNavIcon(MaterialDesignIcon.MENU.button(e ->
                        MobileApplication.getInstance().getDrawer().open()));
                appBar.setTitleText("Primary");
                appBar.getActionItems().add(MaterialDesignIcon.SEARCH.button(e ->
                        System.out.println("Search")));
            }
        });

        selectButtons = Arrays.asList(selectMain, selectSong1, selectsong2, selectsong3, selectsong4, selectsong5, selectsong6, selectsong7, selectsong8, selectsong9, selectsong10, selectsong11, selectsong12, selectsong13, selectsong14, selectsong15, selectsong16, selectsong17, selectsong18, selectsong19, selectsong20, selectsong21);
        playButtons = Arrays.asList(playMain, playsong1, playsong2, playsong3, playsong4, playsong5, playsong6, playsong7, playsong8, playsong9, playsong10, playsong11, playsong12, playsong13, playsong14, playsong15, playsong16, playsong17, playsong18, playsong19, playsong20, playsong21);
        stopButtons = Arrays.asList(stopMain, stopsong1, stopsong2, stopsong3, stopsong4, stopsong5, stopsong6, stopsong7, stopsong8, stopsong9, stopsong10, stopsong11, stopsong12, stopsong13, stopsong14, stopsong15, stopsong16, stopsong17, stopsong18, stopsong19, stopsong20, stopsong21);
        labelNames = Arrays.asList(mainSongName, song1, song2, song3, song4, song5, song6, song7, song8, song9, song10, song11, song12, song13, song14, song15, song16, song17, song18, song19, song20, song21);


        selectButtons.forEach(button -> button.setOnAction(event -> {
            String id = ((Button) event.getSource()).getId();
            switch (id) {
                case "selectMain":
                    selectSong(mainSongName, playMain);
                    break;
                case "selectSong1":
                    selectSong(song1, playsong1);
                    break;
                case "selectsong2":
                    selectSong(song2, playsong2);
                    break;
                case "selectsong3":
                    selectSong(song3, playsong3);
                    break;
                case "selectsong4":
                    selectSong(song4, playsong4);
                    break;
                case "selectsong5":
                    selectSong(song5, playsong5);
                    break;
                case "selectsong6":
                    selectSong(song6, playsong6);
                    break;
                case "selectsong7":
                    selectSong(song7, playsong7);
                    break;
                case "selectsong8":
                    selectSong(song8, playsong8);
                    break;
                case "selectsong9":
                    selectSong(song9, playsong9);
                    break;
                case "selectsong10":
                    selectSong(song10, playsong10);
                    break;
                case "selectsong11":
                    selectSong(song11, playsong11);
                    break;
                case "selectsong12":
                    selectSong(song12, playsong12);
                    break;
                case "selectsong13":
                    selectSong(song13, playsong13);
                    break;
                case "selectsong14":
                    selectSong(song14, playsong14);
                    break;
                case "selectsong15":
                    selectSong(song15, playsong15);
                    break;
                case "selectsong16":
                    selectSong(song16, playsong16);
                    break;
                case "selectsong17":
                    selectSong(song17, playsong17);
                    break;
                case "selectsong18":
                    selectSong(song18, playsong18);
                    break;
                case "selectsong19":
                    selectSong(song19, playsong19);
                    break;
                case "selectsong20":
                    selectSong(song20, playsong20);
                    break;
                case "selectsong21":
                    selectSong(song21, playsong21);
                    break;
            }
        }));

        playButtons.forEach(button -> {
            button.setDisable(true);
            button.setOnAction(event -> {
                String id = ((Button) event.getSource()).getId();
                switch (id) {
                    case "playMain":
                        playMainSong(mainSongName.getId(), stopMain);
                        break;
                    case "playsong1":
                        playSong(song1.getId(), stopsong1);
                        break;
                    case "playsong2":
                        playSong(song2.getId(), stopsong2);
                        break;
                    case "playsong3":
                        playSong(song3.getId(), stopsong3);
                        break;
                    case "playsong4":
                        playSong(song4.getId(), stopsong4);
                        break;
                    case "playsong5":
                        playSong(song5.getId(), stopsong5);
                        break;
                    case "playsong6":
                        playSong(song6.getId(), stopsong6);
                        break;
                    case "playsong7":
                        playSong(song7.getId(), stopsong7);
                        break;
                    case "playsong8":
                        playSong(song8.getId(), stopsong8);
                        break;
                    case "playsong9":
                        playSong(song9.getId(), stopsong9);
                        break;
                    case "playsong10":
                        playSong(song10.getId(), stopsong10);
                        break;
                    case "playsong11":
                        playSong(song11.getId(), stopsong11);
                        break;
                    case "playsong12":
                        playSong(song12.getId(), stopsong12);
                        break;
                    case "playsong13":
                        playSong(song13.getId(), stopsong13);
                        break;
                    case "playsong14":
                        playSong(song14.getId(), stopsong14);
                        break;
                    case "playsong15":
                        playSong(song15.getId(), stopsong15);
                        break;
                    case "playsong16":
                        playSong(song16.getId(), stopsong16);
                        break;
                    case "playsong17":
                        playSong(song17.getId(), stopsong17);
                        break;
                    case "playsong18":
                        playSong(song18.getId(), stopsong18);
                        break;
                    case "playsong19":
                        playSong(song19.getId(), stopsong19);
                        break;
                    case "playsong20":
                        playSong(song20.getId(), stopsong20);
                        break;
                    case "playsong21":
                        playSong(song21.getId(), stopsong21);
                        break;
                }
            });
        });

        stopButtons.forEach(button -> {
            button.setDisable(true);
            button.setOnAction(event -> {
                String id = ((Button) event.getSource()).getId();
                switch (id) {
                    case "stopMain":
                        stopMainSong(mainSongName.getId());
                        break;
                    case "stopsong1":
                        stopSong(song1.getId());
                        break;
                    case "stopsong2":
                        stopSong(song2.getId());
                        break;
                    case "stopsong3":
                        stopSong(song3.getId());
                        break;
                    case "stopsong4":
                        stopSong(song4.getId());
                        break;
                    case "stopsong5":
                        stopSong(song5.getId());
                        break;
                    case "stopsong6":
                        stopSong(song6.getId());
                        break;
                    case "stopsong7":
                        stopSong(song7.getId());
                        break;
                    case "stopsong8":
                        stopSong(song8.getId());
                        break;
                    case "stopsong9":
                        stopSong(song9.getId());
                        break;
                    case "stopsong10":
                        stopSong(song10.getId());
                        break;
                    case "stopsong11":
                        stopSong(song11.getId());
                        break;
                    case "stopsong12":
                        stopSong(song12.getId());
                        break;
                    case "stopsong13":
                        stopSong(song13.getId());
                        break;
                    case "stopsong14":
                        stopSong(song14.getId());
                        break;
                    case "stopsong15":
                        stopSong(song15.getId());
                        break;
                    case "stopsong16":
                        stopSong(song16.getId());
                        break;
                    case "stopsong17":
                        stopSong(song17.getId());
                        break;
                    case "stopsong18":
                        stopSong(song18.getId());
                        break;
                    case "stopsong19":
                        stopSong(song19.getId());
                        break;
                    case "stopsong20":
                        stopSong(song20.getId());
                        break;
                    case "stopsong21":
                        stopSong(song21.getId());
                        break;
                }
            });
        });
    }

    private void stopMainSong(String id) {
        if (playerMainPaused || playerMainplaying) {
            mediaPlayerMain.stop();
            playerMainplaying = false;
            playerMainPaused = false;
        }
    }

    private void stopSong(String id) {
        if (player1playing) {
            mediaPlayer1.stop();
            player1playing = false;
        }
        if (player2playing) {
            mediaPlayer2.stop();
            player2playing = false;
        }
        if (playerMainPaused) {
            mediaPlayerMain.play();
            playerMainplaying = true;
            playerMainPaused = false;
        }
    }


    MediaPlayer mediaPlayer1;
    MediaPlayer mediaPlayer2;
    MediaPlayer mediaPlayerMain;
    boolean player1playing = false;
    boolean player2playing = false;
    boolean playerMainplaying = false;
    boolean playerMainPaused = false;

    private void playMainSong(String id, Button stopMain) {

        File file = new File(songs.get(id));
        Media media = new Media(file.toURI().toString());
        mediaPlayerMain = new MediaPlayer(media);

        if (player1playing) {
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer1.volumeProperty(), 0))
            );
            timeline.play();
            timeline.setOnFinished(event -> {
                mediaPlayer1.stop();
                player1playing = false;
            });

        }
        if (player2playing) {
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer2.volumeProperty(), 0))
            );
            timeline.play();
            timeline.setOnFinished(event -> {
                mediaPlayer2.stop();
                player2playing = false;
            });

        }

        mediaPlayerMain.setVolume(0.0);
        mediaPlayerMain.play();
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(0), new KeyValue(mediaPlayerMain.volumeProperty(), 0)),
                new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayerMain.volumeProperty(), 50))
        );
        timeline.play();

        playerMainplaying = true;

        stopMain.setDisable(false);
    }

    private void playSong(String id, Button button) {
        File file = new File(songs.get(id));
        Media media = new Media(file.toURI().toString());
        if (player1playing) {
            if (playerMainplaying) {
                Timeline timeline = new Timeline(
                        new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayerMain.volumeProperty(), 0))
                );
                timeline.setOnFinished(event -> {
                    mediaPlayerMain.pause();
                    playerMainPaused = true;
                });
                timeline.play();
            }

            Timeline timeline1 = new Timeline(
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer1.volumeProperty(), 0))
            );
            timeline1.setOnFinished(event -> {
                mediaPlayer1.stop();
                mediaPlayer1 = null;
                player1playing = false;
            });
            timeline1.play();

            mediaPlayer2 = new MediaPlayer(media);
            mediaPlayer2.setVolume(0.0);

            Timeline timeline2 = new Timeline(
                    new KeyFrame(Duration.seconds(0), new KeyValue(mediaPlayer2.volumeProperty(), 0)),
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer2.volumeProperty(), 50))
            );
            timeline2.setOnFinished(event -> {
                player2playing = true;
            });
            mediaPlayer2.play();
        } else if (player2playing) {
            if (playerMainplaying) {
                Timeline timeline = new Timeline(
                        new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayerMain.volumeProperty(), 0))
                );
                timeline.play();
                timeline.setOnFinished(event -> {
                    mediaPlayerMain.pause();
                    playerMainPaused = true;
                });
            }
            Timeline timeline2 = new Timeline(
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer1.volumeProperty(), 0))
            );
            timeline2.setOnFinished(event -> {
                mediaPlayer2.stop();
                mediaPlayer2 = null;
                player2playing = false;
            });


            mediaPlayer1 = new MediaPlayer(media);
            mediaPlayer1.setVolume(0.0);
            mediaPlayer1.play();

            Timeline timeline1 = new Timeline(
                    new KeyFrame(Duration.seconds(5), new KeyValue(mediaPlayer1.volumeProperty(), 50))
            );
            timeline1.setOnFinished(event -> {
                player1playing = true;
            });
            timeline1.play();

        } else {
            if (playerMainplaying) {
                mediaPlayerMain.pause();
                playerMainPaused = true;
            }
            mediaPlayer1 = new MediaPlayer(media);
            mediaPlayer1.play();
            player1playing = true;
        }
        button.setDisable(false);
    }

    final FileChooser fileChooser = new FileChooser();


    private void selectSong(Label label, Button button) {

        Stage stage = (Stage) primary.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            songs.put(label.getId(), file.getPath());
            label.setText(file.getName());
            button.setDisable(false);
        }
    }

    private static void configureFileChooser(final FileChooser fileChooser) {
        fileChooser.setTitle("select song");
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
    }

    Map<String, String> songs = new HashMap<>();

    @FXML
    void buttonClick() {
        label.setText("Hello JavaFX Universe!");
    }

}
